package com.yesmin.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * YesminAgentService — Persistent Background & Overlay AI Agent
 * Uses TYPE_ACCESSIBILITY_OVERLAY so Yesmin stays floating over the Home Screen,
 * Settings, WhatsApp, Instagram, and any other app!
 * Includes a Continuous Voice Loop (1, 2, 3... infinity commands) until user taps STOP.
 */
public class YesminAgentService extends AccessibilityService {

    public static YesminAgentService instance;
    public static String lastNotificationText = "";

    private WindowManager windowManager;
    private LinearLayout overlayPill;
    private TextView tvOverlayStatus;
    private TextView tvOverlayStop;
    private boolean isOverlayVisible = false;
    private boolean continuousVoiceLoop = false;

    private SpeechRecognizer bgRecognizer;
    private TextToSpeech bgTts;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        initBackgroundTts();
        createFloatingOverlayBar();
    }

    private void initBackgroundTts() {
        bgTts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = bgTts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    bgTts.setLanguage(Locale.US);
                }
            }
        });
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @SuppressLint("ClickableViewAccessibility")
    private void createFloatingOverlayBar() {
        mainHandler.post(() -> {
            if (overlayPill != null) return;
            try {
                overlayPill = new LinearLayout(this);
                overlayPill.setOrientation(LinearLayout.HORIZONTAL);
                overlayPill.setGravity(Gravity.CENTER_VERTICAL);
                overlayPill.setPadding(dp(12), dp(8), dp(12), dp(8));

                GradientDrawable bg = new GradientDrawable(
                        GradientDrawable.Orientation.LEFT_RIGHT,
                        new int[]{Color.parseColor("#E61E1B4B"), Color.parseColor("#E63B0764")}
                );
                bg.setCornerRadius(dp(26));
                bg.setStroke(dp(2), Color.parseColor("#A855F7"));
                overlayPill.setBackground(bg);

                TextView tvOrbIcon = new TextView(this);
                tvOrbIcon.setText("🎙️");
                tvOrbIcon.setTextSize(16);
                tvOrbIcon.setPadding(0, 0, dp(8), 0);

                tvOverlayStatus = new TextView(this);
                tvOverlayStatus.setText("Yesmin Live (Tap to Speak)");
                tvOverlayStatus.setTextColor(Color.WHITE);
                tvOverlayStatus.setTextSize(12);
                tvOverlayStatus.setTypeface(Typeface.DEFAULT_BOLD);

                tvOverlayStop = new TextView(this);
                tvOverlayStop.setText(" ✕ ");
                tvOverlayStop.setTextColor(Color.parseColor("#F87171"));
                tvOverlayStop.setTextSize(13);
                tvOverlayStop.setTypeface(Typeface.DEFAULT_BOLD);
                tvOverlayStop.setPadding(dp(8), 0, dp(2), 0);

                overlayPill.addView(tvOrbIcon);
                overlayPill.addView(tvOverlayStatus);
                overlayPill.addView(tvOverlayStop);

                int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1
                        ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                        : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;

                final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        overlayType,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                        PixelFormat.TRANSLUCENT
                );
                params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                params.y = dp(48);

                // Dragging + Click handling on Floating Pill
                overlayPill.setOnTouchListener(new View.OnTouchListener() {
                    private int initialX, initialY;
                    private float initialTouchX, initialTouchY;
                    private long downTime;

                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                downTime = System.currentTimeMillis();
                                initialX = params.x;
                                initialY = params.y;
                                initialTouchX = event.getRawX();
                                initialTouchY = event.getRawY();
                                return true;
                            case MotionEvent.ACTION_MOVE:
                                params.x = initialX + (int) (event.getRawX() - initialTouchX);
                                params.y = initialY + (int) (event.getRawY() - initialTouchY);
                                try { windowManager.updateViewLayout(overlayPill, params); } catch (Throwable ignored) {}
                                return true;
                            case MotionEvent.ACTION_UP:
                                if (System.currentTimeMillis() - downTime < 220) {
                                    // Tap on pill toggles continuous listening!
                                    toggleContinuousLoop();
                                }
                                return true;
                        }
                        return false;
                    }
                });

                tvOverlayStop.setOnClickListener(v -> stopContinuousLoopAndHide());

                windowManager.addView(overlayPill, params);
                isOverlayVisible = true;
            } catch (Throwable ignored) {}
        });
    }

    public void showOverlayAndStartContinuousLoop() {
        mainHandler.post(() -> {
            if (overlayPill == null) {
                createFloatingOverlayBar();
            } else {
                overlayPill.setVisibility(View.VISIBLE);
                isOverlayVisible = true;
            }
            continuousVoiceLoop = true;
            tvOverlayStatus.setText("🟢 Yesmin Live Listening...");
            startNextBackgroundListenCycle(300);
        });
    }

    public void stopContinuousLoopAndHide() {
        mainHandler.post(() -> {
            continuousVoiceLoop = false;
            if (bgRecognizer != null) {
                try { bgRecognizer.cancel(); bgRecognizer.destroy(); } catch (Throwable ignored) {}
                bgRecognizer = null;
            }
            if (bgTts != null) bgTts.stop();
            if (overlayPill != null) {
                overlayPill.setVisibility(View.GONE);
                isOverlayVisible = false;
            }
        });
    }

    public void toggleContinuousLoop() {
        mainHandler.post(() -> {
            continuousVoiceLoop = !continuousVoiceLoop;
            if (continuousVoiceLoop) {
                tvOverlayStatus.setText("🟢 Listening (Infinity Mode)...");
                speakBackground("Bolo Jaan, main background mein sun rahi hoon!");
                startNextBackgroundListenCycle(1800);
            } else {
                tvOverlayStatus.setText("⏸️ Yesmin Paused (Tap to Resume)");
                if (bgRecognizer != null) {
                    try { bgRecognizer.stopListening(); } catch (Throwable ignored) {}
                }
            }
        });
    }

    private void startNextBackgroundListenCycle(long delayMs) {
        mainHandler.postDelayed(() -> {
            if (!continuousVoiceLoop) return;
            try {
                if (bgRecognizer != null) {
                    try { bgRecognizer.destroy(); } catch (Throwable ignored) {}
                }
                bgRecognizer = SpeechRecognizer.createSpeechRecognizer(YesminAgentService.this);
                bgRecognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) {
                        if (tvOverlayStatus != null) tvOverlayStatus.setText("🎙️ Listening... (Bolo Jaan)");
                    }
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float rmsdB) {}
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() {
                        if (tvOverlayStatus != null) tvOverlayStatus.setText("⚡ Executing...");
                    }
                    @Override public void onError(int error) {
                        // Automatically restart listening loop if continuous mode is active!
                        if (continuousVoiceLoop) {
                            startNextBackgroundListenCycle(1200);
                        }
                    }
                    @Override public void onResults(Bundle results) {
                        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty()) {
                            String cmd = matches.get(0);
                            handleBackgroundVoiceCommand(cmd);
                        } else if (continuousVoiceLoop) {
                            startNextBackgroundListenCycle(900);
                        }
                    }
                    @Override public void onPartialResults(Bundle partialResults) {}
                    @Override public void onEvent(int eventType, Bundle params) {}
                });

                Intent recIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                recIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                recIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                recIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                bgRecognizer.startListening(recIntent);
            } catch (Throwable e) {
                if (continuousVoiceLoop) startNextBackgroundListenCycle(2000);
            }
        }, delayMs);
    }

    private void handleBackgroundVoiceCommand(String rawCmd) {
        if (rawCmd == null) return;
        String low = rawCmd.toLowerCase(Locale.ROOT).trim();
        if (tvOverlayStatus != null) {
            tvOverlayStatus.setText("⚡ \"" + (rawCmd.length() > 22 ? rawCmd.substring(0, 22) + "..." : rawCmd) + "\"");
        }

        // Stop command
        if (low.contains("stop listening") || low.contains("band ho jao") || low.contains("ruk jao")) {
            speakBackground("Okay Jaan, main ruk rahi hoon. Jab zaroorat ho tap kar dena!");
            continuousVoiceLoop = false;
            if (tvOverlayStatus != null) tvOverlayStatus.setText("⏸️ Yesmin Paused (Tap)");
            return;
        }

        // Forward to MainActivity's AI & Action dispatcher if alive, or execute directly here in AccessibilityService!
        boolean handledDirectly = false;
        if (low.contains("home") || low.contains("होम")) {
            doGlobal("home");
            speakBackground("Home screen par aa gayi Jaan, ab aage batao kya karna hai?");
            handledDirectly = true;
        } else if (low.contains("back") || low.contains("piche") || low.contains("बैक")) {
            doGlobal("back");
            speakBackground("Back aa gayi Jaan, aage bolo?");
            handledDirectly = true;
        } else if (low.contains("scroll down") || low.contains("niche")) {
            swipe(500, 1550, 500, 380, 350);
            speakBackground("Scroll down kar diya Jaan!");
            handledDirectly = true;
        } else if (low.contains("scroll up") || low.contains("upar")) {
            swipe(500, 420, 500, 1550, 350);
            speakBackground("Scroll up kar diya Jaan!");
            handledDirectly = true;
        } else if (low.contains("notification")) {
            doGlobal("notifications");
            speakBackground("Notifications panel khol diya hai.");
            handledDirectly = true;
        } else if (low.startsWith("click ") || low.startsWith("tap ") || low.startsWith("open ")) {
            String target = rawCmd.replaceAll("(?i)^(click|tap|open)\\s+", "").trim();
            if (clickByText(target)) {
                speakBackground(target + " par click kar diya Jaan!");
                handledDirectly = true;
            }
        }

        if (!handledDirectly && MainActivity.activeInstance != null) {
            MainActivity.activeInstance.dispatchVoiceFromOverlay(rawCmd);
        } else if (!handledDirectly) {
            // Try clicking any matching text on screen
            if (clickByText(rawCmd)) {
                speakBackground("Maine " + rawCmd + " par click kar diya Jaan!");
            } else {
                speakBackground("Jaan, maine suna: " + rawCmd + ". Agla command bolo?");
            }
        }

        // Schedule the next continuous listening cycle (2, 3, 4... infinity!)
        if (continuousVoiceLoop) {
            startNextBackgroundListenCycle(3400);
        }
    }

    public void speakBackground(String text) {
        if (bgTts != null && text != null) {
            bgTts.setPitch(1.1f);
            bgTts.setSpeechRate(1.05f);
            bgTts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bg_utt");
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            CharSequence pkg = event.getPackageName();
            List<CharSequence> texts = event.getText();
            if (texts != null && !texts.isEmpty()) {
                lastNotificationText = "[" + (pkg != null ? pkg : "App") + "] " + texts.toString();
            }
        }
    }

    @Override
    public void onInterrupt() {}

    @Override
    public boolean onUnbind(Intent intent) {
        stopContinuousLoopAndHide();
        instance = null;
        return super.onUnbind(intent);
    }

    public static boolean isConnected() {
        return instance != null;
    }

    public boolean tapXY(float x, float y) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 90));
        return dispatchGesture(builder.build(), null, null);
    }

    public boolean swipe(float x1, float y1, float x2, float y2, int durationMs) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, Math.max(120, durationMs)));
        return dispatchGesture(builder.build(), null, null);
    }

    public boolean clickByText(String targetText) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || targetText == null || targetText.trim().isEmpty()) return false;
        String q = targetText.trim();
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(q);
        if (nodes != null && !nodes.isEmpty()) {
            for (AccessibilityNodeInfo node : nodes) {
                if (performClickChain(node)) return true;
            }
        }
        AccessibilityNodeInfo found = findNodeRecursive(root, q.toLowerCase());
        if (found != null) {
            return performClickChain(found);
        }
        return false;
    }

    private AccessibilityNodeInfo findNodeRecursive(AccessibilityNodeInfo node, String lowerQuery) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if ((t != null && t.toString().toLowerCase().contains(lowerQuery)) ||
            (d != null && d.toString().toLowerCase().contains(lowerQuery))) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo res = findNodeRecursive(node.getChild(i), lowerQuery);
            if (res != null) return res;
        }
        return null;
    }

    private boolean performClickChain(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        int depth = 0;
        while (cur != null && depth < 6) {
            if (cur.isClickable()) {
                return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            cur = cur.getParent();
            depth++;
        }
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (!r.isEmpty() && r.centerX() > 0 && r.centerY() > 0) {
            return tapXY(r.centerX(), r.centerY());
        }
        return false;
    }

    public boolean inputTextOnScreen(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused != null && focused.isEditable()) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        }
        return setTextRecursive(root, text);
    }

    private boolean setTextRecursive(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        if (node.isEditable()) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (setTextRecursive(node.getChild(i), text)) return true;
        }
        return false;
    }

    public String readScreenSummary() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "No active screen window";
        StringBuilder sb = new StringBuilder();
        CharSequence pkg = root.getPackageName();
        if (pkg != null) sb.append("Active App: ").append(pkg).append("\n");
        collectNodeText(root, sb, 0);
        String res = sb.toString().trim();
        return res.length() > 2200 ? res.substring(0, 2200) : res;
    }

    private void collectNodeText(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null || depth > 16) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (t != null && t.length() > 0) {
            sb.append("• ").append(t.toString().replace("\n", " "))
              .append(" @(").append(r.centerX()).append(",").append(r.centerY()).append(")\n");
        } else if (d != null && d.length() > 0) {
            sb.append("• [").append(d.toString().replace("\n", " ")).append("]")
              .append(" @(").append(r.centerX()).append(",").append(r.centerY()).append(")\n");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectNodeText(node.getChild(i), sb, depth + 1);
        }
    }

    public boolean doGlobal(String action) {
        if (action == null) return false;
        String a = action.toLowerCase();
        if (a.contains("home")) return performGlobalAction(GLOBAL_ACTION_HOME);
        if (a.contains("back")) return performGlobalAction(GLOBAL_ACTION_BACK);
        if (a.contains("recent")) return performGlobalAction(GLOBAL_ACTION_RECENTS);
        if (a.contains("notif")) return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
        if (a.contains("quick") || a.contains("setting")) return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
        if (a.contains("lock") && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
        }
        if (a.contains("screenshot") && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
        }
        return false;
    }
}
