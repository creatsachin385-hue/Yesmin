package com.yesmin.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class YesminAgentService extends AccessibilityService {

    public static YesminAgentService instance;
    public static String lastNotificationText = "";

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            CharSequence pkg = event.getPackageName();
            List<CharSequence> texts = event.getText();
            if (texts != null && !texts.isEmpty()) {
                lastNotificationText = "[" + (pkg != null ? pkg : "App") + "] " + texts.toString();
            }
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    public static boolean isConnected() {
        return instance != null;
    }

    // 1. Tap exact coordinates on screen
    public boolean tapXY(float x, float y) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 90));
        return dispatchGesture(builder.build(), null, null);
    }

    // 2. Swipe / Scroll on screen
    public boolean swipe(float x1, float y1, float x2, float y2, int durationMs) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false;
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, Math.max(120, durationMs)));
        return dispatchGesture(builder.build(), null, null);
    }

    // 3. Find any button/element on screen by text or contentDescription and click it
    public boolean clickByText(String targetText) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || targetText == null || targetText.trim().isEmpty()) return false;
        String q = targetText.trim();
        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(q);
        if (nodes != null && !nodes.isEmpty()) {
            for (AccessibilityNodeInfo node : nodes) {
                if (performClickChain(node)) return true;
            }
        }
        // Fallback: case-insensitive recursive search including contentDescription
        AccessibilityNodeInfo found = findNodeRecursive(root, q.toLowerCase());
        if (found != null) {
            return performClickChain(found);
        }
        return false;
    }

    private AccessibilityNodeInfo findNodeRecursive(AccessibilityNodeInfo node, String lowerQuery) {
        if (node == null) return null;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if ((t != null && t.toString().toLowerCase().contains(lowerQuery)) ||
            (d != null && d.toString().toLowerCase().contains(lowerQuery))) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo res = findNodeRecursive(node.getChild(i), lowerQuery);
            if (res != null) return res;
        }
        return null;
    }

    private boolean performClickChain(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        int depth = 0;
        while (cur != null && depth < 6) {
            if (cur.isClickable()) {
                return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            cur = cur.getParent();
            depth++;
        }
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (!r.isEmpty() && r.centerX() > 0 && r.centerY() > 0) {
            return tapXY(r.centerX(), r.centerY());
        }
        return false;
    }

    // 4. Type text into focused or editable field on screen
    public boolean inputTextOnScreen(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused != null && focused.isEditable()) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        }
        return setTextRecursive(root, text);
    }

    private boolean setTextRecursive(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        if (node.isEditable()) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            node.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (setTextRecursive(node.getChild(i), text)) return true;
        }
        return false;
    }

    // 5. Read all visible text + coordinates on current screen for Sub-Agent / Screen Reading (like WhatsApp messages)
    public String readScreenSummary() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "No active screen window";
        StringBuilder sb = new StringBuilder();
        CharSequence pkg = root.getPackageName();
        if (pkg != null) sb.append("Active App: ").append(pkg).append("\n");
        collectNodeText(root, sb, 0);
        String res = sb.toString().trim();
        return res.length() > 2200 ? res.substring(0, 2200) : res;
    }

    private void collectNodeText(AccessibilityNodeInfo node, StringBuilder sb, int depth) {
        if (node == null || depth > 16) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (t != null && t.length() > 0) {
            sb.append("• ").append(t.toString().replace("\n", " "))
              .append(" @(").append(r.centerX()).append(",").append(r.centerY()).append(")\n");
        } else if (d != null && d.length() > 0) {
            sb.append("• [").append(d.toString().replace("\n", " ")).append("]")
              .append(" @(").append(r.centerX()).append(",").append(r.centerY()).append(")\n");
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collectNodeText(node.getChild(i), sb, depth + 1);
        }
    }

    // 6. Global System Actions
    public boolean doGlobal(String action) {
        if (action == null) return false;
        String a = action.toLowerCase();
        if (a.contains("home")) return performGlobalAction(GLOBAL_ACTION_HOME);
        if (a.contains("back")) return performGlobalAction(GLOBAL_ACTION_BACK);
        if (a.contains("recent")) return performGlobalAction(GLOBAL_ACTION_RECENTS);
        if (a.contains("notif")) return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
        if (a.contains("quick") || a.contains("setting")) return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
        if (a.contains("lock") && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
        }
        if (a.contains("screenshot") && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT);
        }
        return false;
    }
}
