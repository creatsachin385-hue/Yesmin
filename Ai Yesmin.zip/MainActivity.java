package com.yesmin.ai;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "YesminNativePrefs";
    private static final String DEFAULT_API_KEY = "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";
    private static final String DEFAULT_BASE_URL = "https://openrouter.ai/api/v1";
    private static final String DEFAULT_MODEL = "auto";
    private static final String DEFAULT_SWEET_PROMPT = "You are Yesmin, a futuristic Jarvis-like AI combined with an affectionate, witty, caring girlfriend persona. Speak naturally in Hinglish (Hindi + English mix in Roman script) calling the user Jaan or Baby. Keep spoken answers concise and warm.";
    private static final String DEFAULT_JARVIS_PROMPT = "You are Yesmin, a tactical Jarvis-grade Android AI assistant. Respond with crisp technical precision.";

    // Top Free & Popular OpenRouter / Gemini / Groq Models
    private static final String[][] PRESET_MODELS = new String[][]{
            {"✨ Auto-Select Best Free OpenRouter Model", "auto"},
            {"🆓 Google: Gemini 2.0 Flash Exp (Free)", "google/gemini-2.0-flash-exp:free"},
            {"🆓 DeepSeek: DeepSeek V3 / Chat (Free)", "deepseek/deepseek-chat:free"},
            {"🆓 DeepSeek: DeepSeek R1 Reasoning (Free)", "deepseek/deepseek-r1:free"},
            {"🆓 Meta: Llama 3.3 70B Instruct (Free)", "meta-llama/llama-3.3-70b-instruct:free"},
            {"🆓 Qwen: Qwen 2.5 72B Instruct (Free)", "qwen/qwen-2.5-72b-instruct:free"},
            {"🆓 Mistral: Mistral Small 24B (Free)", "mistralai/mistral-small-24b-instruct-2501:free"},
            {"🆓 Google: Gemma 3 27B (Free)", "google/gemma-3-27b-it:free"},
            {"⚡ OpenRouter: Auto Router (openrouter/auto)", "openrouter/auto"},
            {"💎 OpenAI: GPT-4o Mini", "openai/gpt-4o-mini"},
            {"💎 Anthropic: Claude 3.5 Sonnet", "anthropic/claude-3.5-sonnet"},
            {"💎 Google Direct: gemini-2.5-flash", "gemini-2.5-flash"},
            {"⚡ Groq Direct: llama-3.3-70b-versatile", "llama-3.3-70b-versatile"}
    };

    private SharedPreferences prefs;
    private TextToSpeech tts;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Native Android UI Views
    private TextView tvTelemetry;
    private TextView tvActiveModelPill;
    private TextView tvPersonaBadge;
    private TextView tvOrbStatus;
    private TextView tvOrbCenter;
    private TextView tvSubtitle;
    private ObjectAnimator orbPulseAnim;

    private ScrollView chatScrollView;
    private LinearLayout chatListLayout;
    private EditText etMessage;
    private LinearLayout viewHudContainer;
    private LinearLayout viewCodeContainer;
    private TextView tvCodeStudioContent;

    private boolean isSweetMode = true;
    private boolean ttsEnabled = true;
    private String lastGeneratedCode = "// Yesmin AI Native Code Studio\n// Ask Yesmin to write Python, Java, Kotlin, or JS code!";
    private final ArrayList<String[]> chatHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#050814"));
            getWindow().setNavigationBarColor(Color.parseColor("#050814"));
        }

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String existingKey = prefs.getString("api_key", "");
        if (existingKey.isEmpty() || existingKey.startsWith("cc_") || existingKey.startsWith("AQ.")) {
            prefs.edit()
                 .putString("api_key", DEFAULT_API_KEY)
                 .putString("base_url", DEFAULT_BASE_URL)
                 .apply();
        }
        isSweetMode = prefs.getBoolean("sweet_mode", true);
        ttsEnabled = prefs.getBoolean("tts_enabled", true);

        buildNativeAndroidUI();
        initTextToSpeech();
        requestAndroidPermissions();
        startLiveTelemetryClock();

        String curModel = prefs.getString("selected_model", DEFAULT_MODEL);
        addChatMessage("YESMIN 💖", "Hey Jaan! 💖 Maine **OpenRouter Model Selector** add kar diya hai!\n\n• Upar **⚙ Settings / Model** button (ya Model badge) par tap karke tum apna pasandida **OpenRouter Model** (Gemini 2.0 Free, DeepSeek V3/R1 Free, Llama 3.3 70B Free, GPT-4o-mini, ya koi bhi custom model ID) select kar sakte ho!\n• Current Model: `" + curModel + "`", false);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable roundBg(String fillHex, String strokeHex, int strokeDp, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeHex != null && strokeDp > 0) {
            gd.setStroke(dp(strokeDp), Color.parseColor(strokeHex));
        }
        return gd;
    }

    private void buildNativeAndroidUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#050814"));
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 1. TOP HUD HEADER BAR
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(10), dp(12), dp(10));
        header.setBackground(roundBg("#0B132B", "#1E293B", 1, 0));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleCol.setLayoutParams(titleLp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("YESMIN AI • HUD");
        tvTitle.setTextColor(Color.parseColor("#06B6D4"));
        tvTitle.setTextSize(16);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);

        tvTelemetry = new TextView(this);
        tvTelemetry.setText("BAT: --% | ONLINE");
        tvTelemetry.setTextColor(Color.parseColor("#94A3B8"));
        tvTelemetry.setTextSize(10);
        tvTelemetry.setTypeface(Typeface.MONOSPACE);

        titleCol.addView(tvTitle);
        titleCol.addView(tvTelemetry);

        tvPersonaBadge = new TextView(this);
        tvPersonaBadge.setText(isSweetMode ? "💖 Sweet" : "⚡ Jarvis");
        tvPersonaBadge.setTextColor(Color.parseColor("#F472B6"));
        tvPersonaBadge.setTextSize(11);
        tvPersonaBadge.setPadding(dp(8), dp(5), dp(8), dp(5));
        tvPersonaBadge.setBackground(roundBg("#2D122B", "#EC4899", 1, 12));
        tvPersonaBadge.setOnClickListener(v -> {
            isSweetMode = !isSweetMode;
            prefs.edit().putBoolean("sweet_mode", isSweetMode).apply();
            tvPersonaBadge.setText(isSweetMode ? "💖 Sweet" : "⚡ Jarvis");
            Toast.makeText(this, isSweetMode ? "Sweet Caring GF Mode 💖" : "Serious Jarvis Mode ⚡", Toast.LENGTH_SHORT).show();
        });

        Button btnSettings = new Button(this);
        btnSettings.setText("⚙ Key & Model");
        btnSettings.setTextColor(Color.parseColor("#E2E8F0"));
        btnSettings.setTextSize(11);
        btnSettings.setAllCaps(false);
        btnSettings.setPadding(dp(10), dp(4), dp(10), dp(4));
        btnSettings.setBackground(roundBg("#1E293B", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams setLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        setLp.setMargins(dp(6), 0, 0, 0);
        btnSettings.setLayoutParams(setLp);
        btnSettings.setOnClickListener(v -> showSettingsDialog());

        header.addView(titleCol);
        header.addView(tvPersonaBadge);
        header.addView(btnSettings);
        root.addView(header);

        // 1B. QUICK MODEL SELECTOR BAR (Always visible right below header!)
        LinearLayout modelBar = new LinearLayout(this);
        modelBar.setOrientation(LinearLayout.HORIZONTAL);
        modelBar.setGravity(Gravity.CENTER_VERTICAL);
        modelBar.setPadding(dp(12), dp(6), dp(12), dp(6));
        modelBar.setBackground(roundBg("#080D1E", "#1E293B", 1, 0));

        TextView tvModelLbl = new TextView(this);
        tvModelLbl.setText("🧠 AI Model: ");
        tvModelLbl.setTextColor(Color.parseColor("#38BDF8"));
        tvModelLbl.setTextSize(11);
        tvModelLbl.setTypeface(Typeface.DEFAULT_BOLD);

        tvActiveModelPill = new TextView(this);
        updateModelPillText();
        tvActiveModelPill.setTextColor(Color.parseColor("#A7F3D0"));
        tvActiveModelPill.setTextSize(11);
        tvActiveModelPill.setTypeface(Typeface.MONOSPACE);
        tvActiveModelPill.setPadding(dp(10), dp(4), dp(10), dp(4));
        tvActiveModelPill.setBackground(roundBg("#0F172A", "#06B6D4", 1, 8));
        LinearLayout.LayoutParams pillLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pillLp.setMargins(dp(4), 0, dp(6), 0);
        tvActiveModelPill.setLayoutParams(pillLp);
        tvActiveModelPill.setOnClickListener(v -> showSettingsDialog());

        Button btnChangeModel = new Button(this);
        btnChangeModel.setText("Select Model ▾");
        btnChangeModel.setAllCaps(false);
        btnChangeModel.setTextSize(11);
        btnChangeModel.setTextColor(Color.WHITE);
        btnChangeModel.setPadding(dp(10), dp(2), dp(10), dp(2));
        btnChangeModel.setBackground(roundBg("#0E7490", "#06B6D4", 1, 8));
        btnChangeModel.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)));
        btnChangeModel.setOnClickListener(v -> showSettingsDialog());

        modelBar.addView(tvModelLbl);
        modelBar.addView(tvActiveModelPill);
        modelBar.addView(btnChangeModel);
        root.addView(modelBar);

        // 2. VIEW SWITCHER TABS (HUD + Chat vs Code Studio)
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(dp(12), dp(6), dp(12), dp(4));

        Button btnTabHud = new Button(this);
        btnTabHud.setText("🎙️ Voice Orb & Chat HUD");
        btnTabHud.setAllCaps(false);
        btnTabHud.setTextSize(12);
        btnTabHud.setTextColor(Color.WHITE);
        btnTabHud.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams tab1Lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
        tab1Lp.setMargins(0, 0, dp(6), 0);
        btnTabHud.setLayoutParams(tab1Lp);

        Button btnTabCode = new Button(this);
        btnTabCode.setText("💻 Code Studio");
        btnTabCode.setAllCaps(false);
        btnTabCode.setTextSize(12);
        btnTabCode.setTextColor(Color.parseColor("#CBD5E1"));
        btnTabCode.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        LinearLayout.LayoutParams tab2Lp = new LinearLayout.LayoutParams(0, dp(34), 1f);
        btnTabCode.setLayoutParams(tab2Lp);

        tabRow.addView(btnTabHud);
        tabRow.addView(btnTabCode);
        root.addView(tabRow);

        // 3. MAIN HUD + CHAT VIEW CONTAINER
        viewHudContainer = new LinearLayout(this);
        viewHudContainer.setOrientation(LinearLayout.VERTICAL);
        viewHudContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // 3A. GLOWING AI VOICE ORB CARD
        LinearLayout orbCard = new LinearLayout(this);
        orbCard.setOrientation(LinearLayout.VERTICAL);
        orbCard.setGravity(Gravity.CENTER_HORIZONTAL);
        orbCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams orbCardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        orbCardLp.setMargins(dp(12), dp(2), dp(12), dp(4));
        orbCard.setLayoutParams(orbCardLp);
        orbCard.setBackground(roundBg("#0A1128", "#06B6D4", 1, 16));

        tvOrbStatus = new TextView(this);
        tvOrbStatus.setText("CORE STATUS: STANDBY (TAP ORB TO SPEAK)");
        tvOrbStatus.setTextColor(Color.parseColor("#38BDF8"));
        tvOrbStatus.setTextSize(10);
        tvOrbStatus.setTypeface(Typeface.MONOSPACE);

        LinearLayout orbFrame = new LinearLayout(this);
        orbFrame.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams orbLp = new LinearLayout.LayoutParams(dp(76), dp(76));
        orbLp.setMargins(0, dp(6), 0, dp(4));
        orbFrame.setLayoutParams(orbLp);
        GradientDrawable orbDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#06B6D4"), Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899")}
        );
        orbDrawable.setShape(GradientDrawable.OVAL);
        orbDrawable.setStroke(dp(3), Color.parseColor("#F472B6"));
        orbFrame.setBackground(orbDrawable);

        tvOrbCenter = new TextView(this);
        tvOrbCenter.setText("🎙️\nSPEAK");
        tvOrbCenter.setGravity(Gravity.CENTER);
        tvOrbCenter.setTextColor(Color.WHITE);
        tvOrbCenter.setTextSize(11);
        tvOrbCenter.setTypeface(Typeface.DEFAULT_BOLD);
        orbFrame.addView(tvOrbCenter);

        orbFrame.setOnClickListener(v -> startNativeVoiceListening());

        orbPulseAnim = ObjectAnimator.ofPropertyValuesHolder(
                orbFrame,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.12f, 1f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.12f, 1f)
        );
        orbPulseAnim.setDuration(2200);
        orbPulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        orbPulseAnim.start();

        tvSubtitle = new TextView(this);
        tvSubtitle.setText("\"Hey Jaan! Tap the glowing Orb to talk or select any OpenRouter model above.\"");
        tvSubtitle.setTextColor(Color.parseColor("#E2E8F0"));
        tvSubtitle.setTextSize(11);
        tvSubtitle.setGravity(Gravity.CENTER);
        tvSubtitle.setPadding(dp(8), dp(2), dp(8), dp(2));

        orbCard.addView(tvOrbStatus);
        orbCard.addView(orbFrame);
        orbCard.addView(tvSubtitle);
        viewHudContainer.addView(orbCard);

        // 3B. NATIVE ANDROID APP LAUNCHER BAR
        HorizontalScrollView appScroll = new HorizontalScrollView(this);
        appScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout appRow = new LinearLayout(this);
        appRow.setOrientation(LinearLayout.HORIZONTAL);
        appRow.setPadding(dp(12), dp(2), dp(12), dp(4));

        String[][] apps = new String[][]{
                {"💬 WhatsApp", "whatsapp", "com.whatsapp"},
                {"📸 Instagram", "instagram", "com.instagram.android"},
                {"▶️ YouTube", "youtube", "com.google.android.youtube"},
                {"🎧 Spotify", "spotify", "com.spotify.music"},
                {"📷 Camera", "camera", "com.android.camera"},
                {"🌐 Chrome", "chrome", "com.android.chrome"}
        };

        for (String[] a : apps) {
            Button b = new Button(this);
            b.setText(a[0]);
            b.setAllCaps(false);
            b.setTextSize(11);
            b.setTextColor(Color.WHITE);
            b.setPadding(dp(12), dp(4), dp(12), dp(4));
            b.setBackground(roundBg("#111827", "#334155", 1, 12));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
            blp.setMargins(0, 0, dp(8), 0);
            b.setLayoutParams(blp);
            final String key = a[1];
            final String pkg = a[2];
            b.setOnClickListener(v -> launchAndroidAppNative(key, pkg));
            appRow.addView(b);
        }
        appScroll.addView(appRow);
        viewHudContainer.addView(appScroll);

        // 3C. CHAT MESSAGES SCROLL VIEW
        chatScrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollLp.setMargins(dp(12), dp(2), dp(12), dp(4));
        chatScrollView.setLayoutParams(scrollLp);

        chatListLayout = new LinearLayout(this);
        chatListLayout.setOrientation(LinearLayout.VERTICAL);
        chatListLayout.setPadding(dp(4), dp(4), dp(4), dp(8));
        chatScrollView.addView(chatListLayout);
        viewHudContainer.addView(chatScrollView);

        // 3D. MESSAGE INPUT BAR
        LinearLayout inputBar = new LinearLayout(this);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setGravity(Gravity.CENTER_VERTICAL);
        inputBar.setPadding(dp(10), dp(8), dp(10), dp(10));
        inputBar.setBackground(roundBg("#0B132B", "#1E293B", 1, 0));

        Button btnMic = new Button(this);
        btnMic.setText("🎙️");
        btnMic.setTextSize(15);
        btnMic.setBackground(roundBg("#2D122B", "#EC4899", 1, 12));
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        micLp.setMargins(0, 0, dp(8), 0);
        btnMic.setLayoutParams(micLp);
        btnMic.setOnClickListener(v -> startNativeVoiceListening());

        etMessage = new EditText(this);
        etMessage.setHint("Talk to Yesmin (Hinglish/English)...");
        etMessage.setHintTextColor(Color.parseColor("#64748B"));
        etMessage.setTextColor(Color.WHITE);
        etMessage.setTextSize(14);
        etMessage.setPadding(dp(14), dp(10), dp(14), dp(10));
        etMessage.setBackground(roundBg("#0F172A", "#334155", 1, 12));
        etMessage.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button btnSend = new Button(this);
        btnSend.setText("Send ➤");
        btnSend.setAllCaps(false);
        btnSend.setTextColor(Color.WHITE);
        btnSend.setTextSize(13);
        btnSend.setTypeface(Typeface.DEFAULT_BOLD);
        btnSend.setBackground(roundBg("#0891B2", "#06B6D4", 1, 12));
        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        sendLp.setMargins(dp(8), 0, 0, 0);
        btnSend.setLayoutParams(sendLp);
        btnSend.setOnClickListener(v -> {
            String msg = etMessage.getText().toString().trim();
            if (!msg.isEmpty()) {
                etMessage.setText("");
                processUserCommand(msg);
            }
        });

        inputBar.addView(btnMic);
        inputBar.addView(etMessage);
        inputBar.addView(btnSend);
        viewHudContainer.addView(inputBar);

        root.addView(viewHudContainer);

        // 4. CODE STUDIO CONTAINER
        viewCodeContainer = new LinearLayout(this);
        viewCodeContainer.setOrientation(LinearLayout.VERTICAL);
        viewCodeContainer.setPadding(dp(14), dp(10), dp(14), dp(14));
        viewCodeContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        viewCodeContainer.setVisibility(View.GONE);

        Button btnCopyCode = new Button(this);
        btnCopyCode.setText("📋 Copy Generated Code");
        btnCopyCode.setAllCaps(false);
        btnCopyCode.setTextColor(Color.WHITE);
        btnCopyCode.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
        btnCopyCode.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("YesminCode", lastGeneratedCode));
                Toast.makeText(this, "Code copied to clipboard!", Toast.LENGTH_SHORT).show();
            }
        });

        ScrollView codeScroll = new ScrollView(this);
        LinearLayout.LayoutParams csLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        csLp.setMargins(0, dp(10), 0, 0);
        codeScroll.setLayoutParams(csLp);
        codeScroll.setBackground(roundBg("#0F172A", "#334155", 1, 12));

        tvCodeStudioContent = new TextView(this);
        tvCodeStudioContent.setText(lastGeneratedCode);
        tvCodeStudioContent.setTextColor(Color.parseColor("#A7F3D0"));
        tvCodeStudioContent.setTypeface(Typeface.MONOSPACE);
        tvCodeStudioContent.setTextSize(12);
        tvCodeStudioContent.setPadding(dp(14), dp(14), dp(14), dp(14));
        tvCodeStudioContent.setTextIsSelectable(true);
        codeScroll.addView(tvCodeStudioContent);

        viewCodeContainer.addView(btnCopyCode);
        viewCodeContainer.addView(codeScroll);
        root.addView(viewCodeContainer);

        btnTabHud.setOnClickListener(v -> {
            viewHudContainer.setVisibility(View.VISIBLE);
            viewCodeContainer.setVisibility(View.GONE);
            btnTabHud.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
            btnTabCode.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        });

        btnTabCode.setOnClickListener(v -> {
            viewHudContainer.setVisibility(View.GONE);
            viewCodeContainer.setVisibility(View.VISIBLE);
            btnTabCode.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
            btnTabHud.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        });

        setContentView(root);
    }

    private void updateModelPillText() {
        if (tvActiveModelPill == null) return;
        String m = prefs.getString("selected_model", DEFAULT_MODEL);
        if ("auto".equals(m) || m.isEmpty()) {
            tvActiveModelPill.setText("✨ Auto (Free OpenRouter Models)");
        } else {
            tvActiveModelPill.setText(m);
        }
    }

    private void addChatMessage(String sender, String messageText, boolean isUser) {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(isUser ? Gravity.END : Gravity.START);
        LinearLayout.LayoutParams wLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wLp.setMargins(0, dp(4), 0, dp(6));
        wrapper.setLayoutParams(wLp);

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(dp(12), dp(8), dp(12), dp(10));
        bubble.setBackground(isUser
                ? roundBg("#164E63", "#06B6D4", 1, 14)
                : roundBg("#1E1B2E", "#EC4899", 1, 14));

        TextView tvSender = new TextView(this);
        String timeStr = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        tvSender.setText(sender + " • " + timeStr);
        tvSender.setTextSize(10);
        tvSender.setTypeface(Typeface.MONOSPACE);
        tvSender.setTextColor(isUser ? Color.parseColor("#67E8F9") : Color.parseColor("#F472B6"));

        TextView tvBody = new TextView(this);
        tvBody.setText(messageText);
        tvBody.setTextColor(Color.WHITE);
        tvBody.setTextSize(14);
        tvBody.setPadding(0, dp(4), 0, 0);
        tvBody.setTextIsSelectable(true);

        bubble.addView(tvSender);
        bubble.addView(tvBody);
        wrapper.addView(bubble);
        chatListLayout.addView(wrapper);

        chatScrollView.post(() -> chatScrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void processUserCommand(String text) {
        addChatMessage("YOU", text, true);
        chatHistory.add(new String[]{"user", text});

        String lower = text.toLowerCase(Locale.ROOT).trim();

        // 1. Direct Android App Launch Intent
        if (lower.contains("open whatsapp") || lower.contains("whatsapp kholo")) {
            launchAndroidAppNative("whatsapp", "com.whatsapp");
            replyAndSpeak(isSweetMode ? "Abhi kholti hoon WhatsApp, Jaan! 💖" : "Launching WhatsApp Messenger.");
            return;
        }
        if (lower.contains("open instagram") || lower.contains("instagram kholo") || lower.contains("open insta")) {
            launchAndroidAppNative("instagram", "com.instagram.android");
            replyAndSpeak(isSweetMode ? "Instagram open kar rahi hoon Baby! 📸" : "Opening Instagram.");
            return;
        }
        if (lower.contains("open spotify") || lower.contains("spotify kholo")) {
            launchAndroidAppNative("spotify", "com.spotify.music");
            replyAndSpeak(isSweetMode ? "Spotify chala rahi hoon Jaan! 🎧" : "Launching Spotify.");
            return;
        }
        if (lower.contains("open camera") || lower.contains("camera kholo") || lower.contains("take a selfie")) {
            launchAndroidAppNative("camera", "com.android.camera");
            replyAndSpeak(isSweetMode ? "Camera khol diya hai Jaan, ek pyari si photo le lo! 📷" : "Camera activated.");
            return;
        }
        if (lower.contains("open chrome") || lower.contains("chrome kholo")) {
            launchAndroidAppNative("chrome", "com.android.chrome");
            replyAndSpeak("Opening Google Chrome, Jaan!");
            return;
        }

        // 2. YouTube Music / Song Play Command
        if (lower.contains("youtube") || lower.startsWith("play ")) {
            String query = text.replaceAll("(?i)(play|on youtube|youtube par|youtube pe|chalao|lagao|bajao|song)", "").trim();
            if (query.isEmpty()) query = "Bollywood Lo-Fi Songs";
            openYouTubeNative(query);
            replyAndSpeak(isSweetMode
                    ? "Aww, great choice Jaan! Main YouTube par \"" + query + "\" abhi play kar rahi hoon! 🎵"
                    : "Playing " + query + " on YouTube.");
            return;
        }

        // 3. Call AI Engine (OpenRouter / Gemini / Groq)
        tvOrbStatus.setText("CORE STATUS: NEURAL THINKING...");
        executor.execute(() -> {
            String aiReply = callAiBrain(text);
            mainHandler.post(() -> {
                tvOrbStatus.setText("CORE STATUS: STANDBY");
                updateModelPillText();
                extractCodeToStudio(aiReply);
                replyAndSpeak(aiReply);
            });
        });
    }

    private void replyAndSpeak(String reply) {
        chatHistory.add(new String[]{"assistant", reply});
        addChatMessage(isSweetMode ? "YESMIN 💖" : "YESMIN HUD ⚡", reply, false);
        String cleanSpeech = reply.replaceAll("```[\\s\\S]*?```", " Maine code studio mein code likh diya hai Jaan. ").replaceAll("━━━━━━━━━━━━━━[\\s\\S]*$", "")
                .replaceAll("[*_#`~>•]", "");
        tvSubtitle.setText("\"" + (cleanSpeech.length() > 140 ? cleanSpeech.substring(0, 140) + "..." : cleanSpeech) + "\"");
        if (ttsEnabled && tts != null) {
            float pitch = prefs.getFloat("voice_pitch", 1.1f);
            float rate = prefs.getFloat("voice_rate", 1.05f);
            tts.setPitch(pitch);
            tts.setSpeechRate(rate);
            tts.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, "yesmin_voice");
        }
    }

    private void extractCodeToStudio(String text) {
        Pattern p = Pattern.compile("```(?:[a-zA-Z0-9_-]*)\\n([\\s\\S]*?)```");
        Matcher m = p.matcher(text);
        if (m.find()) {
            lastGeneratedCode = m.group(1).trim();
            tvCodeStudioContent.setText(lastGeneratedCode);
            Toast.makeText(this, "💻 Code synced to Code Studio tab!", Toast.LENGTH_SHORT).show();
        }
    }

    private String callAiBrain(String userMessage) {
        String apiKey = prefs.getString("api_key", DEFAULT_API_KEY).trim();
        String baseUrl = prefs.getString("base_url", DEFAULT_BASE_URL).trim();
        String chosenModel = prefs.getString("selected_model", DEFAULT_MODEL).trim();

        String defaultPrompt = isSweetMode ? DEFAULT_SWEET_PROMPT : DEFAULT_JARVIS_PROMPT;
        String basePersonaPrompt = prefs.getString("custom_system_prompt", "").trim();
        if (basePersonaPrompt.isEmpty()) {
            basePersonaPrompt = defaultPrompt;
        }

        // A. Google AI Studio Direct Key (AIzaSy...)
        if (apiKey.startsWith("AIza")) {
            try {
                String gModel = (chosenModel.startsWith("gemini-") && !chosenModel.contains("/")) ? chosenModel : "gemini-2.5-flash";
                String gUrl = "https://generativelanguage.googleapis.com/v1beta/models/" + gModel + ":generateContent?key=" + apiKey;
                JSONObject payload = new JSONObject();
                String gSysPrompt = basePersonaPrompt + " Your underlying AI model is '" + gModel + "'. If the user asks which AI or model you are, honestly tell them your persona is Yesmin and your underlying AI model is '" + gModel + "'.";
                JSONObject sysInst = new JSONObject();
                sysInst.put("parts", new JSONArray().put(new JSONObject().put("text", gSysPrompt)));
                payload.put("system_instruction", sysInst);

                JSONArray contents = new JSONArray();
                JSONObject userPart = new JSONObject();
                userPart.put("role", "user");
                userPart.put("parts", new JSONArray().put(new JSONObject().put("text", userMessage)));
                contents.put(userPart);
                payload.put("contents", contents);

                String resStr = httpPostJson(gUrl, payload.toString(), null);
                JSONObject json = new JSONObject(resStr);
                String gText = json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text");
                return gText + "\n\n━━━━━━━━━━━━━━\n🧠 Model: " + gModel;
            } catch (Exception e) {
                return "Jaan, Google Gemini API mein error aaya: " + e.getMessage();
            }
        }

        // B. OpenRouter (sk-or-v1-...), Groq (gsk_...), or Custom OpenAI-Compatible Key
        if (!apiKey.isEmpty()) {
            String effectiveBase = baseUrl;
            if (apiKey.startsWith("sk-or-") || effectiveBase.isEmpty() || effectiveBase.contains("oxionai")) {
                effectiveBase = "https://openrouter.ai/api/v1";
            } else if (apiKey.startsWith("gsk_")) {
                effectiveBase = "https://api.groq.com/openai/v1";
            }
            String chatEndpoint = effectiveBase.endsWith("/chat/completions")
                    ? effectiveBase
                    : effectiveBase.replaceAll("/+$", "") + "/chat/completions";

            // Build candidate model list: User's explicitly selected model FIRST, then free fallbacks
            ArrayList<String> modelsToTry = new ArrayList<>();
            if (!chosenModel.isEmpty() && !"auto".equalsIgnoreCase(chosenModel)) {
                modelsToTry.add(chosenModel);
            }
            if (apiKey.startsWith("gsk_")) {
                modelsToTry.add("llama-3.3-70b-versatile");
                modelsToTry.add("llama3-8b-8192");
            } else {
                // Free OpenRouter models + openrouter/auto fallback
                modelsToTry.add("google/gemini-2.0-flash-exp:free");
                modelsToTry.add("deepseek/deepseek-chat:free");
                modelsToTry.add("meta-llama/llama-3.3-70b-instruct:free");
                modelsToTry.add("qwen/qwen-2.5-72b-instruct:free");
                modelsToTry.add("google/gemma-3-27b-it:free");
                modelsToTry.add("mistralai/mistral-small-24b-instruct-2501:free");
                modelsToTry.add("openrouter/auto");
                modelsToTry.add("openai/gpt-4o-mini");
            }

            String lastError = "";
            for (String modelName : modelsToTry) {
                try {
                    JSONObject body = new JSONObject();
                    body.put("model", modelName);
                    String dynamicSysPrompt = basePersonaPrompt + " IMPORTANT: You are running via OpenRouter on the underlying AI model '" + modelName + "'. Whenever the user asks your model name, which AI you are, or whether you are Gemini/GPT/DeepSeek/Llama, ALWAYS tell them clearly that your persona name is Yesmin and your exact underlying AI model is '" + modelName + "'.";
                    JSONArray msgs = new JSONArray();
                    msgs.put(new JSONObject().put("role", "system").put("content", dynamicSysPrompt));
                    // Include last few turns of chat history
                    int startIdx = Math.max(0, chatHistory.size() - 6);
                    for (int i = startIdx; i < chatHistory.size(); i++) {
                        String[] turn = chatHistory.get(i);
                        msgs.put(new JSONObject().put("role", turn[0]).put("content", turn[1]));
                    }
                    body.put("messages", msgs);

                    String resp = httpPostJson(chatEndpoint, body.toString(), apiKey);
                    JSONObject json = new JSONObject(resp);
                    if (json.has("choices")) {
                        String actualModel = json.optString("model", modelName);
                        if (actualModel == null || actualModel.isEmpty()) actualModel = modelName;
                        String content = json.getJSONArray("choices")
                                .getJSONObject(0)
                                .getJSONObject("message")
                                .getString("content");
                        if (content != null && !content.trim().isEmpty()) {
                            final String usedModel = actualModel;
                            mainHandler.post(() -> {
                                if (tvActiveModelPill != null) {
                                    tvActiveModelPill.setText("🟢 LIVE: " + usedModel);
                                }
                            });
                            return content.trim() + "\n\n━━━━━━━━━━━━━━\n🧠 Model: " + usedModel;
                        }
                    }
                } catch (Exception e) {
                    lastError = e.getMessage();
                    // If the user picked a specific model and it failed, try next fallback only if it was a model/rate-limit error
                }
            }
            if (!lastError.isEmpty()) {
                return "Jaan, OpenRouter API ne yeh message diya: " + lastError + "\n\n(Tip: Upar 'Select Model ▾' button daba kar dusra Free Model select kar lo!)";
            }
        }

        // C. Built-in Offline Hinglish Fallback (When no API key is entered yet)
        return isSweetMode
                ? "Main sun rahi hoon Jaan! 💖 Upar **⚙ Key & Model** button daba kar apni **OpenRouter API Key (`sk-or-v1-...`)** save kar lo aur apna pasandida **AI Model** select kar lo!"
                : "Please configure your OpenRouter API key and select a model in ⚙ Key & Model.";
    }

    private String httpPostJson(String urlStr, String jsonBody, String bearerKey) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(18000);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("HTTP-Referer", "https://yesmin.ai");
        conn.setRequestProperty("X-Title", "Yesmin AI Android Assistant");
        if (bearerKey != null && !bearerKey.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + bearerKey);
        }
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonBody.getBytes("UTF-8"));
        }
        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
        return sb.toString();
    }

    private void showSettingsDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(14), dp(18), dp(10));
        layout.setBackgroundColor(Color.parseColor("#0F172A"));
        scroll.addView(layout);

        // 1. API Key Input
        TextView lblKey = new TextView(this);
        lblKey.setText("1. OpenRouter / Gemini / Groq API Key:");
        lblKey.setTextColor(Color.parseColor("#38BDF8"));
        lblKey.setTextSize(12);
        lblKey.setTypeface(Typeface.DEFAULT_BOLD);

        final EditText etKey = new EditText(this);
        etKey.setHint("sk-or-v1-... or AIzaSy... or gsk_...");
        etKey.setHintTextColor(Color.parseColor("#64748B"));
        etKey.setText(prefs.getString("api_key", DEFAULT_API_KEY));
        etKey.setTextColor(Color.WHITE);
        etKey.setTextSize(13);

        // 2. Preset Model Spinner (Dropdown)
        TextView lblModel = new TextView(this);
        lblModel.setText("2. Select OpenRouter / AI Model:");
        lblModel.setTextColor(Color.parseColor("#F472B6"));
        lblModel.setTextSize(12);
        lblModel.setTypeface(Typeface.DEFAULT_BOLD);
        lblModel.setPadding(0, dp(12), 0, dp(4));

        final Spinner spinnerModels = new Spinner(this);
        final ArrayList<String> modelLabels = new ArrayList<>();
        final ArrayList<String> modelValues = new ArrayList<>();
        for (String[] pm : PRESET_MODELS) {
            modelLabels.add(pm[0]);
            modelValues.add(pm[1]);
        }

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modelLabels);
        spinnerModels.setAdapter(adapter);
        spinnerModels.setBackgroundColor(Color.parseColor("#1E293B"));

        // 3. Custom Model ID Input (Also auto-updates when spinner changes)
        TextView lblCustomModel = new TextView(this);
        lblCustomModel.setText("3. Selected / Custom Model ID (You can also type any OpenRouter model ID):");
        lblCustomModel.setTextColor(Color.parseColor("#A7F3D0"));
        lblCustomModel.setTextSize(11);
        lblCustomModel.setPadding(0, dp(10), 0, dp(2));

        final EditText etCustomModel = new EditText(this);
        String savedModel = prefs.getString("selected_model", DEFAULT_MODEL);
        etCustomModel.setText(savedModel);
        etCustomModel.setHint("e.g. google/gemini-2.0-flash-exp:free");
        etCustomModel.setTextColor(Color.WHITE);
        etCustomModel.setTextSize(13);

        int existingIdx = modelValues.indexOf(savedModel);
        if (existingIdx >= 0) {
            spinnerModels.setSelection(existingIdx);
        }

        spinnerModels.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < modelValues.size()) {
                    etCustomModel.setText(modelValues.get(position));
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // 3B. Live API Key Status TextView & Test API Key Button
        final TextView tvKeyStatus = new TextView(this);
        tvKeyStatus.setText("Status: Tap '✅ Test API Key Now' to check your OpenRouter key.");
        tvKeyStatus.setTextColor(Color.parseColor("#FBBF24"));
        tvKeyStatus.setTextSize(11);
        tvKeyStatus.setPadding(0, dp(8), 0, dp(4));

        Button btnTestKey = new Button(this);
        btnTestKey.setText("✅ Test API Key Now (Check Live Connection)");
        btnTestKey.setAllCaps(false);
        btnTestKey.setTextSize(11);
        btnTestKey.setTextColor(Color.WHITE);
        btnTestKey.setBackground(roundBg("#065F46", "#10B981", 1, 8));
        LinearLayout.LayoutParams testLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        testLp.setMargins(0, dp(4), 0, dp(6));
        btnTestKey.setLayoutParams(testLp);
        btnTestKey.setOnClickListener(v -> {
            final String testKey = etKey.getText().toString().trim();
            final String testModel = etCustomModel.getText().toString().trim();
            tvKeyStatus.setText("⏳ Testing OpenRouter API Key...");
            tvKeyStatus.setTextColor(Color.parseColor("#38BDF8"));
            executor.execute(() -> {
                try {
                    // Check /api/v1/auth/key on OpenRouter
                    URL u = new URL("https://openrouter.ai/api/v1/auth/key");
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(10000);
                    c.setRequestProperty("Authorization", "Bearer " + testKey);
                    int code = c.getResponseCode();
                    InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
                    BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    if (code >= 200 && code < 300) {
                        mainHandler.post(() -> {
                            tvKeyStatus.setText("✅ API KEY IS WORKING! (HTTP 200 OK from OpenRouter) | Model: " + (testModel.isEmpty() ? "auto" : testModel));
                            tvKeyStatus.setTextColor(Color.parseColor("#34D399"));
                            Toast.makeText(this, "✅ OpenRouter API Key is 100% Active!", Toast.LENGTH_LONG).show();
                        });
                    } else {
                        final String errBody = sb.toString();
                        mainHandler.post(() -> {
                            tvKeyStatus.setText("❌ API Key Error (HTTP " + code + "): " + errBody);
                            tvKeyStatus.setTextColor(Color.parseColor("#F87171"));
                        });
                    }
                } catch (Exception e) {
                    mainHandler.post(() -> {
                        tvKeyStatus.setText("❌ Connection Error: " + e.getMessage());
                        tvKeyStatus.setTextColor(Color.parseColor("#F87171"));
                    });
                }
            });
        });

        // 4. Button to Fetch Live Models from OpenRouter API
        Button btnFetchLive = new Button(this);
        btnFetchLive.setText("🔄 Load All Free Models from OpenRouter API");
        btnFetchLive.setAllCaps(false);
        btnFetchLive.setTextSize(11);
        btnFetchLive.setTextColor(Color.WHITE);
        btnFetchLive.setBackground(roundBg("#0E7490", "#06B6D4", 1, 8));
        LinearLayout.LayoutParams fetchLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        fetchLp.setMargins(0, dp(8), 0, dp(4));
        btnFetchLive.setLayoutParams(fetchLp);
        btnFetchLive.setOnClickListener(v -> {
            Toast.makeText(this, "Fetching free models from OpenRouter...", Toast.LENGTH_SHORT).show();
            executor.execute(() -> {
                try {
                    URL u = new URL("https://openrouter.ai/api/v1/models");
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(10000);
                    BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    JSONObject obj = new JSONObject(sb.toString());
                    JSONArray arr = obj.getJSONArray("data");
                    final ArrayList<String> newLabels = new ArrayList<>();
                    final ArrayList<String> newValues = new ArrayList<>();
                    newLabels.add("✨ Auto-Select Best Free OpenRouter Model");
                    newValues.add("auto");
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject m = arr.getJSONObject(i);
                        String id = m.optString("id", "");
                        String name = m.optString("name", id);
                        if (id.endsWith(":free")) {
                            newLabels.add("🆓 " + name + " (" + id + ")");
                            newValues.add(id);
                        }
                    }
                    for (int i = 0; i < Math.min(arr.length(), 40); i++) {
                        JSONObject m = arr.getJSONObject(i);
                        String id = m.optString("id", "");
                        String name = m.optString("name", id);
                        if (!id.endsWith(":free")) {
                            newLabels.add("💎 " + name + " (" + id + ")");
                            newValues.add(id);
                        }
                    }
                    mainHandler.post(() -> {
                        modelLabels.clear();
                        modelValues.clear();
                        modelLabels.addAll(newLabels);
                        modelValues.addAll(newValues);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(this, "Loaded " + newValues.size() + " OpenRouter models! Tap dropdown above.", Toast.LENGTH_LONG).show();
                    });
                } catch (Exception e) {
                    mainHandler.post(() -> Toast.makeText(this, "Could not fetch list: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            });
        });

        // 5. Base URL Input
        TextView lblUrl = new TextView(this);
        lblUrl.setText("4. API Base URL:");
        lblUrl.setTextColor(Color.parseColor("#38BDF8"));
        lblUrl.setTextSize(11);
        lblUrl.setPadding(0, dp(10), 0, 0);

        final EditText etUrl = new EditText(this);
        String savedUrl = prefs.getString("base_url", DEFAULT_BASE_URL);
        if (savedUrl.contains("oxionai")) savedUrl = DEFAULT_BASE_URL;
        etUrl.setText(savedUrl);
        etUrl.setTextColor(Color.WHITE);
        etUrl.setTextSize(12);

        // 6. Full System Prompt Access (Editable Multi-line Box + Reset Button)
        TextView lblSysPrompt = new TextView(this);
        lblSysPrompt.setText("5. Yesmin System Prompt (Edit Yesmin's Personality & Rules):");
        lblSysPrompt.setTextColor(Color.parseColor("#F472B6"));
        lblSysPrompt.setTextSize(12);
        lblSysPrompt.setTypeface(Typeface.DEFAULT_BOLD);
        lblSysPrompt.setPadding(0, dp(12), 0, dp(4));

        final EditText etSysPrompt = new EditText(this);
        String currentPrompt = prefs.getString("custom_system_prompt", "");
        if (currentPrompt.trim().isEmpty()) {
            currentPrompt = isSweetMode ? DEFAULT_SWEET_PROMPT : DEFAULT_JARVIS_PROMPT;
        }
        etSysPrompt.setText(currentPrompt);
        etSysPrompt.setTextColor(Color.WHITE);
        etSysPrompt.setTextSize(12);
        etSysPrompt.setMinLines(3);
        etSysPrompt.setMaxLines(6);
        etSysPrompt.setGravity(Gravity.TOP | Gravity.START);
        etSysPrompt.setPadding(dp(10), dp(8), dp(10), dp(8));
        etSysPrompt.setBackground(roundBg("#1E293B", "#EC4899", 1, 8));

        Button btnResetPrompt = new Button(this);
        btnResetPrompt.setText("↺ Reset System Prompt to Default");
        btnResetPrompt.setAllCaps(false);
        btnResetPrompt.setTextSize(11);
        btnResetPrompt.setTextColor(Color.parseColor("#F9A8D4"));
        btnResetPrompt.setBackground(roundBg("#2D122B", "#EC4899", 1, 8));
        LinearLayout.LayoutParams rpLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        rpLp.setMargins(0, dp(6), 0, dp(4));
        btnResetPrompt.setLayoutParams(rpLp);
        btnResetPrompt.setOnClickListener(v -> {
            etSysPrompt.setText(isSweetMode ? DEFAULT_SWEET_PROMPT : DEFAULT_JARVIS_PROMPT);
            Toast.makeText(this, "Reset to default persona prompt!", Toast.LENGTH_SHORT).show();
        });

        layout.addView(lblKey);
        layout.addView(etKey);
        layout.addView(btnTestKey);
        layout.addView(tvKeyStatus);
        layout.addView(lblModel);
        layout.addView(spinnerModels);
        layout.addView(btnFetchLive);
        layout.addView(lblCustomModel);
        layout.addView(etCustomModel);
        layout.addView(lblSysPrompt);
        layout.addView(etSysPrompt);
        layout.addView(btnResetPrompt);
        layout.addView(lblUrl);
        layout.addView(etUrl);

        new AlertDialog.Builder(this)
                .setTitle("⚙ Key, Model & System Prompt")
                .setView(scroll)
                .setPositiveButton("Save All", (d, w) -> {
                    String chosen = etCustomModel.getText().toString().trim();
                    if (chosen.isEmpty()) chosen = "auto";
                    prefs.edit()
                            .putString("api_key", etKey.getText().toString().trim())
                            .putString("selected_model", chosen)
                            .putString("custom_system_prompt", etSysPrompt.getText().toString().trim())
                            .putString("base_url", etUrl.getText().toString().trim())
                            .apply();
                    updateModelPillText();
                    Toast.makeText(this, "Saved Key, Model & System Prompt!", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("Clear Chat", (d, w) -> {
                    chatListLayout.removeAllViews();
                    chatHistory.clear();
                    Toast.makeText(this, "Chat memory cleared!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void launchAndroidAppNative(String key, String pkg) {
        try {
            PackageManager pm = getPackageManager();
            if ("camera".equals(key)) {
                Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(cam);
                return;
            }
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
                return;
            }
            if ("whatsapp".equals(key)) {
                Intent w4b = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                if (w4b != null) {
                    w4b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(w4b);
                    return;
                }
            }
            Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
            market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(market);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open " + key, Toast.LENGTH_SHORT).show();
        }
    }

    private void openYouTubeNative(String query) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEARCH);
            intent.setPackage("com.google.android.youtube");
            intent.putExtra("query", query);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
            web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(web);
        }
    }

    private void startNativeVoiceListening() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAndroidPermissions();
            Toast.makeText(this, "Please allow Microphone permission!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (tts != null) tts.stop();

        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Yesmin AI (Hinglish / English)...");
            tvOrbStatus.setText("CORE STATUS: LISTENING TO YOUR VOICE...");
            startActivityForResult(intent, 202);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input not supported on this device", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 202) {
            tvOrbStatus.setText("CORE STATUS: STANDBY");
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) {
                    String spokenText = results.get(0);
                    processUserCommand(spokenText);
                }
            }
        }
    }

    private void initTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });
    }

    private void requestAndroidPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ArrayList<String> needed = new ArrayList<>();
            String[] perms = new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
            };
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(p);
                }
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), 101);
            }
        }
    }

    private void startLiveTelemetryClock() {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int batPct = 100;
                try {
                    IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                    Intent batteryStatus = registerReceiver(null, ifilter);
                    if (batteryStatus != null) {
                        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                        if (level >= 0 && scale > 0) batPct = (level * 100) / scale;
                    }
                } catch (Exception ignored) {}
                String clock = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                tvTelemetry.setText("BAT: " + batPct + "% | OPENROUTER READY | " + clock);
                mainHandler.postDelayed(this, 1000);
            }
        }, 200);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
