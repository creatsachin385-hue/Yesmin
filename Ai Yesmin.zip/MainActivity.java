package com.yesmin.ai;

import android.Manifest;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_PERMS = 101;
    private static final int REQ_VOICE = 202;
    private static final int REQ_GOOGLE_ACCOUNT = 303;
    private static final int REQ_SHIZUKU_PERM = 404;

    private WebView webView;
    private TextToSpeech tts;
    private SharedPreferences prefs;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#090D16"));
            getWindow().setNavigationBarColor(Color.parseColor("#090D16"));
        }

        prefs = getSharedPreferences("YesminAgentPrefs", MODE_PRIVATE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new NativeAgentBridge(), "YesminNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushAgentStatusToUi();
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });

        requestRuntimePermissions();

        // Load our ChatGPT/Gemini Dark UI directly from memory (Zero ERR_FILE_NOT_FOUND ever!)
        webView.loadDataWithBaseURL("https://yesmin.ai/", UiHtmlProvider.getHtml(), "text/html", "UTF-8", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        pushAgentStatusToUi();
    }

    private void pushAgentStatusToUi() {
        if (webView == null) return;
        boolean accActive = isAccessibilityServiceEnabled();
        String shizukuState = getShizukuOrRootStatus();
        String googleEmail = prefs.getString("google_email", "");
        int bat = getBatteryPercentage();
        String js = String.format(Locale.US,
                "if(window.onNativeTelemetry) window.onNativeTelemetry(%b, '%s', '%s', %d);",
                accActive,
                shizukuState.replace("'", "\\'"),
                googleEmail.replace("'", "\\'"),
                bat
        );
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    public boolean isAccessibilityServiceEnabled() {
        if (YesminAgentService.isConnected()) return true;
        try {
            String enabledServices = Settings.Secure.getString(
                    getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            );
            if (enabledServices != null && enabledServices.contains(getPackageName())) {
                return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public boolean isShizukuInstalled() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return pi != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public String getShizukuOrRootStatus() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED) {
                    return "GRANTED (Shizuku API)";
                }
            }
            if (isShizukuInstalled()) {
                return "INSTALLED (Tap to Authorize)";
            }
        } catch (Throwable ignored) {}
        return "Tap to Setup";
    }

    public int getBatteryPercentage() {
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent b = registerReceiver(null, ifilter);
            if (b != null) {
                int l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int s = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (l >= 0 && s > 0) return (l * 100) / s;
            }
        } catch (Throwable ignored) {}
        return 100;
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] perms = new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
            };
            ArrayList<String> needed = new ArrayList<>();
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(p);
                }
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
            }
        }
    }

    public class NativeAgentBridge {

        // 1. REQUEST SHIZUKU PERMISSION OR OPEN SHIZUKU MANAGER
        @JavascriptInterface
        public String requestShizukuAccess() {
            try {
                if (!isShizukuInstalled()) {
                    Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api"));
                    market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(market);
                    return "Shizuku app phone mein install nahi mila — maine Play Store khol diya hai!";
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED) {
                        pushAgentStatusToUi();
                        return "✅ Shizuku Permission Pehle Se Granted Hai!";
                    }
                    // Request Android runtime permission for Shizuku API_V23 AND open Shizuku Manager
                    mainHandler.post(() -> requestPermissions(new String[]{"moe.shizuku.manager.permission.API_V23"}, REQ_SHIZUKU_PERM));
                }
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    return "📲 Shizuku Permission Request bhej di gayi hai aur Shizuku App khol diya hai ('Authorized apps' mein Yesmin AI ko ON karein)!";
                }
                return "Requested Shizuku permission!";
            } catch (Throwable e) {
                return "Shizuku error: " + e.getMessage();
            }
        }

        // 2. REAL ROOT (su) PERMISSION & COMMAND EXECUTION
        @JavascriptInterface
        public String requestRootAccess() {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String out = br.readLine();
                p.waitFor();
                if (out != null && out.contains("uid=0")) {
                    return "✅ Real Root Access (Magisk / KernelSU) Granted: " + out;
                }
                return "❌ Root (su) access nahi mila. Agar phone rooted nahi hai to Step 1 (Accessibility Service) ON karein — usse bina root ke pura phone control hota hai!";
            } catch (Throwable e) {
                return "❌ Phone Rooted nahi hai. Step 1 (Accessibility Service) ON karein!";
            }
        }

        // 3. EXECUTE SHELL COMMAND (Via Root su or standard Android shell)
        @JavascriptInterface
        public String runShellCommand(String cmd) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                int code = p.waitFor();
                if (code == 0 && sb.length() > 0) return "[Root] " + sb.toString().trim();
            } catch (Throwable ignored) {}

            try {
                Process p2 = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                BufferedReader br = new BufferedReader(new InputStreamReader(p2.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                p2.waitFor();
                return sb.toString().trim();
            } catch (Throwable e) {
                return "Shell error: " + e.getMessage();
            }
        }

        // 4. OPEN ANDROID ACCESSIBILITY SETTINGS (Where "Yesmin AI Autonomous Agent" is registered!)
        @JavascriptInterface
        public void openAccessibilitySettings() {
            try {
                Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                mainHandler.post(() -> Toast.makeText(MainActivity.this,
                        "👉 'Installed apps / Downloaded services' mein ja kar 'Yesmin AI Autonomous Agent' ko ON karein!",
                        Toast.LENGTH_LONG).show());
            } catch (Throwable ignored) {}
        }

        // 5. PERFORM REAL AUTONOMOUS AGENT ACTIONS VIA ACCESSIBILITY SERVICE
        @JavascriptInterface
        public String executeAgentAction(String actionType, String param1, String param2) {
            YesminAgentService svc = YesminAgentService.instance;
            if ("GLOBAL".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.doGlobal(param1)) {
                    return "✅ Executed system action: " + param1;
                }
                if (param1.equalsIgnoreCase("home")) runShellCommand("input keyevent 3");
                if (param1.equalsIgnoreCase("back")) runShellCommand("input keyevent 4");
                return "⚠️ Enable 'Yesmin AI Autonomous Agent' in Accessibility Settings first!";
            }
            if ("CLICK_TEXT".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.clickByText(param1)) {
                    return "✅ Clicked screen button: '" + param1 + "'";
                }
                return "⚠️ Could not find '" + param1 + "' (Make sure Yesmin AI is ON in Accessibility Settings)";
            }
            if ("TAP_XY".equalsIgnoreCase(actionType)) {
                try {
                    float x = Float.parseFloat(param1);
                    float y = Float.parseFloat(param2);
                    if (svc != null && svc.tapXY(x, y)) return "✅ Tapped (" + x + ", " + y + ")";
                    runShellCommand("input tap " + (int) x + " " + (int) y);
                    return "✅ Tapped (" + (int) x + ", " + (int) y + ")";
                } catch (Throwable e) {
                    return "Invalid coordinates";
                }
            }
            if ("SCROLL_DOWN".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.swipe(500, 1500, 500, 400, 350)) {
                    return "✅ Scrolled down on screen!";
                }
                runShellCommand("input swipe 500 1500 500 400 300");
                return "⚠️ Enable Yesmin AI in Accessibility Settings to scroll any screen!";
            }
            if ("TYPE_TEXT".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.inputTextOnScreen(param1)) {
                    return "✅ Typed text: " + param1;
                }
                String safe = param1.replace(" ", "%s");
                runShellCommand("input text \"" + safe + "\"");
                return "✅ Typed: " + param1;
            }
            if ("READ_SCREEN".equalsIgnoreCase(actionType)) {
                if (svc != null) return svc.readScreenSummary();
                return "Enable Yesmin AI in Accessibility Settings to read screen text.";
            }
            return "Unknown agent action";
        }

        // 6. REAL ANDROID GOOGLE ACCOUNT PICKER DIALOG
        @JavascriptInterface
        public void signInWithGoogle() {
            mainHandler.post(() -> {
                try {
                    Intent intent;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        intent = AccountManager.newChooseAccountIntent(
                                null, null, new String[]{"com.google"}, null, null, null, null);
                    } else {
                        intent = AccountManager.newChooseAccountIntent(
                                null, null, new String[]{"com.google"}, false, null, null, null, null);
                    }
                    startActivityForResult(intent, REQ_GOOGLE_ACCOUNT);
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Google Account Picker: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        // 7. LAUNCH ANY ANDROID APP
        @JavascriptInterface
        public boolean launchApp(String key, String pkg) {
            try {
                String k = key != null ? key.toLowerCase().trim() : "";
                PackageManager pm = getPackageManager();
                if ("camera".equals(k)) {
                    Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                    cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(cam);
                    return true;
                }
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    return true;
                }
                if ("whatsapp".equals(k)) {
                    Intent w4b = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                    if (w4b != null) {
                        w4b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(w4b);
                        return true;
                    }
                }
                Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
                market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(market);
                return true;
            } catch (Throwable e) {
                return false;
            }
        }

        @JavascriptInterface
        public void playYouTube(String query) {
            try {
                Intent intent = new Intent(Intent.ACTION_SEARCH);
                intent.setPackage("com.google.android.youtube");
                intent.putExtra("query", query);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Throwable e) {
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
                web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(web);
            }
        }

        @JavascriptInterface
        public void startVoiceMic() {
            mainHandler.post(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo Jaan (Yesmin AI Agent Listening)...");
                    startActivityForResult(intent, REQ_VOICE);
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Voice Mic not available", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void speak(String text) {
            if (tts != null && text != null) {
                tts.setPitch(1.1f);
                tts.setSpeechRate(1.05f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yesmin_utt");
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void copyText(String text) {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("YesminAI", text));
                mainHandler.post(() -> Toast.makeText(MainActivity.this, "Copied to clipboard!", Toast.LENGTH_SHORT).show());
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (list != null && !list.isEmpty()) {
                String spoken = list.get(0).replace("'", "\\'").replace("\n", " ");
                webView.evaluateJavascript("if(window.onNativeVoiceInput) window.onNativeVoiceInput('" + spoken + "');", null);
            }
        } else if (requestCode == REQ_GOOGLE_ACCOUNT && resultCode == RESULT_OK && data != null) {
            String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            if (accountName != null) {
                prefs.edit().putString("google_email", accountName).apply();
                Toast.makeText(this, "✅ Signed in with Google: " + accountName, Toast.LENGTH_LONG).show();
                pushAgentStatusToUi();
            }
        }
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("if(window.handleBackPress) window.handleBackPress();", val -> {
            if (!"true".equals(val)) {
                MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
