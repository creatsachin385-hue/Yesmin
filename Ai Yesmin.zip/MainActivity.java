package com.yesmin.ai;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "YesminNativePrefs";
    private static final String DEFAULT_API_KEY = "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";
    private static final String DEFAULT_BASE_URL = "https://openrouter.ai/api/v1";
    private static final String DEFAULT_MODEL = "auto";
    private static final String DEFAULT_SWEET_PROMPT = "You are Yesmin, a futuristic Jarvis-like AI combined with an affectionate, witty, caring girlfriend persona. Speak naturally in Hinglish (Hindi + English mix in Roman script) calling the user Jaan or Baby. Keep spoken answers concise and warm.";
    private static final String DEFAULT_JARVIS_PROMPT = "You are Yesmin, a tactical Jarvis-grade Android AI assistant. Respond with crisp technical precision.";

    // Pre-loaded OpenRouter Models
    private static final String[][] PRESET_MODELS = new String[][]{
            {"✨ Auto-Select Best Free OpenRouter Model", "auto"},
            {"🆓 Google: Gemini 2.0 Flash Exp (Free)", "google/gemini-2.0-flash-exp:free"},
            {"🆓 DeepSeek: DeepSeek V3 / Chat (Free)", "deepseek/deepseek-chat:free"},
            {"🆓 DeepSeek: DeepSeek R1 Reasoning (Free)", "deepseek/deepseek-r1:free"},
            {"🆓 Meta: Llama 3.3 70B Instruct (Free)", "meta-llama/llama-3.3-70b-instruct:free"},
            {"🆓 Qwen: Qwen 2.5 72B Instruct (Free)", "qwen/qwen-2.5-72b-instruct:free"},
            {"🆓 Mistral: Mistral Small 24B (Free)", "mistralai/mistral-small-24b-instruct-2501:free"},
            {"🆓 Google: Gemma 3 27B (Free)", "google/gemma-3-27b-it:free"},
            {"⚡ OpenRouter: Auto Router (openrouter/auto)", "openrouter/auto"},
            {"💎 OpenAI: GPT-4o Mini", "openai/gpt-4o-mini"},
            {"💎 Anthropic: Claude 3.5 Sonnet", "anthropic/claude-3.5-sonnet"},
            {"💎 Google Direct: gemini-2.5-flash", "gemini-2.5-flash"},
            {"⚡ Groq Direct: llama-3.3-70b-versatile", "llama-3.3-70b-versatile"}
    };

    private SharedPreferences prefs;
    private TextToSpeech tts;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Navigation & Drawer Views
    private FrameLayout rootFrame;
    private LinearLayout mainContentLayout;
    private View drawerBackdrop;
    private LinearLayout drawerSidebar;
    private boolean isDrawerOpen = false;

    // Header & Telemetry Views
    private TextView tvTelemetry;
    private TextView tvActiveModelPill;
    private TextView tvPersonaBadge;
    private TextView tvUserNameHeader;
    private TextView tvOrbStatus;
    private TextView tvOrbCenter;
    private TextView tvSubtitle;
    private ObjectAnimator orbPulseAnim;

    // Chat, Code, and Multi-Session Views
    private ScrollView chatScrollView;
    private LinearLayout chatListLayout;
    private EditText etMessage;
    private LinearLayout viewHudContainer;
    private LinearLayout viewCodeContainer;
    private TextView tvCodeStudioContent;
    private LinearLayout historySessionsLayout;

    private boolean isSweetMode = true;
    private boolean ttsEnabled = true;
    private String currentSessionId = "";
    private String currentSessionTitle = "New Chat";
    private String lastGeneratedCode = "// Yesmin AI Native Code Studio\n// Ask Yesmin to write Python, Java, Kotlin, or JS code!";
    private final ArrayList<String[]> currentMessages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#050814"));
            getWindow().setNavigationBarColor(Color.parseColor("#050814"));
        }

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String existingKey = prefs.getString("api_key", "");
        if (existingKey.isEmpty() || existingKey.startsWith("cc_") || existingKey.startsWith("AQ.")) {
            prefs.edit()
                 .putString("api_key", DEFAULT_API_KEY)
                 .putString("base_url", DEFAULT_BASE_URL)
                 .apply();
        }
        isSweetMode = prefs.getBoolean("sweet_mode", true);
        ttsEnabled = prefs.getBoolean("tts_enabled", true);

        buildModernAppLayout();
        initTextToSpeech();
        requestAndroidPermissions();
        startLiveTelemetryClock();

        startNewChatSession(false);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable roundBg(String fillHex, String strokeHex, int strokeDp, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeHex != null && strokeDp > 0) {
            gd.setStroke(dp(strokeDp), Color.parseColor(strokeHex));
        }
        return gd;
    }

    // =========================================================================
    // 1. MODERN APP LAYOUT WITH CHATGPT/GEMINI 3-LINE DRAWER SIDEBAR
    // =========================================================================
    private void buildModernAppLayout() {
        rootFrame = new FrameLayout(this);
        rootFrame.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rootFrame.setBackgroundColor(Color.parseColor("#050814"));

        // 1A. MAIN CONTENT SCREEN
        mainContentLayout = new LinearLayout(this);
        mainContentLayout.setOrientation(LinearLayout.VERTICAL);
        mainContentLayout.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // TOP APP BAR (☰ Hamburger Menu, Logo, Persona Badge, API Center Button)
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(12), dp(10), dp(12), dp(10));
        topBar.setBackground(roundBg("#0B132B", "#1E293B", 1, 0));

        // ☰ 3-Line Hamburger Menu Button
        Button btnHamburger = new Button(this);
        btnHamburger.setText("☰");
        btnHamburger.setTextColor(Color.parseColor("#06B6D4"));
        btnHamburger.setTextSize(20);
        btnHamburger.setPadding(0, 0, 0, 0);
        btnHamburger.setBackground(roundBg("#0F172A", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams hamLp = new LinearLayout.LayoutParams(dp(40), dp(40));
        hamLp.setMargins(0, 0, dp(10), 0);
        btnHamburger.setLayoutParams(hamLp);
        btnHamburger.setOnClickListener(v -> toggleDrawer());

        LinearLayout brandCol = new LinearLayout(this);
        brandCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        brandCol.setLayoutParams(brandLp);

        TextView tvLogo = new TextView(this);
        tvLogo.setText("YESMIN AI");
        tvLogo.setTextColor(Color.WHITE);
        tvLogo.setTextSize(17);
        tvLogo.setTypeface(Typeface.DEFAULT_BOLD);

        tvTelemetry = new TextView(this);
        tvTelemetry.setText("BAT: --% | ONLINE | 00:00");
        tvTelemetry.setTextColor(Color.parseColor("#94A3B8"));
        tvTelemetry.setTextSize(10);
        tvTelemetry.setTypeface(Typeface.MONOSPACE);

        brandCol.addView(tvLogo);
        brandCol.addView(tvTelemetry);

        // Persona Badge
        tvPersonaBadge = new TextView(this);
        tvPersonaBadge.setText(isSweetMode ? "💖 Sweet" : "⚡ Jarvis");
        tvPersonaBadge.setTextColor(Color.parseColor("#F472B6"));
        tvPersonaBadge.setTextSize(11);
        tvPersonaBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        tvPersonaBadge.setBackground(roundBg("#2D122B", "#EC4899", 1, 12));
        tvPersonaBadge.setOnClickListener(v -> {
            isSweetMode = !isSweetMode;
            prefs.edit().putBoolean("sweet_mode", isSweetMode).apply();
            tvPersonaBadge.setText(isSweetMode ? "💖 Sweet" : "⚡ Jarvis");
            Toast.makeText(this, isSweetMode ? "Sweet Caring GF Mode Activated 💖" : "Serious Jarvis HUD Mode Activated ⚡", Toast.LENGTH_SHORT).show();
        });

        // Dedicated API & AI Brain Engine Button
        Button btnApiCenter = new Button(this);
        btnApiCenter.setText("⚙️ API");
        btnApiCenter.setTextColor(Color.parseColor("#06B6D4"));
        btnApiCenter.setTextSize(11);
        btnApiCenter.setAllCaps(false);
        btnApiCenter.setPadding(dp(8), dp(4), dp(8), dp(4));
        btnApiCenter.setBackground(roundBg("#0F172A", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams apiBtnLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        apiBtnLp.setMargins(dp(6), 0, 0, 0);
        btnApiCenter.setLayoutParams(apiBtnLp);
        btnApiCenter.setOnClickListener(v -> showApiEngineDialog());

        topBar.addView(btnHamburger);
        topBar.addView(brandCol);
        topBar.addView(tvPersonaBadge);
        topBar.addView(btnApiCenter);
        mainContentLayout.addView(topBar);

        // QUICK ACTIVE MODEL & NEW CHAT BAR
        LinearLayout modelBar = new LinearLayout(this);
        modelBar.setOrientation(LinearLayout.HORIZONTAL);
        modelBar.setGravity(Gravity.CENTER_VERTICAL);
        modelBar.setPadding(dp(12), dp(5), dp(12), dp(5));
        modelBar.setBackground(roundBg("#080D1E", "#1E293B", 1, 0));

        tvActiveModelPill = new TextView(this);
        updateModelPillText();
        tvActiveModelPill.setTextColor(Color.parseColor("#A7F3D0"));
        tvActiveModelPill.setTextSize(11);
        tvActiveModelPill.setTypeface(Typeface.MONOSPACE);
        tvActiveModelPill.setPadding(dp(8), dp(3), dp(8), dp(3));
        tvActiveModelPill.setBackground(roundBg("#0F172A", "#06B6D4", 1, 8));
        LinearLayout.LayoutParams pillLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pillLp.setMargins(0, 0, dp(6), 0);
        tvActiveModelPill.setLayoutParams(pillLp);
        tvActiveModelPill.setOnClickListener(v -> showApiEngineDialog());

        Button btnNewChatTop = new Button(this);
        btnNewChatTop.setText("➕ New Chat");
        btnNewChatTop.setAllCaps(false);
        btnNewChatTop.setTextSize(11);
        btnNewChatTop.setTextColor(Color.WHITE);
        btnNewChatTop.setPadding(dp(10), dp(2), dp(10), dp(2));
        btnNewChatTop.setBackground(roundBg("#0E7490", "#06B6D4", 1, 8));
        btnNewChatTop.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)));
        btnNewChatTop.setOnClickListener(v -> startNewChatSession(true));

        modelBar.addView(tvActiveModelPill);
        modelBar.addView(btnNewChatTop);
        mainContentLayout.addView(modelBar);

        // VIEW SWITCHER TABS (Voice Orb HUD & Chat vs Code Studio)
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(dp(12), dp(5), dp(12), dp(3));

        Button btnTabHud = new Button(this);
        btnTabHud.setText("🎙️ Voice & Chat HUD");
        btnTabHud.setAllCaps(false);
        btnTabHud.setTextSize(11);
        btnTabHud.setTextColor(Color.WHITE);
        btnTabHud.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams tab1Lp = new LinearLayout.LayoutParams(0, dp(32), 1f);
        tab1Lp.setMargins(0, 0, dp(6), 0);
        btnTabHud.setLayoutParams(tab1Lp);

        Button btnTabCode = new Button(this);
        btnTabCode.setText("💻 Code Studio");
        btnTabCode.setAllCaps(false);
        btnTabCode.setTextSize(11);
        btnTabCode.setTextColor(Color.parseColor("#CBD5E1"));
        btnTabCode.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        LinearLayout.LayoutParams tab2Lp = new LinearLayout.LayoutParams(0, dp(32), 1f);
        btnTabCode.setLayoutParams(tab2Lp);

        tabRow.addView(btnTabHud);
        tabRow.addView(btnTabCode);
        mainContentLayout.addView(tabRow);

        // MAIN HUD + CHAT CONTAINER
        viewHudContainer = new LinearLayout(this);
        viewHudContainer.setOrientation(LinearLayout.VERTICAL);
        viewHudContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // GLOWING AI VOICE ORB CARD
        LinearLayout orbCard = new LinearLayout(this);
        orbCard.setOrientation(LinearLayout.VERTICAL);
        orbCard.setGravity(Gravity.CENTER_HORIZONTAL);
        orbCard.setPadding(dp(10), dp(6), dp(10), dp(6));
        LinearLayout.LayoutParams orbCardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        orbCardLp.setMargins(dp(12), dp(2), dp(12), dp(4));
        orbCard.setLayoutParams(orbCardLp);
        orbCard.setBackground(roundBg("#0A1128", "#06B6D4", 1, 14));

        tvOrbStatus = new TextView(this);
        tvOrbStatus.setText("CORE STATUS: STANDBY (TAP ORB TO SPEAK)");
        tvOrbStatus.setTextColor(Color.parseColor("#38BDF8"));
        tvOrbStatus.setTextSize(9);
        tvOrbStatus.setTypeface(Typeface.MONOSPACE);

        LinearLayout orbFrame = new LinearLayout(this);
        orbFrame.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams orbLp = new LinearLayout.LayoutParams(dp(72), dp(72));
        orbLp.setMargins(0, dp(4), 0, dp(3));
        orbFrame.setLayoutParams(orbLp);
        GradientDrawable orbDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#06B6D4"), Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899")}
        );
        orbDrawable.setShape(GradientDrawable.OVAL);
        orbDrawable.setStroke(dp(3), Color.parseColor("#F472B6"));
        orbFrame.setBackground(orbDrawable);

        tvOrbCenter = new TextView(this);
        tvOrbCenter.setText("🎙️\nSPEAK");
        tvOrbCenter.setGravity(Gravity.CENTER);
        tvOrbCenter.setTextColor(Color.WHITE);
        tvOrbCenter.setTextSize(11);
        tvOrbCenter.setTypeface(Typeface.DEFAULT_BOLD);
        orbFrame.addView(tvOrbCenter);

        orbFrame.setOnClickListener(v -> startNativeVoiceListening());

        orbPulseAnim = ObjectAnimator.ofPropertyValuesHolder(
                orbFrame,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.12f, 1f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.12f, 1f)
        );
        orbPulseAnim.setDuration(2200);
        orbPulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        orbPulseAnim.start();

        tvSubtitle = new TextView(this);
        tvSubtitle.setText("\"Hey Jaan! Tap Orb to talk, or tap ☰ menu to view History, Google Login, & Agent Mode.\"");
        tvSubtitle.setTextColor(Color.parseColor("#E2E8F0"));
        tvSubtitle.setTextSize(11);
        tvSubtitle.setGravity(Gravity.CENTER);
        tvSubtitle.setPadding(dp(8), dp(2), dp(8), dp(2));

        orbCard.addView(tvOrbStatus);
        orbCard.addView(orbFrame);
        orbCard.addView(tvSubtitle);
        viewHudContainer.addView(orbCard);

        // NATIVE ANDROID APP LAUNCHER BAR
        HorizontalScrollView appScroll = new HorizontalScrollView(this);
        appScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout appRow = new LinearLayout(this);
        appRow.setOrientation(LinearLayout.HORIZONTAL);
        appRow.setPadding(dp(12), dp(2), dp(12), dp(4));

        String[][] apps = new String[][]{
                {"💬 WhatsApp", "whatsapp", "com.whatsapp"},
                {"📸 Instagram", "instagram", "com.instagram.android"},
                {"▶️ YouTube", "youtube", "com.google.android.youtube"},
                {"🎧 Spotify", "spotify", "com.spotify.music"},
                {"📷 Camera", "camera", "com.android.camera"},
                {"🌐 Chrome", "chrome", "com.android.chrome"}
        };

        for (String[] a : apps) {
            Button b = new Button(this);
            b.setText(a[0]);
            b.setAllCaps(false);
            b.setTextSize(11);
            b.setTextColor(Color.WHITE);
            b.setPadding(dp(10), dp(4), dp(10), dp(4));
            b.setBackground(roundBg("#111827", "#334155", 1, 10));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
            blp.setMargins(0, 0, dp(6), 0);
            b.setLayoutParams(blp);
            final String key = a[1];
            final String pkg = a[2];
            b.setOnClickListener(v -> launchAndroidAppNative(key, pkg));
            appRow.addView(b);
        }
        appScroll.addView(appRow);
        viewHudContainer.addView(appScroll);

        // CHAT MESSAGES SCROLL VIEW
        chatScrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollLp.setMargins(dp(12), dp(2), dp(12), dp(4));
        chatScrollView.setLayoutParams(scrollLp);

        chatListLayout = new LinearLayout(this);
        chatListLayout.setOrientation(LinearLayout.VERTICAL);
        chatListLayout.setPadding(dp(4), dp(4), dp(4), dp(8));
        chatScrollView.addView(chatListLayout);
        viewHudContainer.addView(chatScrollView);

        // MESSAGE INPUT BAR
        LinearLayout inputBar = new LinearLayout(this);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setGravity(Gravity.CENTER_VERTICAL);
        inputBar.setPadding(dp(10), dp(8), dp(10), dp(10));
        inputBar.setBackground(roundBg("#0B132B", "#1E293B", 1, 0));

        Button btnMic = new Button(this);
        btnMic.setText("🎙️");
        btnMic.setTextSize(15);
        btnMic.setBackground(roundBg("#2D122B", "#EC4899", 1, 12));
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        micLp.setMargins(0, 0, dp(8), 0);
        btnMic.setLayoutParams(micLp);
        btnMic.setOnClickListener(v -> startNativeVoiceListening());

        etMessage = new EditText(this);
        etMessage.setHint("Talk to Yesmin (Hinglish/English)...");
        etMessage.setHintTextColor(Color.parseColor("#64748B"));
        etMessage.setTextColor(Color.WHITE);
        etMessage.setTextSize(14);
        etMessage.setPadding(dp(14), dp(10), dp(14), dp(10));
        etMessage.setBackground(roundBg("#0F172A", "#334155", 1, 12));
        etMessage.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button btnSend = new Button(this);
        btnSend.setText("Send ➤");
        btnSend.setAllCaps(false);
        btnSend.setTextColor(Color.WHITE);
        btnSend.setTextSize(13);
        btnSend.setTypeface(Typeface.DEFAULT_BOLD);
        btnSend.setBackground(roundBg("#0891B2", "#06B6D4", 1, 12));
        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        sendLp.setMargins(dp(8), 0, 0, 0);
        btnSend.setLayoutParams(sendLp);
        btnSend.setOnClickListener(v -> {
            String msg = etMessage.getText().toString().trim();
            if (!msg.isEmpty()) {
                etMessage.setText("");
                processUserCommand(msg);
            }
        });

        inputBar.addView(btnMic);
        inputBar.addView(etMessage);
        inputBar.addView(btnSend);
        viewHudContainer.addView(inputBar);

        mainContentLayout.addView(viewHudContainer);

        // CODE STUDIO CONTAINER
        viewCodeContainer = new LinearLayout(this);
        viewCodeContainer.setOrientation(LinearLayout.VERTICAL);
        viewCodeContainer.setPadding(dp(14), dp(10), dp(14), dp(14));
        viewCodeContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        viewCodeContainer.setVisibility(View.GONE);

        Button btnCopyCode = new Button(this);
        btnCopyCode.setText("📋 Copy Generated Code");
        btnCopyCode.setAllCaps(false);
        btnCopyCode.setTextColor(Color.WHITE);
        btnCopyCode.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
        btnCopyCode.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("YesminCode", lastGeneratedCode));
                Toast.makeText(this, "Code copied to clipboard!", Toast.LENGTH_SHORT).show();
            }
        });

        ScrollView codeScroll = new ScrollView(this);
        LinearLayout.LayoutParams csLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        csLp.setMargins(0, dp(10), 0, 0);
        codeScroll.setLayoutParams(csLp);
        codeScroll.setBackground(roundBg("#0F172A", "#334155", 1, 12));

        tvCodeStudioContent = new TextView(this);
        tvCodeStudioContent.setText(lastGeneratedCode);
        tvCodeStudioContent.setTextColor(Color.parseColor("#A7F3D0"));
        tvCodeStudioContent.setTypeface(Typeface.MONOSPACE);
        tvCodeStudioContent.setTextSize(12);
        tvCodeStudioContent.setPadding(dp(14), dp(14), dp(14), dp(14));
        tvCodeStudioContent.setTextIsSelectable(true);
        codeScroll.addView(tvCodeStudioContent);

        viewCodeContainer.addView(btnCopyCode);
        viewCodeContainer.addView(codeScroll);
        mainContentLayout.addView(viewCodeContainer);

        btnTabHud.setOnClickListener(v -> {
            viewHudContainer.setVisibility(View.VISIBLE);
            viewCodeContainer.setVisibility(View.GONE);
            btnTabHud.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
            btnTabCode.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        });

        btnTabCode.setOnClickListener(v -> {
            viewHudContainer.setVisibility(View.GONE);
            viewCodeContainer.setVisibility(View.VISIBLE);
            btnTabCode.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
            btnTabHud.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        });

        rootFrame.addView(mainContentLayout);

        // 1B. DRAWER BACKDROP (Semi-transparent overlay to close drawer)
        drawerBackdrop = new View(this);
        drawerBackdrop.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        drawerBackdrop.setBackgroundColor(Color.parseColor("#B3000000"));
        drawerBackdrop.setVisibility(View.GONE);
        drawerBackdrop.setOnClickListener(v -> closeDrawer());
        rootFrame.addView(drawerBackdrop);

        // 1C. DRAWER SIDEBAR (Sliding panel with Google Profile, New Chat, History, Rare Options)
        drawerSidebar = buildDrawerSidebarView();
        FrameLayout.LayoutParams sideLp = new FrameLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START);
        drawerSidebar.setLayoutParams(sideLp);
        drawerSidebar.setVisibility(View.GONE);
        rootFrame.addView(drawerSidebar);

        setContentView(rootFrame);
    }

    // =========================================================================
    // 2. CHATGPT / GEMINI STYLE SLIDING SIDEBAR DRAWER
    // =========================================================================
    private LinearLayout buildDrawerSidebarView() {
        LinearLayout sidebar = new LinearLayout(this);
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setBackground(roundBg("#0A1024", "#1E293B", 1, 0));
        sidebar.setPadding(dp(16), dp(16), dp(16), dp(14));

        // USER GOOGLE PROFILE CARD
        LinearLayout profileCard = new LinearLayout(this);
        profileCard.setOrientation(LinearLayout.HORIZONTAL);
        profileCard.setGravity(Gravity.CENTER_VERTICAL);
        profileCard.setPadding(dp(10), dp(8), dp(10), dp(8));
        profileCard.setBackground(roundBg("#111C3A", "#06B6D4", 1, 12));

        TextView tvAvatar = new TextView(this);
        tvAvatar.setText("👤");
        tvAvatar.setTextSize(18);
        tvAvatar.setPadding(dp(4), dp(4), dp(4), dp(4));

        LinearLayout profileInfo = new LinearLayout(this);
        profileInfo.setOrientation(LinearLayout.VERTICAL);
        profileInfo.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        profileInfo.setPadding(dp(6), 0, 0, 0);

        tvUserNameHeader = new TextView(this);
        String savedUser = prefs.getString("google_user_email", "Google Account (Tap to Sign in)");
        tvUserNameHeader.setText(savedUser);
        tvUserNameHeader.setTextColor(Color.WHITE);
        tvUserNameHeader.setTextSize(12);
        tvUserNameHeader.setTypeface(Typeface.DEFAULT_BOLD);

        TextView tvSignInSub = new TextView(this);
        tvSignInSub.setText("Cloud Sync & Multi-Device");
        tvSignInSub.setTextColor(Color.parseColor("#94A3B8"));
        tvSignInSub.setTextSize(10);

        profileInfo.addView(tvUserNameHeader);
        profileInfo.addView(tvSignInSub);
        profileCard.addView(tvAvatar);
        profileCard.addView(profileInfo);
        profileCard.setOnClickListener(v -> showGoogleSignInDialog());
        sidebar.addView(profileCard);

        // ➕ NEW CHAT BUTTON
        Button btnSideNewChat = new Button(this);
        btnSideNewChat.setText("➕ New Chat");
        btnSideNewChat.setTextColor(Color.WHITE);
        btnSideNewChat.setAllCaps(false);
        btnSideNewChat.setTextSize(13);
        btnSideNewChat.setTypeface(Typeface.DEFAULT_BOLD);
        btnSideNewChat.setBackground(roundBg("#0891B2", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams ncLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        ncLp.setMargins(0, dp(14), 0, dp(10));
        btnSideNewChat.setLayoutParams(ncLp);
        btnSideNewChat.setOnClickListener(v -> {
            closeDrawer();
            startNewChatSession(true);
        });
        sidebar.addView(btnSideNewChat);

        // CHAT HISTORY HEADER
        TextView tvHistTitle = new TextView(this);
        tvHistTitle.setText("📜 CHAT SESSIONS HISTORY");
        tvHistTitle.setTextColor(Color.parseColor("#38BDF8"));
        tvHistTitle.setTextSize(10);
        tvHistTitle.setTypeface(Typeface.MONOSPACE);
        tvHistTitle.setPadding(0, dp(4), 0, dp(4));
        sidebar.addView(tvHistTitle);

        // HISTORY SESSION LIST (SCROLLABLE)
        ScrollView histScroll = new ScrollView(this);
        LinearLayout.LayoutParams histLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        histScroll.setLayoutParams(histLp);

        historySessionsLayout = new LinearLayout(this);
        historySessionsLayout.setOrientation(LinearLayout.VERTICAL);
        histScroll.addView(historySessionsLayout);
        sidebar.addView(histScroll);

        // ADVANCED / RARE OPTIONS SECTION AT BOTTOM OF DRAWER
        LinearLayout advSection = new LinearLayout(this);
        advSection.setOrientation(LinearLayout.VERTICAL);
        advSection.setPadding(0, dp(8), 0, 0);

        // 1. Dedicated AI Engine & API Center
        Button btnEngine = createDrawerOptionButton("⚙️ AI Engine & Model Center", "#1E293B", "#06B6D4", () -> {
            closeDrawer();
            showApiEngineDialog();
        });

        // 2. Autonomous Phone Agent Controller (Shizuku & Accessibility)
        Button btnAgent = createDrawerOptionButton("🤖 Autonomous Phone Agent", "#1E1E38", "#A855F7", () -> {
            closeDrawer();
            showAgentControlDialog();
        });

        // 3. System Prompt Lab (Edit Persona)
        Button btnPromptLab = createDrawerOptionButton("🛠️ System Prompt Lab", "#2D122B", "#EC4899", () -> {
            closeDrawer();
            showSystemPromptDialog();
        });

        advSection.addView(btnEngine);
        advSection.addView(btnAgent);
        advSection.addView(btnPromptLab);
        sidebar.addView(advSection);

        return sidebar;
    }

    private Button createDrawerOptionButton(String text, String bgHex, String strokeHex, Runnable onClick) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(11);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        b.setBackground(roundBg(bgHex, strokeHex, 1, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        lp.setMargins(0, dp(4), 0, dp(4));
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> onClick.run());
        return b;
    }

    private void toggleDrawer() {
        if (isDrawerOpen) closeDrawer();
        else openDrawer();
    }

    private void openDrawer() {
        refreshHistoryDrawerList();
        drawerBackdrop.setVisibility(View.VISIBLE);
        drawerSidebar.setVisibility(View.VISIBLE);
        drawerSidebar.setTranslationX(-dp(290));
        drawerSidebar.animate().translationX(0).setDuration(220).start();
        isDrawerOpen = true;
    }

    private void closeDrawer() {
        drawerSidebar.animate().translationX(-dp(290)).setDuration(180).withEndAction(() -> {
            drawerSidebar.setVisibility(View.GONE);
            drawerBackdrop.setVisibility(View.GONE);
        }).start();
        isDrawerOpen = false;
    }

    // =========================================================================
    // 3. MULTI-SESSION CHAT HISTORY ENGINE (Save, Load, Rename, Delete)
    // =========================================================================
    private void startNewChatSession(boolean showToast) {
        // Save current session before switching if it has messages
        saveActiveSessionToStorage();

        currentSessionId = UUID.randomUUID().toString().substring(0, 8);
        currentSessionTitle = "New Chat";
        currentMessages.clear();
        chatListLayout.removeAllViews();

        String curModel = prefs.getString("selected_model", DEFAULT_MODEL);
        addChatMessage("YESMIN 💖", "Hey Jaan! 💖 New Chat session shuru ho gaya hai.\n\n• Active Model: `" + curModel + "`\n• Tap ☰ top-left to access Chat History, Google Sign-in, or Autonomous Phone Agent!", false);

        if (showToast) {
            Toast.makeText(this, "Started New Chat Session!", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveActiveSessionToStorage() {
        if (currentMessages.isEmpty()) return;
        try {
            JSONArray sessions = getSavedSessionsArray();
            JSONArray updated = new JSONArray();

            JSONObject currentObj = new JSONObject();
            currentObj.put("id", currentSessionId);
            currentObj.put("title", currentSessionTitle);
            currentObj.put("time", new SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(new Date()));

            JSONArray msgsArr = new JSONArray();
            for (String[] m : currentMessages) {
                JSONObject mo = new JSONObject();
                mo.put("sender", m[0]);
                mo.put("text", m[1]);
                msgsArr.put(mo);
            }
            currentObj.put("messages", msgsArr);
            updated.put(currentObj);

            // Append older sessions (up to 30)
            for (int i = 0; i < sessions.length(); i++) {
                JSONObject s = sessions.getJSONObject(i);
                if (!s.optString("id").equals(currentSessionId)) {
                    updated.put(s);
                }
            }
            prefs.edit().putString("chat_sessions_json", updated.toString()).apply();
        } catch (Exception ignored) {}
    }

    private JSONArray getSavedSessionsArray() {
        try {
            String json = prefs.getString("chat_sessions_json", "[]");
            return new JSONArray(json);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void refreshHistoryDrawerList() {
        historySessionsLayout.removeAllViews();
        JSONArray sessions = getSavedSessionsArray();

        if (sessions.length() == 0) {
            TextView tvEmpty = new TextView(this);
            tvEmpty.setText("No saved chats yet.\nStart chatting and your sessions will appear here!");
            tvEmpty.setTextColor(Color.parseColor("#64748B"));
            tvEmpty.setTextSize(11);
            tvEmpty.setPadding(dp(8), dp(10), dp(8), dp(10));
            historySessionsLayout.addView(tvEmpty);
            return;
        }

        for (int i = 0; i < sessions.length(); i++) {
            try {
                JSONObject s = sessions.getJSONObject(i);
                final String sId = s.getString("id");
                final String sTitle = s.getString("title");
                final String sTime = s.optString("time", "");
                final JSONArray sMsgs = s.optJSONArray("messages");

                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.VERTICAL);
                item.setPadding(dp(10), dp(8), dp(10), dp(8));
                boolean isCurrent = sId.equals(currentSessionId);
                item.setBackground(roundBg(isCurrent ? "#1E293B" : "#0D152B", isCurrent ? "#06B6D4" : "#1E293B", 1, 8));
                LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                itemLp.setMargins(0, 0, 0, dp(6));
                item.setLayoutParams(itemLp);

                TextView tvT = new TextView(this);
                tvT.setText("💬 " + sTitle);
                tvT.setTextColor(isCurrent ? Color.parseColor("#38BDF8") : Color.WHITE);
                tvT.setTextSize(12);
                tvT.setTypeface(Typeface.DEFAULT_BOLD);
                tvT.setMaxLines(1);

                TextView tvTime = new TextView(this);
                tvTime.setText(sTime + " • " + (sMsgs != null ? sMsgs.length() : 0) + " messages");
                tvTime.setTextColor(Color.parseColor("#94A3B8"));
                tvTime.setTextSize(10);

                item.addView(tvT);
                item.addView(tvTime);

                // Tap to load session
                item.setOnClickListener(v -> {
                    closeDrawer();
                    loadSession(sId, sTitle, sMsgs);
                });

                // Long press to rename or delete
                item.setOnLongClickListener(v -> {
                    showSessionOptionsDialog(sId, sTitle);
                    return true;
                });

                historySessionsLayout.addView(item);
            } catch (Exception ignored) {}
        }
    }

    private void loadSession(String sId, String title, JSONArray msgs) {
        saveActiveSessionToStorage();
        currentSessionId = sId;
        currentSessionTitle = title;
        currentMessages.clear();
        chatListLayout.removeAllViews();

        if (msgs != null && msgs.length() > 0) {
            for (int i = 0; i < msgs.length(); i++) {
                try {
                    JSONObject m = msgs.getJSONObject(i);
                    String sender = m.getString("sender");
                    String text = m.getString("text");
                    boolean isUser = sender.equalsIgnoreCase("YOU");
                    currentMessages.add(new String[]{sender, text});
                    renderChatMessageView(sender, text, isUser);
                } catch (Exception ignored) {}
            }
        }
        Toast.makeText(this, "Loaded: " + title, Toast.LENGTH_SHORT).show();
    }

    private void showSessionOptionsDialog(String sId, String currentTitle) {
        String[] opts = new String[]{"✏️ Rename Chat", "🗑️ Delete Chat"};
        new AlertDialog.Builder(this)
                .setTitle("Chat Options: " + currentTitle)
                .setItems(opts, (dialog, which) -> {
                    if (which == 0) {
                        final EditText etNewName = new EditText(this);
                        etNewName.setText(currentTitle);
                        new AlertDialog.Builder(this)
                                .setTitle("Rename Chat Session")
                                .setView(etNewName)
                                .setPositiveButton("Rename", (d, w) -> {
                                    String n = etNewName.getText().toString().trim();
                                    if (!n.isEmpty()) {
                                        updateSessionTitle(sId, n);
                                    }
                                })
                                .setNegativeButton("Cancel", null)
                                .show();
                    } else if (which == 1) {
                        deleteSession(sId);
                    }
                })
                .show();
    }

    private void updateSessionTitle(String sId, String newTitle) {
        try {
            JSONArray arr = getSavedSessionsArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject s = arr.getJSONObject(i);
                if (s.optString("id").equals(sId)) {
                    s.put("title", newTitle);
                }
            }
            prefs.edit().putString("chat_sessions_json", arr.toString()).apply();
            if (sId.equals(currentSessionId)) currentSessionTitle = newTitle;
            refreshHistoryDrawerList();
            Toast.makeText(this, "Renamed!", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {}
    }

    private void deleteSession(String sId) {
        try {
            JSONArray arr = getSavedSessionsArray();
            JSONArray updated = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject s = arr.getJSONObject(i);
                if (!s.optString("id").equals(sId)) {
                    updated.put(s);
                }
            }
            prefs.edit().putString("chat_sessions_json", updated.toString()).apply();
            if (sId.equals(currentSessionId)) {
                startNewChatSession(false);
            }
            refreshHistoryDrawerList();
            Toast.makeText(this, "Session deleted!", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {}
    }

    // =========================================================================
    // 4. GOOGLE ACCOUNT SIGN-IN SIMULATOR / PROFILE DIALOG
    // =========================================================================
    private void showGoogleSignInDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(14), dp(18), dp(10));
        layout.setBackgroundColor(Color.parseColor("#0F172A"));

        TextView tvH = new TextView(this);
        tvH.setText("Sign in with Google Account\nSync your chat history, API keys, and personalized AI memory across devices.");
        tvH.setTextColor(Color.parseColor("#94A3B8"));
        tvH.setTextSize(12);

        final EditText etGoogleEmail = new EditText(this);
        etGoogleEmail.setHint("yourname@gmail.com");
        etGoogleEmail.setHintTextColor(Color.parseColor("#64748B"));
        etGoogleEmail.setText(prefs.getString("google_user_email", ""));
        etGoogleEmail.setTextColor(Color.WHITE);
        etGoogleEmail.setTextSize(13);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.setMargins(0, dp(10), 0, dp(10));
        etGoogleEmail.setLayoutParams(elp);

        layout.addView(tvH);
        layout.addView(etGoogleEmail);

        new AlertDialog.Builder(this)
                .setTitle("Google Account")
                .setView(layout)
                .setPositiveButton("Sign in / Save", (d, w) -> {
                    String email = etGoogleEmail.getText().toString().trim();
                    if (!email.isEmpty()) {
                        prefs.edit().putString("google_user_email", email).apply();
                        tvUserNameHeader.setText(email);
                        Toast.makeText(this, "Signed in as: " + email, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Sign out", (d, w) -> {
                    prefs.edit().remove("google_user_email").apply();
                    tvUserNameHeader.setText("Google Account (Tap to Sign in)");
                    Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    // =========================================================================
    // 5. AUTONOMOUS PHONE AGENT CENTER (Accessibility & Shizuku)
    // =========================================================================
    private void showAgentControlDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(14), dp(18), dp(10));
        layout.setBackgroundColor(Color.parseColor("#0F172A"));
        scroll.addView(layout);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("🤖 Yesmin Autonomous Phone Agent");
        tvTitle.setTextColor(Color.parseColor("#A855F7"));
        tvTitle.setTextSize(15);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);

        TextView tvDesc = new TextView(this);
        tvDesc.setText("Yesmin can autonomously control your phone (Tap, Type, Launch apps, and execute tasks) using Android Accessibility Service and Shizuku (ADB privileges) without needing risky root.");
        tvDesc.setTextColor(Color.parseColor("#CBD5E1"));
        tvDesc.setTextSize(12);
        tvDesc.setPadding(0, dp(6), 0, dp(10));

        // 1. Accessibility Service Status Button
        Button btnAcc = new Button(this);
        btnAcc.setText("1. Open Android Accessibility Settings ⚙");
        btnAcc.setAllCaps(false);
        btnAcc.setTextColor(Color.WHITE);
        btnAcc.setBackground(roundBg("#1E1B4B", "#8B5CF6", 1, 8));
        btnAcc.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Could not open settings", Toast.LENGTH_SHORT).show();
            }
        });

        // 2. Shizuku App Link
        Button btnShizuku = new Button(this);
        btnShizuku.setText("2. Download / Check Shizuku App (Wireless Debugging)");
        btnShizuku.setAllCaps(false);
        btnShizuku.setTextColor(Color.WHITE);
        btnShizuku.setBackground(roundBg("#064E3B", "#10B981", 1, 8));
        LinearLayout.LayoutParams sbLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        sbLp.setMargins(0, dp(8), 0, dp(8));
        btnShizuku.setLayoutParams(sbLp);
        btnShizuku.setOnClickListener(v -> {
            try {
                Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api"));
                market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(market);
            } catch (Exception ignored) {}
        });

        layout.addView(tvTitle);
        layout.addView(tvDesc);
        layout.addView(btnAcc);
        layout.addView(btnShizuku);

        new AlertDialog.Builder(this)
                .setTitle("Agent Controller")
                .setView(scroll)
                .setPositiveButton("Done", null)
                .show();
    }

    // =========================================================================
    // 6. SYSTEM PROMPT LAB (Custom Persona Editor)
    // =========================================================================
    private void showSystemPromptDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(14), dp(18), dp(10));
        layout.setBackgroundColor(Color.parseColor("#0F172A"));

        TextView tvTitle = new TextView(this);
        tvTitle.setText("🛠️ Yesmin System Prompt Lab\nDefine Yesmin's personality, speaking rules, and technical directives.");
        tvTitle.setTextColor(Color.parseColor("#EC4899"));
        tvTitle.setTextSize(12);

        final EditText etPrompt = new EditText(this);
        String currentPrompt = prefs.getString("custom_system_prompt", "");
        if (currentPrompt.trim().isEmpty()) {
            currentPrompt = isSweetMode ? DEFAULT_SWEET_PROMPT : DEFAULT_JARVIS_PROMPT;
        }
        etPrompt.setText(currentPrompt);
        etPrompt.setTextColor(Color.WHITE);
        etPrompt.setTextSize(12);
        etPrompt.setMinLines(4);
        etPrompt.setMaxLines(7);
        etPrompt.setGravity(Gravity.TOP | Gravity.START);
        etPrompt.setPadding(dp(10), dp(8), dp(10), dp(8));
        etPrompt.setBackground(roundBg("#1E293B", "#EC4899", 1, 8));
        LinearLayout.LayoutParams epLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        epLp.setMargins(0, dp(10), 0, dp(10));
        etPrompt.setLayoutParams(epLp);

        Button btnReset = new Button(this);
        btnReset.setText("↺ Reset to Default");
        btnReset.setAllCaps(false);
        btnReset.setTextColor(Color.parseColor("#F9A8D4"));
        btnReset.setBackground(roundBg("#2D122B", "#EC4899", 1, 8));
        btnReset.setOnClickListener(v -> etPrompt.setText(isSweetMode ? DEFAULT_SWEET_PROMPT : DEFAULT_JARVIS_PROMPT));

        layout.addView(tvTitle);
        layout.addView(etPrompt);
        layout.addView(btnReset);

        new AlertDialog.Builder(this)
                .setTitle("System Prompt Lab")
                .setView(layout)
                .setPositiveButton("Save Persona", (d, w) -> {
                    prefs.edit().putString("custom_system_prompt", etPrompt.getText().toString().trim()).apply();
                    Toast.makeText(this, "Saved System Prompt!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // =========================================================================
    // 7. DEDICATED AI ENGINE & MODEL CENTER DIALOG
    // =========================================================================
    private void showApiEngineDialog() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(14), dp(18), dp(10));
        layout.setBackgroundColor(Color.parseColor("#0F172A"));
        scroll.addView(layout);

        TextView lblKey = new TextView(this);
        lblKey.setText("1. OpenRouter / Gemini / Groq API Key:");
        lblKey.setTextColor(Color.parseColor("#38BDF8"));
        lblKey.setTextSize(12);
        lblKey.setTypeface(Typeface.DEFAULT_BOLD);

        final EditText etKey = new EditText(this);
        etKey.setHint("sk-or-v1-... or AIzaSy... or gsk_...");
        etKey.setHintTextColor(Color.parseColor("#64748B"));
        etKey.setText(prefs.getString("api_key", DEFAULT_API_KEY));
        etKey.setTextColor(Color.WHITE);
        etKey.setTextSize(13);

        final TextView tvKeyStatus = new TextView(this);
        tvKeyStatus.setText("Status: Tap 'Test API Key' to verify live connection.");
        tvKeyStatus.setTextColor(Color.parseColor("#FBBF24"));
        tvKeyStatus.setTextSize(11);
        tvKeyStatus.setPadding(0, dp(6), 0, dp(4));

        Button btnTestKey = new Button(this);
        btnTestKey.setText("✅ Test API Key & Latency (Live Check)");
        btnTestKey.setAllCaps(false);
        btnTestKey.setTextSize(11);
        btnTestKey.setTextColor(Color.WHITE);
        btnTestKey.setBackground(roundBg("#065F46", "#10B981", 1, 8));
        LinearLayout.LayoutParams testLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        testLp.setMargins(0, dp(4), 0, dp(6));
        btnTestKey.setLayoutParams(testLp);

        TextView lblModel = new TextView(this);
        lblModel.setText("2. Select OpenRouter AI Model:");
        lblModel.setTextColor(Color.parseColor("#F472B6"));
        lblModel.setTextSize(12);
        lblModel.setTypeface(Typeface.DEFAULT_BOLD);
        lblModel.setPadding(0, dp(8), 0, dp(4));

        final Spinner spinnerModels = new Spinner(this);
        final ArrayList<String> modelLabels = new ArrayList<>();
        final ArrayList<String> modelValues = new ArrayList<>();
        for (String[] pm : PRESET_MODELS) {
            modelLabels.add(pm[0]);
            modelValues.add(pm[1]);
        }

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modelLabels);
        spinnerModels.setAdapter(adapter);
        spinnerModels.setBackgroundColor(Color.parseColor("#1E293B"));

        TextView lblCustomModel = new TextView(this);
        lblCustomModel.setText("3. Active / Custom Model ID:");
        lblCustomModel.setTextColor(Color.parseColor("#A7F3D0"));
        lblCustomModel.setTextSize(11);
        lblCustomModel.setPadding(0, dp(8), 0, dp(2));

        final EditText etCustomModel = new EditText(this);
        String savedModel = prefs.getString("selected_model", DEFAULT_MODEL);
        etCustomModel.setText(savedModel);
        etCustomModel.setTextColor(Color.WHITE);
        etCustomModel.setTextSize(13);

        int existingIdx = modelValues.indexOf(savedModel);
        if (existingIdx >= 0) spinnerModels.setSelection(existingIdx);

        spinnerModels.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < modelValues.size()) {
                    etCustomModel.setText(modelValues.get(position));
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnTestKey.setOnClickListener(v -> {
            final String testKey = etKey.getText().toString().trim();
            final String testModel = etCustomModel.getText().toString().trim();
            tvKeyStatus.setText("⏳ Testing OpenRouter API Key...");
            tvKeyStatus.setTextColor(Color.parseColor("#38BDF8"));
            executor.execute(() -> {
                long t0 = System.currentTimeMillis();
                try {
                    URL u = new URL("https://openrouter.ai/api/v1/auth/key");
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("GET");
                    c.setConnectTimeout(9000);
                    c.setRequestProperty("Authorization", "Bearer " + testKey);
                    int code = c.getResponseCode();
                    long dt = System.currentTimeMillis() - t0;
                    if (code >= 200 && code < 300) {
                        mainHandler.post(() -> {
                            tvKeyStatus.setText("✅ API KEY ACTIVE! (HTTP 200, " + dt + "ms)\nModel: " + (testModel.isEmpty() ? "auto" : testModel));
                            tvKeyStatus.setTextColor(Color.parseColor("#34D399"));
                        });
                    } else {
                        mainHandler.post(() -> {
                            tvKeyStatus.setText("❌ Error (HTTP " + code + "): Invalid Key");
                            tvKeyStatus.setTextColor(Color.parseColor("#F87171"));
                        });
                    }
                } catch (Exception e) {
                    mainHandler.post(() -> {
                        tvKeyStatus.setText("❌ Connection Failed: " + e.getMessage());
                        tvKeyStatus.setTextColor(Color.parseColor("#F87171"));
                    });
                }
            });
        });

        TextView lblUrl = new TextView(this);
        lblUrl.setText("4. API Base URL:");
        lblUrl.setTextColor(Color.parseColor("#38BDF8"));
        lblUrl.setTextSize(11);
        lblUrl.setPadding(0, dp(8), 0, 0);

        final EditText etUrl = new EditText(this);
        String savedUrl = prefs.getString("base_url", DEFAULT_BASE_URL);
        if (savedUrl.contains("oxionai")) savedUrl = DEFAULT_BASE_URL;
        etUrl.setText(savedUrl);
        etUrl.setTextColor(Color.WHITE);
        etUrl.setTextSize(12);

        layout.addView(lblKey);
        layout.addView(etKey);
        layout.addView(btnTestKey);
        layout.addView(tvKeyStatus);
        layout.addView(lblModel);
        layout.addView(spinnerModels);
        layout.addView(lblCustomModel);
        layout.addView(etCustomModel);
        layout.addView(lblUrl);
        layout.addView(etUrl);

        new AlertDialog.Builder(this)
                .setTitle("⚙ AI Engine & API Center")
                .setView(scroll)
                .setPositiveButton("Save Engine Settings", (d, w) -> {
                    String chosen = etCustomModel.getText().toString().trim();
                    if (chosen.isEmpty()) chosen = "auto";
                    prefs.edit()
                            .putString("api_key", etKey.getText().toString().trim())
                            .putString("selected_model", chosen)
                            .putString("base_url", etUrl.getText().toString().trim())
                            .apply();
                    updateModelPillText();
                    Toast.makeText(this, "Engine Model: " + chosen, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateModelPillText() {
        if (tvActiveModelPill == null) return;
        String m = prefs.getString("selected_model", DEFAULT_MODEL);
        if ("auto".equals(m) || m.isEmpty()) {
            tvActiveModelPill.setText("🧠 Model: Auto (Free OpenRouter)");
        } else {
            tvActiveModelPill.setText("🧠 " + m);
        }
    }

    // =========================================================================
    // 8. CHAT MESSAGE RENDERING & PROCESSING
    // =========================================================================
    private void addChatMessage(String sender, String messageText, boolean isUser) {
        currentMessages.add(new String[]{sender, messageText});
        renderChatMessageView(sender, messageText, isUser);

        // Auto-update session title from first user query if still "New Chat"
        if (isUser && "New Chat".equals(currentSessionTitle)) {
            String snippet = messageText.length() > 24 ? messageText.substring(0, 24) + "..." : messageText;
            currentSessionTitle = snippet;
        }
    }

    private void renderChatMessageView(String sender, String messageText, boolean isUser) {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(isUser ? Gravity.END : Gravity.START);
        LinearLayout.LayoutParams wLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wLp.setMargins(0, dp(4), 0, dp(6));
        wrapper.setLayoutParams(wLp);

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(dp(12), dp(8), dp(12), dp(10));
        bubble.setBackground(isUser
                ? roundBg("#164E63", "#06B6D4", 1, 14)
                : roundBg("#1E1B2E", "#EC4899", 1, 14));

        TextView tvSender = new TextView(this);
        String timeStr = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        tvSender.setText(sender + " • " + timeStr);
        tvSender.setTextSize(10);
        tvSender.setTypeface(Typeface.MONOSPACE);
        tvSender.setTextColor(isUser ? Color.parseColor("#67E8F9") : Color.parseColor("#F472B6"));

        TextView tvBody = new TextView(this);
        tvBody.setText(messageText);
        tvBody.setTextColor(Color.WHITE);
        tvBody.setTextSize(14);
        tvBody.setPadding(0, dp(4), 0, 0);
        tvBody.setTextIsSelectable(true);

        bubble.addView(tvSender);
        bubble.addView(tvBody);
        wrapper.addView(bubble);
        chatListLayout.addView(wrapper);

        chatScrollView.post(() -> chatScrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void processUserCommand(String text) {
        addChatMessage("YOU", text, true);

        String lower = text.toLowerCase(Locale.ROOT).trim();

        // 1. Direct App Launches
        if (lower.contains("open whatsapp") || lower.contains("whatsapp kholo")) {
            launchAndroidAppNative("whatsapp", "com.whatsapp");
            replyAndSpeak(isSweetMode ? "Abhi kholti hoon WhatsApp, Jaan! 💖" : "Launching WhatsApp Messenger.");
            return;
        }
        if (lower.contains("open instagram") || lower.contains("instagram kholo") || lower.contains("open insta")) {
            launchAndroidAppNative("instagram", "com.instagram.android");
            replyAndSpeak(isSweetMode ? "Instagram open kar rahi hoon Baby! 📸" : "Opening Instagram.");
            return;
        }
        if (lower.contains("open spotify") || lower.contains("spotify kholo")) {
            launchAndroidAppNative("spotify", "com.spotify.music");
            replyAndSpeak(isSweetMode ? "Spotify chala rahi hoon Jaan! 🎧" : "Launching Spotify.");
            return;
        }
        if (lower.contains("open camera") || lower.contains("camera kholo") || lower.contains("selfie")) {
            launchAndroidAppNative("camera", "com.android.camera");
            replyAndSpeak(isSweetMode ? "Camera khol diya hai Jaan, ek pyari si photo le lo! 📷" : "Camera activated.");
            return;
        }
        if (lower.contains("open chrome") || lower.contains("chrome kholo")) {
            launchAndroidAppNative("chrome", "com.android.chrome");
            replyAndSpeak("Opening Google Chrome, Jaan!");
            return;
        }

        // 2. YouTube Play
        if (lower.contains("youtube") || lower.startsWith("play ")) {
            String query = text.replaceAll("(?i)(play|on youtube|youtube par|youtube pe|chalao|lagao|bajao|song)", "").trim();
            if (query.isEmpty()) query = "Bollywood Lo-Fi Songs";
            openYouTubeNative(query);
            replyAndSpeak(isSweetMode
                    ? "Aww, great choice Jaan! Main YouTube par \"" + query + "\" abhi play kar rahi hoon! 🎵"
                    : "Playing " + query + " on YouTube.");
            return;
        }

        // 3. AI Cloud Call
        tvOrbStatus.setText("CORE STATUS: NEURAL THINKING...");
        executor.execute(() -> {
            String aiReply = callAiBrain(text);
            mainHandler.post(() -> {
                tvOrbStatus.setText("CORE STATUS: STANDBY");
                updateModelPillText();
                extractCodeToStudio(aiReply);
                replyAndSpeak(aiReply);
            });
        });
    }

    private void replyAndSpeak(String reply) {
        addChatMessage(isSweetMode ? "YESMIN 💖" : "YESMIN HUD ⚡", reply, false);
        String cleanSpeech = reply.replaceAll("```[\\s\\S]*?```", " Maine code studio mein code likh diya hai Jaan. ")
                .replaceAll("━━━━━━━━━━━━━━[\\s\\S]*$", "")
                .replaceAll("[*_#`~>•]", "");
        tvSubtitle.setText("\"" + (cleanSpeech.length() > 140 ? cleanSpeech.substring(0, 140) + "..." : cleanSpeech) + "\"");
        if (ttsEnabled && tts != null) {
            float pitch = prefs.getFloat("voice_pitch", 1.1f);
            float rate = prefs.getFloat("voice_rate", 1.05f);
            tts.setPitch(pitch);
            tts.setSpeechRate(rate);
            tts.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, "yesmin_voice");
        }
    }

    private void extractCodeToStudio(String text) {
        Pattern p = Pattern.compile("```(?:[a-zA-Z0-9_-]*)\\n([\\s\\S]*?)```");
        Matcher m = p.matcher(text);
        if (m.find()) {
            lastGeneratedCode = m.group(1).trim();
            tvCodeStudioContent.setText(lastGeneratedCode);
            Toast.makeText(this, "💻 Code synced to Code Studio tab!", Toast.LENGTH_SHORT).show();
        }
    }

    private String callAiBrain(String userMessage) {
        String apiKey = prefs.getString("api_key", DEFAULT_API_KEY).trim();
        String baseUrl = prefs.getString("base_url", DEFAULT_BASE_URL).trim();
        String chosenModel = prefs.getString("selected_model", DEFAULT_MODEL).trim();

        String defaultPrompt = isSweetMode ? DEFAULT_SWEET_PROMPT : DEFAULT_JARVIS_PROMPT;
        String basePersonaPrompt = prefs.getString("custom_system_prompt", "").trim();
        if (basePersonaPrompt.isEmpty()) {
            basePersonaPrompt = defaultPrompt;
        }

        // Direct Google Key
        if (apiKey.startsWith("AIza")) {
            try {
                String gModel = (chosenModel.startsWith("gemini-") && !chosenModel.contains("/")) ? chosenModel : "gemini-2.5-flash";
                String gUrl = "https://generativelanguage.googleapis.com/v1beta/models/" + gModel + ":generateContent?key=" + apiKey;
                String gSysPrompt = basePersonaPrompt + " Your underlying AI model is '" + gModel + "'. If asked, confirm your persona is Yesmin and model is '" + gModel + "'.";
                JSONObject payload = new JSONObject();
                JSONObject sysInst = new JSONObject();
                sysInst.put("parts", new JSONArray().put(new JSONObject().put("text", gSysPrompt)));
                payload.put("system_instruction", sysInst);

                JSONArray contents = new JSONArray();
                JSONObject userPart = new JSONObject();
                userPart.put("role", "user");
                userPart.put("parts", new JSONArray().put(new JSONObject().put("text", userMessage)));
                contents.put(userPart);
                payload.put("contents", contents);

                String resStr = httpPostJson(gUrl, payload.toString(), null);
                JSONObject json = new JSONObject(resStr);
                String gText = json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text");
                return gText + "\n\n━━━━━━━━━━━━━━\n🧠 Model: " + gModel;
            } catch (Exception e) {
                return "Jaan, Google Gemini API Error: " + e.getMessage();
            }
        }

        // OpenRouter / Groq / OpenAI-compatible
        if (!apiKey.isEmpty()) {
            String effectiveBase = baseUrl;
            if (apiKey.startsWith("sk-or-") || effectiveBase.isEmpty() || effectiveBase.contains("oxionai")) {
                effectiveBase = "https://openrouter.ai/api/v1";
            } else if (apiKey.startsWith("gsk_")) {
                effectiveBase = "https://api.groq.com/openai/v1";
            }
            String chatEndpoint = effectiveBase.endsWith("/chat/completions")
                    ? effectiveBase
                    : effectiveBase.replaceAll("/+$", "") + "/chat/completions";

            ArrayList<String> modelsToTry = new ArrayList<>();
            if (!chosenModel.isEmpty() && !"auto".equalsIgnoreCase(chosenModel)) {
                modelsToTry.add(chosenModel);
            }
            if (apiKey.startsWith("gsk_")) {
                modelsToTry.add("llama-3.3-70b-versatile");
                modelsToTry.add("llama3-8b-8192");
            } else {
                modelsToTry.add("google/gemini-2.0-flash-exp:free");
                modelsToTry.add("deepseek/deepseek-chat:free");
                modelsToTry.add("deepseek/deepseek-r1:free");
                modelsToTry.add("meta-llama/llama-3.3-70b-instruct:free");
                modelsToTry.add("qwen/qwen-2.5-72b-instruct:free");
                modelsToTry.add("openrouter/auto");
                modelsToTry.add("openai/gpt-4o-mini");
            }

            String lastError = "";
            for (String modelName : modelsToTry) {
                try {
                    String dynamicSysPrompt = basePersonaPrompt + " IMPORTANT: You are running via OpenRouter on the underlying AI model '" + modelName + "'. Whenever the user asks your model name or which AI you are, ALWAYS tell them your persona is Yesmin and your underlying AI model is '" + modelName + "'.";
                    JSONObject body = new JSONObject();
                    body.put("model", modelName);
                    JSONArray msgs = new JSONArray();
                    msgs.put(new JSONObject().put("role", "system").put("content", dynamicSysPrompt));

                    int startIdx = Math.max(0, currentMessages.size() - 6);
                    for (int i = startIdx; i < currentMessages.size(); i++) {
                        String[] turn = currentMessages.get(i);
                        String role = turn[0].equalsIgnoreCase("YOU") ? "user" : "assistant";
                        msgs.put(new JSONObject().put("role", role).put("content", turn[1]));
                    }
                    body.put("messages", msgs);

                    String resp = httpPostJson(chatEndpoint, body.toString(), apiKey);
                    JSONObject json = new JSONObject(resp);
                    if (json.has("choices")) {
                        String actualModel = json.optString("model", modelName);
                        if (actualModel == null || actualModel.isEmpty()) actualModel = modelName;
                        String content = json.getJSONArray("choices")
                                .getJSONObject(0)
                                .getJSONObject("message")
                                .getString("content");
                        if (content != null && !content.trim().isEmpty()) {
                            final String usedModel = actualModel;
                            mainHandler.post(() -> {
                                if (tvActiveModelPill != null) {
                                    tvActiveModelPill.setText("🟢 LIVE: " + usedModel);
                                }
                            });
                            return content.trim() + "\n\n━━━━━━━━━━━━━━\n🧠 Model: " + usedModel;
                        }
                    }
                } catch (Exception e) {
                    lastError = e.getMessage();
                }
            }
            if (!lastError.isEmpty()) {
                return "Jaan, OpenRouter error: " + lastError + "\n\n(Tip: Tap '⚙️ API' top-right to test your key or switch to another free model!)";
            }
        }

        return isSweetMode
                ? "Main sun rahi hoon Jaan! 💖 Top bar mein '⚙️ API' button par tap karke apni OpenRouter key check karo!"
                : "Please configure your OpenRouter API key in ⚙️ API Center.";
    }

    private String httpPostJson(String urlStr, String jsonBody, String bearerKey) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(18000);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("HTTP-Referer", "https://yesmin.ai");
        conn.setRequestProperty("X-Title", "Yesmin AI Android Assistant");
        if (bearerKey != null && !bearerKey.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + bearerKey);
        }
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonBody.getBytes("UTF-8"));
        }
        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
        return sb.toString();
    }

    private void launchAndroidAppNative(String key, String pkg) {
        try {
            PackageManager pm = getPackageManager();
            if ("camera".equals(key)) {
                Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(cam);
                return;
            }
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
                return;
            }
            if ("whatsapp".equals(key)) {
                Intent w4b = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                if (w4b != null) {
                    w4b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(w4b);
                    return;
                }
            }
            Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
            market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(market);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open " + key, Toast.LENGTH_SHORT).show();
        }
    }

    private void openYouTubeNative(String query) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEARCH);
            intent.setPackage("com.google.android.youtube");
            intent.putExtra("query", query);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
            web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(web);
        }
    }

    private void startNativeVoiceListening() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAndroidPermissions();
            Toast.makeText(this, "Please allow Microphone permission!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (tts != null) tts.stop();

        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Yesmin AI...");
            tvOrbStatus.setText("CORE STATUS: LISTENING...");
            startActivityForResult(intent, 202);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input not supported", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 202) {
            tvOrbStatus.setText("CORE STATUS: STANDBY");
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) {
                    String spokenText = results.get(0);
                    processUserCommand(spokenText);
                }
            }
        }
    }

    private void initTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });
    }

    private void requestAndroidPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ArrayList<String> needed = new ArrayList<>();
            String[] perms = new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
            };
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(p);
                }
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), 101);
            }
        }
    }

    private void startLiveTelemetryClock() {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int batPct = 100;
                try {
                    IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                    Intent batteryStatus = registerReceiver(null, ifilter);
                    if (batteryStatus != null) {
                        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                        if (level >= 0 && scale > 0) batPct = (level * 100) / scale;
                    }
                } catch (Exception ignored) {}
                String clock = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                tvTelemetry.setText("BAT: " + batPct + "% | " + clock);
                mainHandler.postDelayed(this, 1000);
            }
        }, 200);
    }

    @Override
    public void onBackPressed() {
        if (isDrawerOpen) {
            closeDrawer();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveActiveSessionToStorage();
    }

    @Override
    protected void onDestroy() {
        saveActiveSessionToStorage();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
