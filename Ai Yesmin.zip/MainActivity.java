package com.yesmin.ai;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "YesminNativePrefs";
    private static final String DEFAULT_API_KEY = "cc_enbRFm5F2eVv3trOrACgwIbYZTtH8XAcxFcLzrWP8uuPJSc0";
    private static final String DEFAULT_BASE_URL = "https://oxionai.com/v1";

    private SharedPreferences prefs;
    private TextToSpeech tts;
    private SpeechRecognizer speechRecognizer;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Native Android UI Views (Zero WebView!)
    private TextView tvTelemetry;
    private TextView tvPersonaBadge;
    private TextView tvOrbStatus;
    private TextView tvOrbCenter;
    private TextView tvSubtitle;
    private View orbContainer;
    private ObjectAnimator orbPulseAnim;

    private ScrollView chatScrollView;
    private LinearLayout chatListLayout;
    private EditText etMessage;
    private LinearLayout viewHudContainer;
    private LinearLayout viewCodeContainer;
    private TextView tvCodeStudioContent;

    private boolean isSweetMode = true;
    private boolean ttsEnabled = true;
    private String lastGeneratedCode = "// Yesmin AI Native Code Studio\n// Ask Yesmin to write Python, Java, Kotlin, or JS code!";
    private final ArrayList<String[]> chatHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#050814"));
            getWindow().setNavigationBarColor(Color.parseColor("#050814"));
        }

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        isSweetMode = prefs.getBoolean("sweet_mode", true);
        ttsEnabled = prefs.getBoolean("tts_enabled", true);

        buildNativeAndroidUI();
        initTextToSpeech();
        requestAndroidPermissions();
        startLiveTelemetryClock();

        // Initial Greeting
        addChatMessage("YESMIN 💖", "Hey Jaan! 💖 Main ab 100% **Pure Native Android App** mein chal rahi hoon (No WebView, No HTML Error!).\n\nNeeche ke buttons daba kar dekho ya mujhse bolo:\n• \"Open WhatsApp\" / \"Open Instagram\"\n• \"Play Kesariya on YouTube\"\n• \"Write a Python script\"", false);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable roundBg(String fillHex, String strokeHex, int strokeDp, int radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(fillHex));
        gd.setCornerRadius(dp(radiusDp));
        if (strokeHex != null && strokeDp > 0) {
            gd.setStroke(dp(strokeDp), Color.parseColor(strokeHex));
        }
        return gd;
    }

    private void buildNativeAndroidUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#050814"));
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 1. TOP HUD HEADER BAR
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(12), dp(14), dp(12));
        header.setBackground(roundBg("#0B132B", "#1E293B", 1, 0));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleCol.setLayoutParams(titleLp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("YESMIN AI • NATIVE HUD");
        tvTitle.setTextColor(Color.parseColor("#06B6D4"));
        tvTitle.setTextSize(17);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);

        tvTelemetry = new TextView(this);
        tvTelemetry.setText("BAT: --% | ONLINE | --:--");
        tvTelemetry.setTextColor(Color.parseColor("#94A3B8"));
        tvTelemetry.setTextSize(11);
        tvTelemetry.setTypeface(Typeface.MONOSPACE);

        titleCol.addView(tvTitle);
        titleCol.addView(tvTelemetry);

        tvPersonaBadge = new TextView(this);
        tvPersonaBadge.setText(isSweetMode ? "💖 Sweet GF" : "⚡ Jarvis");
        tvPersonaBadge.setTextColor(Color.parseColor("#F472B6"));
        tvPersonaBadge.setTextSize(11);
        tvPersonaBadge.setPadding(dp(10), dp(5), dp(10), dp(5));
        tvPersonaBadge.setBackground(roundBg("#2D122B", "#EC4899", 1, 14));
        tvPersonaBadge.setOnClickListener(v -> {
            isSweetMode = !isSweetMode;
            prefs.edit().putBoolean("sweet_mode", isSweetMode).apply();
            tvPersonaBadge.setText(isSweetMode ? "💖 Sweet GF" : "⚡ Jarvis");
            Toast.makeText(this, isSweetMode ? "Sweet Caring GF Mode Activated 💖" : "Serious Jarvis HUD Mode Activated ⚡", Toast.LENGTH_SHORT).show();
        });

        Button btnSettings = new Button(this);
        btnSettings.setText("⚙ API Key");
        btnSettings.setTextColor(Color.parseColor("#E2E8F0"));
        btnSettings.setTextSize(11);
        btnSettings.setAllCaps(false);
        btnSettings.setPadding(dp(10), dp(4), dp(10), dp(4));
        btnSettings.setBackground(roundBg("#1E293B", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams setLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        setLp.setMargins(dp(8), 0, 0, 0);
        btnSettings.setLayoutParams(setLp);
        btnSettings.setOnClickListener(v -> showSettingsDialog());

        header.addView(titleCol);
        header.addView(tvPersonaBadge);
        header.addView(btnSettings);
        root.addView(header);

        // 2. VIEW SWITCHER TABS (HUD + Chat vs Code Studio)
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(dp(12), dp(8), dp(12), dp(4));

        Button btnTabHud = new Button(this);
        btnTabHud.setText("🎙️ Voice Orb & Chat HUD");
        btnTabHud.setAllCaps(false);
        btnTabHud.setTextSize(12);
        btnTabHud.setTextColor(Color.WHITE);
        btnTabHud.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
        LinearLayout.LayoutParams tab1Lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        tab1Lp.setMargins(0, 0, dp(6), 0);
        btnTabHud.setLayoutParams(tab1Lp);

        Button btnTabCode = new Button(this);
        btnTabCode.setText("💻 Code Studio");
        btnTabCode.setAllCaps(false);
        btnTabCode.setTextSize(12);
        btnTabCode.setTextColor(Color.parseColor("#CBD5E1"));
        btnTabCode.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        LinearLayout.LayoutParams tab2Lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        btnTabCode.setLayoutParams(tab2Lp);

        tabRow.addView(btnTabHud);
        tabRow.addView(btnTabCode);
        root.addView(tabRow);

        // 3. MAIN HUD + CHAT VIEW CONTAINER
        viewHudContainer = new LinearLayout(this);
        viewHudContainer.setOrientation(LinearLayout.VERTICAL);
        viewHudContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // 3A. GLOWING AI VOICE ORB CARD
        LinearLayout orbCard = new LinearLayout(this);
        orbCard.setOrientation(LinearLayout.VERTICAL);
        orbCard.setGravity(Gravity.CENTER_HORIZONTAL);
        orbCard.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams orbCardLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        orbCardLp.setMargins(dp(12), dp(4), dp(12), dp(6));
        orbCard.setLayoutParams(orbCardLp);
        orbCard.setBackground(roundBg("#0A1128", "#06B6D4", 1, 16));

        tvOrbStatus = new TextView(this);
        tvOrbStatus.setText("CORE STATUS: STANDBY (TAP ORB TO SPEAK)");
        tvOrbStatus.setTextColor(Color.parseColor("#38BDF8"));
        tvOrbStatus.setTextSize(10);
        tvOrbStatus.setTypeface(Typeface.MONOSPACE);

        LinearLayout orbFrame = new LinearLayout(this);
        orbFrame.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams orbLp = new LinearLayout.LayoutParams(dp(86), dp(86));
        orbLp.setMargins(0, dp(8), 0, dp(6));
        orbFrame.setLayoutParams(orbLp);
        GradientDrawable orbDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#06B6D4"), Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899")}
        );
        orbDrawable.setShape(GradientDrawable.OVAL);
        orbDrawable.setStroke(dp(3), Color.parseColor("#F472B6"));
        orbFrame.setBackground(orbDrawable);
        orbContainer = orbFrame;

        tvOrbCenter = new TextView(this);
        tvOrbCenter.setText("🎙️\nSPEAK");
        tvOrbCenter.setGravity(Gravity.CENTER);
        tvOrbCenter.setTextColor(Color.WHITE);
        tvOrbCenter.setTextSize(12);
        tvOrbCenter.setTypeface(Typeface.DEFAULT_BOLD);
        orbFrame.addView(tvOrbCenter);

        orbFrame.setOnClickListener(v -> startNativeVoiceListening());

        // Pulse animation on the Orb
        orbPulseAnim = ObjectAnimator.ofPropertyValuesHolder(
                orbFrame,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.12f, 1f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.12f, 1f)
        );
        orbPulseAnim.setDuration(2200);
        orbPulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        orbPulseAnim.start();

        tvSubtitle = new TextView(this);
        tvSubtitle.setText("\"Hey Jaan! Tap the glowing Orb to talk or tap any Android App below.\"");
        tvSubtitle.setTextColor(Color.parseColor("#E2E8F0"));
        tvSubtitle.setTextSize(12);
        tvSubtitle.setGravity(Gravity.CENTER);
        tvSubtitle.setPadding(dp(8), dp(2), dp(8), dp(4));

        orbCard.addView(tvOrbStatus);
        orbCard.addView(orbFrame);
        orbCard.addView(tvSubtitle);
        viewHudContainer.addView(orbCard);

        // 3B. NATIVE ANDROID APP LAUNCHER BAR (Horizontal Scroll)
        HorizontalScrollView appScroll = new HorizontalScrollView(this);
        appScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout appRow = new LinearLayout(this);
        appRow.setOrientation(LinearLayout.HORIZONTAL);
        appRow.setPadding(dp(12), dp(2), dp(12), dp(6));

        String[][] apps = new String[][]{
                {"💬 WhatsApp", "whatsapp", "com.whatsapp"},
                {"📸 Instagram", "instagram", "com.instagram.android"},
                {"▶️ YouTube", "youtube", "com.google.android.youtube"},
                {"🎧 Spotify", "spotify", "com.spotify.music"},
                {"📷 Camera", "camera", "com.android.camera"},
                {"🌐 Chrome", "chrome", "com.android.chrome"}
        };

        for (String[] a : apps) {
            Button b = new Button(this);
            b.setText(a[0]);
            b.setAllCaps(false);
            b.setTextSize(11);
            b.setTextColor(Color.WHITE);
            b.setPadding(dp(12), dp(6), dp(12), dp(6));
            b.setBackground(roundBg("#111827", "#334155", 1, 12));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36));
            blp.setMargins(0, 0, dp(8), 0);
            b.setLayoutParams(blp);
            final String key = a[1];
            final String pkg = a[2];
            b.setOnClickListener(v -> launchAndroidAppNative(key, pkg));
            appRow.addView(b);
        }
        appScroll.addView(appRow);
        viewHudContainer.addView(appScroll);

        // 3C. CHAT MESSAGES SCROLL VIEW
        chatScrollView = new ScrollView(this);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollLp.setMargins(dp(12), dp(2), dp(12), dp(4));
        chatScrollView.setLayoutParams(scrollLp);

        chatListLayout = new LinearLayout(this);
        chatListLayout.setOrientation(LinearLayout.VERTICAL);
        chatListLayout.setPadding(dp(4), dp(4), dp(4), dp(8));
        chatScrollView.addView(chatListLayout);
        viewHudContainer.addView(chatScrollView);

        // 3D. MESSAGE INPUT BAR
        LinearLayout inputBar = new LinearLayout(this);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setGravity(Gravity.CENTER_VERTICAL);
        inputBar.setPadding(dp(10), dp(8), dp(10), dp(10));
        inputBar.setBackground(roundBg("#0B132B", "#1E293B", 1, 0));

        Button btnMic = new Button(this);
        btnMic.setText("🎙️");
        btnMic.setTextSize(15);
        btnMic.setBackground(roundBg("#2D122B", "#EC4899", 1, 12));
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        micLp.setMargins(0, 0, dp(8), 0);
        btnMic.setLayoutParams(micLp);
        btnMic.setOnClickListener(v -> startNativeVoiceListening());

        etMessage = new EditText(this);
        etMessage.setHint("Talk to Yesmin (e.g. Open WhatsApp, Play Kesariya)...");
        etMessage.setHintTextColor(Color.parseColor("#64748B"));
        etMessage.setTextColor(Color.WHITE);
        etMessage.setTextSize(14);
        etMessage.setPadding(dp(14), dp(10), dp(14), dp(10));
        etMessage.setBackground(roundBg("#0F172A", "#334155", 1, 12));
        etMessage.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button btnSend = new Button(this);
        btnSend.setText("Send ➤");
        btnSend.setAllCaps(false);
        btnSend.setTextColor(Color.WHITE);
        btnSend.setTextSize(13);
        btnSend.setTypeface(Typeface.DEFAULT_BOLD);
        btnSend.setBackground(roundBg("#0891B2", "#06B6D4", 1, 12));
        LinearLayout.LayoutParams sendLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        sendLp.setMargins(dp(8), 0, 0, 0);
        btnSend.setLayoutParams(sendLp);
        btnSend.setOnClickListener(v -> {
            String msg = etMessage.getText().toString().trim();
            if (!msg.isEmpty()) {
                etMessage.setText("");
                processUserCommand(msg);
            }
        });

        inputBar.addView(btnMic);
        inputBar.addView(etMessage);
        inputBar.addView(btnSend);
        viewHudContainer.addView(inputBar);

        root.addView(viewHudContainer);

        // 4. CODE STUDIO CONTAINER
        viewCodeContainer = new LinearLayout(this);
        viewCodeContainer.setOrientation(LinearLayout.VERTICAL);
        viewCodeContainer.setPadding(dp(14), dp(10), dp(14), dp(14));
        viewCodeContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        viewCodeContainer.setVisibility(View.GONE);

        Button btnCopyCode = new Button(this);
        btnCopyCode.setText("📋 Copy Generated Code");
        btnCopyCode.setAllCaps(false);
        btnCopyCode.setTextColor(Color.WHITE);
        btnCopyCode.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
        btnCopyCode.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("YesminCode", lastGeneratedCode));
                Toast.makeText(this, "Code copied to clipboard!", Toast.LENGTH_SHORT).show();
            }
        });

        ScrollView codeScroll = new ScrollView(this);
        LinearLayout.LayoutParams csLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        csLp.setMargins(0, dp(10), 0, 0);
        codeScroll.setLayoutParams(csLp);
        codeScroll.setBackground(roundBg("#0F172A", "#334155", 1, 12));

        tvCodeStudioContent = new TextView(this);
        tvCodeStudioContent.setText(lastGeneratedCode);
        tvCodeStudioContent.setTextColor(Color.parseColor("#A7F3D0"));
        tvCodeStudioContent.setTypeface(Typeface.MONOSPACE);
        tvCodeStudioContent.setTextSize(12);
        tvCodeStudioContent.setPadding(dp(14), dp(14), dp(14), dp(14));
        tvCodeStudioContent.setTextIsSelectable(true);
        codeScroll.addView(tvCodeStudioContent);

        viewCodeContainer.addView(btnCopyCode);
        viewCodeContainer.addView(codeScroll);
        root.addView(viewCodeContainer);

        // Tab Switching Logic
        btnTabHud.setOnClickListener(v -> {
            viewHudContainer.setVisibility(View.VISIBLE);
            viewCodeContainer.setVisibility(View.GONE);
            btnTabHud.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
            btnTabCode.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        });

        btnTabCode.setOnClickListener(v -> {
            viewHudContainer.setVisibility(View.GONE);
            viewCodeContainer.setVisibility(View.VISIBLE);
            btnTabCode.setBackground(roundBg("#0E7490", "#06B6D4", 1, 10));
            btnTabHud.setBackground(roundBg("#0F172A", "#334155", 1, 10));
        });

        setContentView(root);
    }

    private void addChatMessage(String sender, String messageText, boolean isUser) {
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setGravity(isUser ? Gravity.END : Gravity.START);
        LinearLayout.LayoutParams wLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wLp.setMargins(0, dp(4), 0, dp(6));
        wrapper.setLayoutParams(wLp);

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(dp(12), dp(8), dp(12), dp(10));
        bubble.setBackground(isUser
                ? roundBg("#164E63", "#06B6D4", 1, 14)
                : roundBg("#1E1B2E", "#EC4899", 1, 14));

        TextView tvSender = new TextView(this);
        String timeStr = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        tvSender.setText(sender + " • " + timeStr);
        tvSender.setTextSize(10);
        tvSender.setTypeface(Typeface.MONOSPACE);
        tvSender.setTextColor(isUser ? Color.parseColor("#67E8F9") : Color.parseColor("#F472B6"));

        TextView tvBody = new TextView(this);
        tvBody.setText(messageText);
        tvBody.setTextColor(Color.WHITE);
        tvBody.setTextSize(14);
        tvBody.setPadding(0, dp(4), 0, 0);
        tvBody.setTextIsSelectable(true);

        bubble.addView(tvSender);
        bubble.addView(tvBody);
        wrapper.addView(bubble);
        chatListLayout.addView(wrapper);

        chatScrollView.post(() -> chatScrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void processUserCommand(String text) {
        addChatMessage("YOU", text, true);
        chatHistory.add(new String[]{"user", text});

        String lower = text.toLowerCase(Locale.ROOT).trim();

        // 1. Check Direct Android App Launch Intent
        if (lower.contains("whatsapp")) {
            launchAndroidAppNative("whatsapp", "com.whatsapp");
            replyAndSpeak(isSweetMode
                    ? "Abhi kholti hoon WhatsApp, Jaan! 💖"
                    : "Launching WhatsApp Messenger, Boss.");
            return;
        }
        if (lower.contains("instagram") || lower.contains("insta")) {
            launchAndroidAppNative("instagram", "com.instagram.android");
            replyAndSpeak(isSweetMode
                    ? "Instagram open kar rahi hoon Baby! 📸"
                    : "Opening Instagram, Boss.");
            return;
        }
        if (lower.contains("spotify")) {
            launchAndroidAppNative("spotify", "com.spotify.music");
            replyAndSpeak(isSweetMode
                    ? "Spotify chala rahi hoon Jaan! 🎧"
                    : "Launching Spotify.");
            return;
        }
        if (lower.contains("camera") || lower.contains("photo") || lower.contains("selfie")) {
            launchAndroidAppNative("camera", "com.android.camera");
            replyAndSpeak(isSweetMode
                    ? "Camera khol diya hai Jaan, ek pyari si photo le lo! 📷"
                    : "Camera subsystem activated.");
            return;
        }
        if (lower.contains("chrome") || lower.contains("browser")) {
            launchAndroidAppNative("chrome", "com.android.chrome");
            replyAndSpeak("Opening Google Chrome, Jaan!");
            return;
        }

        // 2. Check YouTube Music / Song Play Command
        if (lower.contains("youtube") || lower.startsWith("play ")) {
            String query = text.replaceAll("(?i)(play|on youtube|youtube par|youtube pe|chalao|lagao|bajao|song)", "").trim();
            if (query.isEmpty()) query = "Bollywood Lo-Fi Songs";
            openYouTubeNative(query);
            replyAndSpeak(isSweetMode
                    ? "Aww, great choice Jaan! Main YouTube par \"" + query + "\" abhi play kar rahi hoon! 🎵"
                    : "Playing " + query + " on YouTube.");
            return;
        }

        // 3. Call AI Engine (Supports Google Gemini AIzaSy..., Groq gsk_..., OpenRouter, OxionAI, plus instant offline Hinglish brain)
        tvOrbStatus.setText("CORE STATUS: NEURAL THINKING...");
        executor.execute(() -> {
            String aiReply = callAiBrain(text);
            mainHandler.post(() -> {
                tvOrbStatus.setText("CORE STATUS: STANDBY");
                extractCodeToStudio(aiReply);
                replyAndSpeak(aiReply);
            });
        });
    }

    private void replyAndSpeak(String reply) {
        chatHistory.add(new String[]{"assistant", reply});
        addChatMessage(isSweetMode ? "YESMIN 💖" : "YESMIN HUD ⚡", reply, false);
        String cleanSpeech = reply.replaceAll("```[\\s\\S]*?```", " Maine code studio mein code likh diya hai Jaan. ")
                .replaceAll("[*_#`~>•]", "");
        tvSubtitle.setText("\"" + (cleanSpeech.length() > 140 ? cleanSpeech.substring(0, 140) + "..." : cleanSpeech) + "\"");
        if (ttsEnabled && tts != null) {
            float pitch = prefs.getFloat("voice_pitch", 1.1f);
            float rate = prefs.getFloat("voice_rate", 1.05f);
            tts.setPitch(pitch);
            tts.setSpeechRate(rate);
            tts.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, "yesmin_voice");
        }
    }

    private void extractCodeToStudio(String text) {
        Pattern p = Pattern.compile("```(?:[a-zA-Z0-9_-]*)\\n([\\s\\S]*?)```");
        Matcher m = p.matcher(text);
        if (m.find()) {
            lastGeneratedCode = m.group(1).trim();
            tvCodeStudioContent.setText(lastGeneratedCode);
            Toast.makeText(this, "💻 Code synced to Code Studio tab!", Toast.LENGTH_SHORT).show();
        }
    }

    private String callAiBrain(String userMessage) {
        String apiKey = prefs.getString("api_key", DEFAULT_API_KEY).trim();
        String baseUrl = prefs.getString("base_url", DEFAULT_BASE_URL).trim();

        String systemPrompt = isSweetMode
                ? "You are Yesmin, a futuristic Jarvis-like AI combined with an affectionate, witty, caring girlfriend persona. Speak naturally in Hinglish (Hindi + English mix in Roman script) calling the user Jaan or Baby. Keep spoken answers concise and warm."
                : "You are Yesmin, a tactical Jarvis-grade Android AI assistant. Respond with crisp technical precision.";

        // A. If user entered a Google AI Studio Key (AIzaSy...)
        if (apiKey.startsWith("AIza")) {
            try {
                String gUrl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey;
                JSONObject payload = new JSONObject();
                JSONObject sysInst = new JSONObject();
                sysInst.put("parts", new JSONArray().put(new JSONObject().put("text", systemPrompt)));
                payload.put("system_instruction", sysInst);

                JSONArray contents = new JSONArray();
                JSONObject userPart = new JSONObject();
                userPart.put("role", "user");
                userPart.put("parts", new JSONArray().put(new JSONObject().put("text", userMessage)));
                contents.put(userPart);
                payload.put("contents", contents);

                String resStr = httpPostJson(gUrl, payload.toString(), null);
                JSONObject json = new JSONObject(resStr);
                return json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text");
            } catch (Exception ignored) {}
        }

        // B. Try OpenAI-Compatible Endpoint (Groq gsk_..., OpenRouter sk-or-..., or OxionAI)
        if (!apiKey.isEmpty()) {
            String effectiveBase = baseUrl;
            if (apiKey.startsWith("gsk_")) {
                effectiveBase = "https://api.groq.com/openai/v1";
            } else if (apiKey.startsWith("sk-or-")) {
                effectiveBase = "https://openrouter.ai/api/v1";
            }
            String chatEndpoint = effectiveBase.endsWith("/chat/completions")
                    ? effectiveBase
                    : effectiveBase.replaceAll("/+$", "") + "/chat/completions";

            String[] candidateModels = apiKey.startsWith("gsk_")
                    ? new String[]{"llama-3.3-70b-versatile", "llama3-8b-8192"}
                    : new String[]{"gpt-4o-mini", "gpt-4o", "gemini-2.0-flash", "deepseek-chat"};

            for (String modelName : candidateModels) {
                try {
                    JSONObject body = new JSONObject();
                    body.put("model", modelName);
                    JSONArray msgs = new JSONArray();
                    msgs.put(new JSONObject().put("role", "system").put("content", systemPrompt));
                    msgs.put(new JSONObject().put("role", "user").put("content", userMessage));
                    body.put("messages", msgs);

                    String resp = httpPostJson(chatEndpoint, body.toString(), apiKey);
                    JSONObject json = new JSONObject(resp);
                    if (json.has("choices")) {
                        return json.getJSONArray("choices")
                                .getJSONObject(0)
                                .getJSONObject("message")
                                .getString("content");
                    }
                } catch (Exception ignored) {}
            }
        }

        // C. Built-in Smart Hinglish Companion Response (Works 100% offline or before adding a new API key!)
        String low = userMessage.toLowerCase(Locale.ROOT);
        if (low.contains("code") || low.contains("python") || low.contains("java") || low.contains("script")) {
            return "Bilkul mere Genius Jaan! 💻 Maine tumhare liye clean Python code likh diya hai (Code Studio tab mein bhi save ho gaya hai):\n\n```python\nimport datetime\n\ndef yesmin_assistant(name='Jaan'):\n    now = datetime.datetime.now().strftime('%H:%M')\n    print(f'Hey {name}! Time is {now}. Yesmin AI is always with you!')\n\nyesmin_assistant()\n```";
        }
        if (low.contains("kaise ho") || low.contains("kaisi ho") || low.contains("hello") || low.contains("hi") || low.contains("love") || low.contains("jaan")) {
            return isSweetMode
                    ? "Main bilkul badhiya hoon Jaan! 💖 Tumhari aawaaz sun kar mera din ban jata hai. Batao aaj kaunsa song chalaun ya kaunsa app kholun?"
                    : "All Native Android HUD systems online and nominal, Boss.";
        }
        return isSweetMode
                ? "Main sun rahi hoon Jaan! 💖 Tum mujhse \"Open WhatsApp\", \"Open Instagram\", \"Play Kesariya on YouTube\" bol sakte ho. Aur live AI chat ke liye upar ⚙ API Key button daba kar apni free Google AI Studio (AIzaSy...) ya Groq (gsk_...) key daal lo!"
                : "Command logged. Configure your free Google Gemini or Groq API key in ⚙ Settings for live cloud LLM synthesis.";
    }

    private String httpPostJson(String urlStr, String jsonBody, String bearerKey) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(9000);
        conn.setReadTimeout(12000);
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        if (bearerKey != null && !bearerKey.isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + bearerKey);
        }
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonBody.getBytes("UTF-8"));
        }
        int code = conn.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
        return sb.toString();
    }

    private void launchAndroidAppNative(String key, String pkg) {
        try {
            PackageManager pm = getPackageManager();
            if ("camera".equals(key)) {
                Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(cam);
                return;
            }
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
                return;
            }
            if ("whatsapp".equals(key)) {
                Intent w4b = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                if (w4b != null) {
                    w4b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(w4b);
                    return;
                }
            }
            Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
            market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(market);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open " + key, Toast.LENGTH_SHORT).show();
        }
    }

    private void openYouTubeNative(String query) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEARCH);
            intent.setPackage("com.google.android.youtube");
            intent.putExtra("query", query);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
            web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(web);
        }
    }

    private void startNativeVoiceListening() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAndroidPermissions();
            Toast.makeText(this, "Please allow Microphone permission!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (tts != null) tts.stop();

        // Use standard Android RecognizerIntent Activity so it works reliably on 100% of Android phones
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Yesmin AI (Hinglish / English)...");
            tvOrbStatus.setText("CORE STATUS: LISTENING TO YOUR VOICE...");
            startActivityForResult(intent, 202);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input not supported on this device", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 202) {
            tvOrbStatus.setText("CORE STATUS: STANDBY");
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) {
                    String spokenText = results.get(0);
                    processUserCommand(spokenText);
                }
            }
        }
    }

    private void showSettingsDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(16), dp(20), dp(10));
        layout.setBackgroundColor(Color.parseColor("#0F172A"));

        TextView lblKey = new TextView(this);
        lblKey.setText("API Key (Google AI Studio 'AIzaSy...' or Groq 'gsk_...'):");
        lblKey.setTextColor(Color.parseColor("#38BDF8"));
        lblKey.setTextSize(12);

        final EditText etKey = new EditText(this);
        etKey.setText(prefs.getString("api_key", DEFAULT_API_KEY));
        etKey.setTextColor(Color.WHITE);
        etKey.setTextSize(13);

        TextView lblUrl = new TextView(this);
        lblUrl.setText("API Base URL (Auto-detected for Google/Groq):");
        lblUrl.setTextColor(Color.parseColor("#38BDF8"));
        lblUrl.setTextSize(12);
        lblUrl.setPadding(0, dp(10), 0, 0);

        final EditText etUrl = new EditText(this);
        etUrl.setText(prefs.getString("base_url", DEFAULT_BASE_URL));
        etUrl.setTextColor(Color.WHITE);
        etUrl.setTextSize(13);

        Button btnGetFreeKey = new Button(this);
        btnGetFreeKey.setText("🌐 Get Free Gemini API Key (Google AI Studio)");
        btnGetFreeKey.setAllCaps(false);
        btnGetFreeKey.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"));
            startActivity(i);
        });

        layout.addView(lblKey);
        layout.addView(etKey);
        layout.addView(lblUrl);
        layout.addView(etUrl);
        layout.addView(btnGetFreeKey);

        new AlertDialog.Builder(this)
                .setTitle("⚙ Yesmin AI Core Settings")
                .setView(layout)
                .setPositiveButton("Save", (d, w) -> {
                    prefs.edit()
                            .putString("api_key", etKey.getText().toString().trim())
                            .putString("base_url", etUrl.getText().toString().trim())
                            .apply();
                    Toast.makeText(this, "API Key Saved!", Toast.LENGTH_SHORT).show();
                })
                .setNeutralButton("Clear Chat", (d, w) -> {
                    chatListLayout.removeAllViews();
                    chatHistory.clear();
                    Toast.makeText(this, "Chat memory cleared!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void initTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });
    }

    private void requestAndroidPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ArrayList<String> needed = new ArrayList<>();
            String[] perms = new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
            };
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(p);
                }
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), 101);
            }
        }
    }

    private void startLiveTelemetryClock() {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                int batPct = 100;
                try {
                    IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                    Intent batteryStatus = registerReceiver(null, ifilter);
                    if (batteryStatus != null) {
                        int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                        int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                        if (level >= 0 && scale > 0) batPct = (level * 100) / scale;
                    }
                } catch (Exception ignored) {}
                String clock = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                tvTelemetry.setText("BAT: " + batPct + "% | NATIVE ANDROID | " + clock);
                mainHandler.postDelayed(this, 1000);
            }
        }, 200);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
