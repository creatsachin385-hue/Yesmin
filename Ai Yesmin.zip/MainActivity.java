package com.yesmin.ai;

import android.Manifest;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_PERMS = 101;
    private static final int REQ_VOICE = 202;
    private static final int REQ_GOOGLE_ACCOUNT = 303;
    private static final int REQ_SHIZUKU_PERM = 404;

    private WebView webView;
    private TextToSpeech tts;
    private SharedPreferences prefs;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private BroadcastReceiver powerReceiver;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#080B14"));
            getWindow().setNavigationBarColor(Color.parseColor("#080B14"));
        }

        prefs = getSharedPreferences("YesminAgentPrefs", MODE_PRIVATE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new NativeAgentBridge(), "YesminNative");

        // Auto-grant WebRTC Camera & Mic inside WebView for Live Camera Vision Mode!
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushAgentStatusToUi();
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });

        registerChargingTriggersReceiver();
        requestRuntimePermissions();

        webView.loadDataWithBaseURL("https://yesmin.ai/", UiHtmlProvider.getHtml(), "text/html", "UTF-8", null);
    }

    private void registerChargingTriggersReceiver() {
        powerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || intent.getAction() == null) return;
                String act = intent.getAction();
                if (Intent.ACTION_POWER_CONNECTED.equals(act)) {
                    webView.post(() -> webView.evaluateJavascript("if(window.onChargingTrigger) window.onChargingTrigger('CONNECTED');", null));
                } else if (Intent.ACTION_POWER_DISCONNECTED.equals(act)) {
                    webView.post(() -> webView.evaluateJavascript("if(window.onChargingTrigger) window.onChargingTrigger('DISCONNECTED');", null));
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        registerReceiver(powerReceiver, filter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        pushAgentStatusToUi();
    }

    private void pushAgentStatusToUi() {
        if (webView == null) return;
        boolean accActive = isAccessibilityServiceEnabled();
        String shizukuState = getShizukuOrRootStatus();
        String googleEmail = prefs.getString("google_email", "");
        int bat = getBatteryPercentage();
        String js = String.format(Locale.US,
                "if(window.onNativeTelemetry) window.onNativeTelemetry(%b, '%s', '%s', %d);",
                accActive,
                shizukuState.replace("'", "\\'"),
                googleEmail.replace("'", "\\'"),
                bat
        );
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    public boolean isAccessibilityServiceEnabled() {
        if (YesminAgentService.isConnected()) return true;
        try {
            String enabledServices = Settings.Secure.getString(
                    getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            );
            if (enabledServices != null && enabledServices.contains(getPackageName())) {
                return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public boolean isShizukuInstalled() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return pi != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public String getShizukuOrRootStatus() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED) {
                    return "GRANTED (Shizuku)";
                }
            }
            if (isShizukuInstalled()) {
                return "READY (Tap to Allow)";
            }
        } catch (Throwable ignored) {}
        return "Tap to Setup";
    }

    public int getBatteryPercentage() {
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent b = registerReceiver(null, ifilter);
            if (b != null) {
                int l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int s = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (l >= 0 && s > 0) return (l * 100) / s;
            }
        } catch (Throwable ignored) {}
        return 100;
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] perms = new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
            ArrayList<String> needed = new ArrayList<>();
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(p);
                }
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
            }
        }
    }

    public class NativeAgentBridge {

        @JavascriptInterface
        public void vibrateTick() {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(28, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        v.vibrate(28);
                    }
                }
            } catch (Throwable ignored) {}
        }

        // 1. SHIZUKU PERMISSION & AUTHORIZED APPS REGISTRATION
        @JavascriptInterface
        public String requestShizukuAccess() {
            try {
                if (!isShizukuInstalled()) {
                    Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api"));
                    market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(market);
                    return "Shizuku app install nahi hai — Play Store khol diya hai!";
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED) {
                        pushAgentStatusToUi();
                        return "✅ Shizuku Access Granted Hai!";
                    }
                    mainHandler.post(() -> requestPermissions(new String[]{"moe.shizuku.manager.permission.API_V23"}, REQ_SHIZUKU_PERM));
                }
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    return "✅ Yesmin AI ab Shizuku ki 'Authorized applications' list mein dikhega! Wahan Yesmin AI ka switch ON karein.";
                }
                return "Requested Shizuku permission!";
            } catch (Throwable e) {
                return "Shizuku error: " + e.getMessage();
            }
        }

        // 2. REAL ROOT (su) PERMISSION & COMMAND EXECUTION
        @JavascriptInterface
        public String requestRootAccess() {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String out = br.readLine();
                p.waitFor();
                if (out != null && out.contains("uid=0")) {
                    return "✅ Real Root Access (uid=0) Active: " + out;
                }
                return "⚠️ Root (su) nahi mila. Accessibility Service + Shizuku se bina root ke pura phone control karein!";
            } catch (Throwable e) {
                return "⚠️ Phone Rooted nahi hai. Accessibility Service ON rakhein!";
            }
        }

        @JavascriptInterface
        public String runShellCommand(String cmd) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                int code = p.waitFor();
                if (code == 0 && sb.length() > 0) return "[Root] " + sb.toString().trim();
            } catch (Throwable ignored) {}

            try {
                Process p2 = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                BufferedReader br = new BufferedReader(new InputStreamReader(p2.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                p2.waitFor();
                return sb.toString().trim();
            } catch (Throwable e) {
                return "Shell error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void openAccessibilitySettings() {
            try {
                Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                mainHandler.post(() -> Toast.makeText(MainActivity.this,
                        "👉 'Installed apps' mein 'Yesmin AI Autonomous Agent' ko ON karein!",
                        Toast.LENGTH_LONG).show());
            } catch (Throwable ignored) {}
        }

        // 3. NORMAL PHONE CALL BY CONTACT NAME OR NUMBER (Like "Call Krishna KK" in the video!)
        @JavascriptInterface
        public String callContactByNameOrNumber(String query) {
            if (query == null || query.trim().isEmpty()) return "Jaan, kisko call karna hai naam batao?";
            String clean = query.trim();

            // If digits, call directly
            if (clean.matches(".*[0-9]{5,}.*")) {
                String num = clean.replaceAll("[^0-9+]", "");
                return placeDirectCall(num, num);
            }

            // Look up in Android Contacts
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                try {
                    Cursor cursor = getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            new String[]{
                                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                                    ContactsContract.CommonDataKinds.Phone.NUMBER
                            },
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                            new String[]{"%" + clean + "%"},
                            null
                    );
                    if (cursor != null) {
                        if (cursor.moveToFirst()) {
                            String foundName = cursor.getString(0);
                            String foundNum = cursor.getString(1);
                            cursor.close();
                            return placeDirectCall(foundName, foundNum);
                        }
                        cursor.close();
                    }
                } catch (Throwable ignored) {}
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mainHandler.post(() -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}, REQ_PERMS));
            }

            // Fallback: open dialer with query
            try {
                Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(clean)));
                dial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dial);
                return "📞 Dialer khol diya hai '" + clean + "' ke liye, Jaan!";
            } catch (Throwable e) {
                return "Call error: " + e.getMessage();
            }
        }

        private String placeDirectCall(String displayName, String phoneNumber) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phoneNumber));
                    callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(callIntent);
                    return "📞 Calling " + displayName + " (" + phoneNumber + ") right now, Jaan!";
                } else {
                    Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
                    dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(dialIntent);
                    return "📞 Dialing " + displayName + " (" + phoneNumber + "), Jaan!";
                }
            } catch (Throwable e) {
                return "Could not place call: " + e.getMessage();
            }
        }

        // 4. SEND SOS EMERGENCY ALERT
        @JavascriptInterface
        public String sendSosAlert(String phone, String customMsg) {
            if (phone == null || phone.trim().isEmpty()) return "Pehle SOS number save karo Jaan!";
            try {
                Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone.trim()));
                sms.putExtra("sms_body", customMsg != null && !customMsg.isEmpty() ? customMsg : "🚨 SOS Emergency Alert from Yesmin AI! Please help me at my current location.");
                sms.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(sms);
                return "🚨 SOS Emergency Alert triggered for " + phone;
            } catch (Throwable e) {
                return "SOS error: " + e.getMessage();
            }
        }

        // 5. PERFORM REAL AUTONOMOUS AGENT ACTIONS VIA ACCESSIBILITY SERVICE
        @JavascriptInterface
        public String executeAgentAction(String actionType, String param1, String param2) {
            YesminAgentService svc = YesminAgentService.instance;
            if ("GLOBAL".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.doGlobal(param1)) {
                    return "✅ Done Jaan! Executed: " + param1;
                }
                if (param1.equalsIgnoreCase("home")) runShellCommand("input keyevent 3");
                if (param1.equalsIgnoreCase("back")) runShellCommand("input keyevent 4");
                return "✅ Executed " + param1;
            }
            if ("CLICK_TEXT".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.clickByText(param1)) {
                    return "✅ Clicked '" + param1 + "' on screen!";
                }
                return "⚠️ '" + param1 + "' screen par nahi mila (Check if Accessibility Service is ON).";
            }
            if ("TAP_XY".equalsIgnoreCase(actionType)) {
                try {
                    float x = Float.parseFloat(param1);
                    float y = Float.parseFloat(param2);
                    if (svc != null && svc.tapXY(x, y)) return "✅ Tapped (" + (int) x + ", " + (int) y + ")";
                    runShellCommand("input tap " + (int) x + " " + (int) y);
                    return "✅ Tapped (" + (int) x + ", " + (int) y + ")";
                } catch (Throwable e) {
                    return "Invalid coordinates";
                }
            }
            if ("SCROLL_DOWN".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.swipe(500, 1550, 500, 380, 350)) {
                    return "✅ Scrolled down!";
                }
                runShellCommand("input swipe 500 1550 500 380 300");
                return "✅ Scrolled down!";
            }
            if ("SCROLL_UP".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.swipe(500, 420, 500, 1550, 350)) {
                    return "✅ Scrolled up!";
                }
                runShellCommand("input swipe 500 420 500 1550 300");
                return "✅ Scrolled up!";
            }
            if ("TYPE_TEXT".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.inputTextOnScreen(param1)) {
                    return "✅ Typed: " + param1;
                }
                String safe = param1.replace(" ", "%s");
                runShellCommand("input text \"" + safe + "\"");
                return "✅ Typed: " + param1;
            }
            if ("READ_SCREEN".equalsIgnoreCase(actionType)) {
                if (svc != null) return svc.readScreenSummary();
                return "Accessibility Service is not active yet.";
            }
            if ("LAST_NOTIF".equalsIgnoreCase(actionType)) {
                return YesminAgentService.lastNotificationText.isEmpty()
                        ? "Abhi koi naya notification record nahi hua hai Jaan."
                        : YesminAgentService.lastNotificationText;
            }
            return "Unknown action";
        }

        // 6. REAL GOOGLE ACCOUNT PICKER
        @JavascriptInterface
        public void signInWithGoogle() {
            mainHandler.post(() -> {
                try {
                    Intent intent;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        intent = AccountManager.newChooseAccountIntent(
                                null, null, new String[]{"com.google"}, null, null, null, null);
                    } else {
                        intent = AccountManager.newChooseAccountIntent(
                                null, null, new String[]{"com.google"}, false, null, null, null, null);
                    }
                    startActivityForResult(intent, REQ_GOOGLE_ACCOUNT);
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Google Account Picker: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        // 7. LAUNCH ANY ANDROID APP
        @JavascriptInterface
        public boolean launchApp(String key, String pkg) {
            try {
                String k = key != null ? key.toLowerCase().trim() : "";
                PackageManager pm = getPackageManager();
                if ("camera".equals(k)) {
                    Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                    cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(cam);
                    return true;
                }
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    return true;
                }
                if ("whatsapp".equals(k)) {
                    Intent w4b = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                    if (w4b != null) {
                        w4b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(w4b);
                        return true;
                    }
                }
                Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
                market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(market);
                return true;
            } catch (Throwable e) {
                return false;
            }
        }

        @JavascriptInterface
        public void playYouTube(String query) {
            try {
                Intent intent = new Intent(Intent.ACTION_SEARCH);
                intent.setPackage("com.google.android.youtube");
                intent.putExtra("query", query);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Throwable e) {
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
                web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(web);
            }
        }

        @JavascriptInterface
        public void startVoiceMic() {
            mainHandler.post(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo Jaan (Yesmin AI Listening)...");
                    startActivityForResult(intent, REQ_VOICE);
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Voice Mic not available", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void speak(String text) {
            if (tts != null && text != null) {
                tts.setPitch(1.1f);
                tts.setSpeechRate(1.05f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yesmin_utt");
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (list != null && !list.isEmpty()) {
                String spoken = list.get(0).replace("'", "\\'").replace("\n", " ");
                webView.evaluateJavascript("if(window.onNativeVoiceInput) window.onNativeVoiceInput('" + spoken + "');", null);
            }
        } else if (requestCode == REQ_GOOGLE_ACCOUNT && resultCode == RESULT_OK && data != null) {
            String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            if (accountName != null) {
                prefs.edit().putString("google_email", accountName).apply();
                Toast.makeText(this, "✅ Signed in with Google: " + accountName, Toast.LENGTH_LONG).show();
                pushAgentStatusToUi();
            }
        }
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("if(window.handleBackPress) window.handleBackPress();", val -> {
            if (!"true".equals(val)) {
                MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onDestroy() {
        try {
            if (powerReceiver != null) unregisterReceiver(powerReceiver);
        } catch (Throwable ignored) {}
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
