package com.yesmin.ai;

import android.Manifest;
import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    public static MainActivity activeInstance;

    private static final int REQ_PERMS = 101;
    private static final int REQ_VOICE = 202;
    private static final int REQ_GOOGLE_ACCOUNT = 303;
    private static final int REQ_SHIZUKU_PERM = 404;

    private WebView webView;
    private TextToSpeech tts;
    private SharedPreferences prefs;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private BroadcastReceiver powerReceiver;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activeInstance = this;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(Color.parseColor("#080711"));
            getWindow().setNavigationBarColor(Color.parseColor("#080711"));
        }

        prefs = getSharedPreferences("YesminAgentPrefs", MODE_PRIVATE);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new NativeAgentBridge(), "YesminNative");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushAgentStatusToUi();
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });

        registerChargingTriggersReceiver();
        requestRuntimePermissions();

        webView.loadDataWithBaseURL("https://yesmin.ai/", UiHtmlProvider.getHtml(), "text/html", "UTF-8", null);
    }

    public void dispatchVoiceFromOverlay(final String spokenText) {
        if (webView == null || spokenText == null) return;
        final String safe = spokenText.replace("'", "\\'").replace("\n", " ");
        mainHandler.post(() -> webView.evaluateJavascript("if(window.onNativeVoiceInput) window.onNativeVoiceInput('" + safe + "');", null));
    }

    private void registerChargingTriggersReceiver() {
        powerReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || intent.getAction() == null) return;
                String act = intent.getAction();
                if (Intent.ACTION_POWER_CONNECTED.equals(act)) {
                    webView.post(() -> webView.evaluateJavascript("if(window.onChargingTrigger) window.onChargingTrigger('CONNECTED');", null));
                } else if (Intent.ACTION_POWER_DISCONNECTED.equals(act)) {
                    webView.post(() -> webView.evaluateJavascript("if(window.onChargingTrigger) window.onChargingTrigger('DISCONNECTED');", null));
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        registerReceiver(powerReceiver, filter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        activeInstance = this;
        pushAgentStatusToUi();
    }

    private void pushAgentStatusToUi() {
        if (webView == null) return;
        boolean accActive = isAccessibilityServiceEnabled();
        String shizukuState = getShizukuOrRootStatus();
        String googleEmail = prefs.getString("google_email", "");
        int bat = getBatteryPercentage();
        String js = String.format(Locale.US,
                "if(window.onNativeTelemetry) window.onNativeTelemetry(%b, '%s', '%s', %d);",
                accActive,
                shizukuState.replace("'", "\\'"),
                googleEmail.replace("'", "\\'"),
                bat
        );
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    public boolean isAccessibilityServiceEnabled() {
        if (YesminAgentService.isConnected()) return true;
        try {
            String enabledServices = Settings.Secure.getString(
                    getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            );
            if (enabledServices != null && enabledServices.contains(getPackageName())) {
                return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    public boolean isShizukuInstalled() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0);
            return pi != null;
        } catch (Throwable t) {
            return false;
        }
    }

    public String getShizukuOrRootStatus() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED) {
                    return "GRANTED (Shizuku)";
                }
            }
            if (isShizukuInstalled()) {
                return "READY (Tap to Allow)";
            }
        } catch (Throwable ignored) {}
        return "Tap to Setup";
    }

    public int getBatteryPercentage() {
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent b = registerReceiver(null, ifilter);
            if (b != null) {
                int l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int s = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (l >= 0 && s > 0) return (l * 100) / s;
            }
        } catch (Throwable ignored) {}
        return 100;
    }

    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] perms = new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.ACCESS_FINE_LOCATION
            };
            ArrayList<String> needed = new ArrayList<>();
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(p);
                }
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), REQ_PERMS);
            }
        }
    }

    public class NativeAgentBridge {

        @JavascriptInterface
        public void vibrateTick() {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        v.vibrate(25);
                    }
                }
            } catch (Throwable ignored) {}
        }

        // 1. START PERSISTENT FLOATING OVERLAY & INFINITE CONTINUOUS LISTENING (Gemini Live Screen-Share Style!)
        @JavascriptInterface
        public String startBackgroundLiveMode() {
            if (!isAccessibilityServiceEnabled() || YesminAgentService.instance == null) {
                openAccessibilitySettings();
                return "⚠️ Pehle Accessibility Settings mein 'Yesmin AI Autonomous Agent' ko ON karein taaki main Home Screen aur dusre apps ke upar lagatar kaam kar sakun!";
            }
            YesminAgentService.instance.showOverlayAndStartContinuousLoop();
            return "✅ Yesmin Live Background Overlay ON ho gaya hai! Ab aap Home Screen par jao ya koi bhi app kholo, upar floating bar se main 1, 2, 3... infinity tak aapki har baat sunungi aur karungi!";
        }

        @JavascriptInterface
        public void stopBackgroundLiveMode() {
            if (YesminAgentService.instance != null) {
                YesminAgentService.instance.stopContinuousLoopAndHide();
            }
        }

        // 2. LIVE WEB / GOOGLE / WIKIPEDIA / DUCKDUCKGO RESEARCH ENGINE (Native Java HTTP -> No CORS blocks!)
        @JavascriptInterface
        public String performWebResearch(String query) {
            if (query == null || query.trim().isEmpty()) return "";
            StringBuilder results = new StringBuilder();
            try {
                String q = URLEncoder.encode(query.trim(), "UTF-8");
                // 1. Query Wikipedia Search API for deep factual knowledge
                String wikiUrl = "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=" + q + "&utf8=&format=json&srlimit=3";
                HttpURLConnection c1 = (HttpURLConnection) new URL(wikiUrl).openConnection();
                c1.setRequestProperty("User-Agent", "YesminAI/7.0 (Android; Autonomous Agent)");
                c1.setConnectTimeout(6000);
                c1.setReadTimeout(6000);
                if (c1.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(c1.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    String raw = sb.toString().replaceAll("<[^>]+>", "");
                    if (raw.length() > 900) raw = raw.substring(0, 900);
                    results.append("[Web Research]: ").append(raw).append("\n");
                }
            } catch (Throwable ignored) {}

            try {
                String q2 = URLEncoder.encode(query.trim(), "UTF-8");
                String ddgUrl = "https://api.duckduckgo.com/?q=" + q2 + "&format=json&no_html=1";
                HttpURLConnection c2 = (HttpURLConnection) new URL(ddgUrl).openConnection();
                c2.setRequestProperty("User-Agent", "YesminAI/7.0");
                c2.setConnectTimeout(5000);
                c2.setReadTimeout(5000);
                if (c2.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(c2.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    String raw = sb.toString();
                    if (raw.length() > 700) raw = raw.substring(0, 700);
                    results.append("[Instant Answer]: ").append(raw);
                }
            } catch (Throwable ignored) {}
            return results.toString();
        }

        // 3. DIRECT SYSTEM SETTINGS & HARDWARE CONTROL (Flashlight, Volume, Brightness, Wi-Fi, Bluetooth, Hotspot, Location, Battery)
        @JavascriptInterface
        public String controlPhoneSetting(String settingType, String stateOrVal) {
            String t = settingType != null ? settingType.toLowerCase(Locale.ROOT).trim() : "";
            String v = stateOrVal != null ? stateOrVal.toLowerCase(Locale.ROOT).trim() : "";

            try {
                // Flashlight / Torch
                if (t.contains("torch") || t.contains("flash") || t.contains("light")) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                        if (cm != null && cm.getCameraIdList().length > 0) {
                            boolean turnOn = !v.contains("off") && !v.contains("band");
                            cm.setTorchMode(cm.getCameraIdList()[0], turnOn);
                            return turnOn ? "🔦 Flashlight ON kar di hai Jaan!" : "🔦 Flashlight OFF kar di hai Jaan!";
                        }
                    }
                }

                // Volume Control
                if (t.contains("volume") || t.contains("sound") || t.contains("aawaz")) {
                    AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    if (am != null) {
                        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        if (v.contains("mute") || v.contains("zero") || v.contains("band")) {
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI);
                            return "🔇 Media Volume mute kar diya hai Jaan!";
                        } else if (v.contains("full") || v.contains("max") || v.contains("100")) {
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI);
                            return "🔊 Volume 100% full kar diya hai Jaan!";
                        } else if (v.contains("down") || v.contains("kam")) {
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                            return "🔉 Volume kam kar diya hai!";
                        } else {
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                            return "🔊 Volume badha diya hai!";
                        }
                    }
                }

                // Wi-Fi Settings / Panel
                if (t.contains("wifi") || t.contains("wi-fi") || t.contains("internet")) {
                    Intent panel = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                            ? new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                            : new Intent(Settings.ACTION_WIFI_SETTINGS);
                    panel.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(panel);
                    return "📶 Wi-Fi & Internet Panel khol diya hai Jaan!";
                }

                // Bluetooth Settings
                if (t.contains("bluetooth")) {
                    Intent bt = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                    bt.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(bt);
                    return "🦷 Bluetooth Settings khol di hai Jaan!";
                }

                // Location / GPS
                if (t.contains("location") || t.contains("gps")) {
                    Intent loc = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    loc.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(loc);
                    return "📍 Location / GPS Settings khol di hai!";
                }

                // Display / Brightness
                if (t.contains("display") || t.contains("brightness") || t.contains("dark mode")) {
                    Intent disp = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
                    disp.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(disp);
                    return "☀️ Display & Brightness Settings khol di hai!";
                }

                // Hotspot / Tethering
                if (t.contains("hotspot") || t.contains("tether")) {
                    Intent hs = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                    hs.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(hs);
                    return "📡 Hotspot & Network Settings khol di hai!";
                }

                // Battery / Power
                if (t.contains("battery") || t.contains("power")) {
                    Intent bat = new Intent(Intent.ACTION_BATTERY_SAVER_SETTINGS);
                    bat.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(bat);
                    return "🔋 Battery Saver Settings khol di hai!";
                }

                // Sound / Ringer / DND
                if (t.contains("dnd") || t.contains("ring") || t.contains("vibrate")) {
                    Intent snd = new Intent(Settings.ACTION_SOUND_SETTINGS);
                    snd.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(snd);
                    return "🔔 Sound & Vibration Settings khol di hai!";
                }

                // Default: Open Main Android Settings
                Intent gen = new Intent(Settings.ACTION_SETTINGS);
                gen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(gen);
                return "⚙️ Android System Settings khol di hai Jaan!";
            } catch (Throwable e) {
                return "Settings error: " + e.getMessage();
            }
        }

        // 4. SHIZUKU PERMISSION & AUTHORIZED APPS REGISTRATION
        @JavascriptInterface
        public String requestShizukuAccess() {
            try {
                if (!isShizukuInstalled()) {
                    Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api"));
                    market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(market);
                    return "Shizuku app install nahi hai — Play Store khol diya hai!";
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission("moe.shizuku.manager.permission.API_V23") == PackageManager.PERMISSION_GRANTED) {
                        pushAgentStatusToUi();
                        return "✅ Shizuku Access Granted Hai!";
                    }
                    mainHandler.post(() -> requestPermissions(new String[]{"moe.shizuku.manager.permission.API_V23"}, REQ_SHIZUKU_PERM));
                }
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    return "✅ Yesmin AI ab Shizuku ki 'Authorized applications' list mein dikhega! Wahan Yesmin AI ka switch ON karein.";
                }
                return "Requested Shizuku permission!";
            } catch (Throwable e) {
                return "Shizuku error: " + e.getMessage();
            }
        }

        // 5. REAL ROOT (su) PERMISSION & COMMAND EXECUTION
        @JavascriptInterface
        public String requestRootAccess() {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "id"});
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String out = br.readLine();
                p.waitFor();
                if (out != null && out.contains("uid=0")) {
                    return "✅ Real Root Access (uid=0) Active: " + out;
                }
                return "⚠️ Root (su) nahi mila. Accessibility Service + Live Overlay ON rakhein!";
            } catch (Throwable e) {
                return "⚠️ Phone Rooted nahi hai. Accessibility Service ON rakhein!";
            }
        }

        @JavascriptInterface
        public String runShellCommand(String cmd) {
            try {
                Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                int code = p.waitFor();
                if (code == 0 && sb.length() > 0) return "[Root] " + sb.toString().trim();
            } catch (Throwable ignored) {}

            try {
                Process p2 = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                BufferedReader br = new BufferedReader(new InputStreamReader(p2.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                p2.waitFor();
                return sb.toString().trim();
            } catch (Throwable e) {
                return "Shell error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void openAccessibilitySettings() {
            try {
                Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                mainHandler.post(() -> Toast.makeText(MainActivity.this,
                        "👉 'Installed apps' mein 'Yesmin AI Autonomous Agent' ko ON karein!",
                        Toast.LENGTH_LONG).show());
            } catch (Throwable ignored) {}
        }

        // 6. NORMAL PHONE CALL BY CONTACT NAME OR NUMBER
        @JavascriptInterface
        public String callContactByNameOrNumber(String query) {
            if (query == null || query.trim().isEmpty()) return "Jaan, kisko call karna hai naam batao?";
            String clean = query.trim();

            if (clean.matches(".*[0-9]{5,}.*")) {
                String num = clean.replaceAll("[^0-9+]", "");
                return placeDirectCall(num, num);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                try {
                    Cursor cursor = getContentResolver().query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            new String[]{
                                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                                    ContactsContract.CommonDataKinds.Phone.NUMBER
                            },
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                            new String[]{"%" + clean + "%"},
                            null
                    );
                    if (cursor != null) {
                        if (cursor.moveToFirst()) {
                            String foundName = cursor.getString(0);
                            String foundNum = cursor.getString(1);
                            cursor.close();
                            return placeDirectCall(foundName, foundNum);
                        }
                        cursor.close();
                    }
                } catch (Throwable ignored) {}
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mainHandler.post(() -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}, REQ_PERMS));
            }

            try {
                Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(clean)));
                dial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(dial);
                return "📞 Dialer khol diya hai '" + clean + "' ke liye, Jaan!";
            } catch (Throwable e) {
                return "Call error: " + e.getMessage();
            }
        }

        private String placeDirectCall(String displayName, String phoneNumber) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phoneNumber));
                    callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(callIntent);
                    return "📞 Calling " + displayName + " (" + phoneNumber + ") right now, Jaan!";
                } else {
                    Intent dialIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
                    dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(dialIntent);
                    return "📞 Dialing " + displayName + " (" + phoneNumber + "), Jaan!";
                }
            } catch (Throwable e) {
                return "Could not place call: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public String sendSosAlert(String phone, String customMsg) {
            if (phone == null || phone.trim().isEmpty()) return "Pehle SOS number save karo Jaan!";
            try {
                Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone.trim()));
                sms.putExtra("sms_body", customMsg != null && !customMsg.isEmpty() ? customMsg : "🚨 SOS Emergency Alert from Yesmin AI! Please help me at my current location.");
                sms.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(sms);
                return "🚨 SOS Emergency Alert triggered for " + phone;
            } catch (Throwable e) {
                return "SOS error: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public String executeAgentAction(String actionType, String param1, String param2) {
            YesminAgentService svc = YesminAgentService.instance;
            if ("GLOBAL".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.doGlobal(param1)) {
                    return "✅ Done Jaan! Executed: " + param1;
                }
                if (param1.equalsIgnoreCase("home")) runShellCommand("input keyevent 3");
                if (param1.equalsIgnoreCase("back")) runShellCommand("input keyevent 4");
                return "✅ Executed " + param1;
            }
            if ("CLICK_TEXT".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.clickByText(param1)) {
                    return "✅ Clicked '" + param1 + "' on screen!";
                }
                return "⚠️ '" + param1 + "' screen par nahi mila (Check if Accessibility Service is ON).";
            }
            if ("TAP_XY".equalsIgnoreCase(actionType)) {
                try {
                    float x = Float.parseFloat(param1);
                    float y = Float.parseFloat(param2);
                    if (svc != null && svc.tapXY(x, y)) return "✅ Tapped (" + (int) x + ", " + (int) y + ")";
                    runShellCommand("input tap " + (int) x + " " + (int) y);
                    return "✅ Tapped (" + (int) x + ", " + (int) y + ")";
                } catch (Throwable e) {
                    return "Invalid coordinates";
                }
            }
            if ("SCROLL_DOWN".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.swipe(500, 1550, 500, 380, 350)) {
                    return "✅ Scrolled down!";
                }
                runShellCommand("input swipe 500 1550 500 380 300");
                return "✅ Scrolled down!";
            }
            if ("SCROLL_UP".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.swipe(500, 420, 500, 1550, 350)) {
                    return "✅ Scrolled up!";
                }
                runShellCommand("input swipe 500 420 500 1550 300");
                return "✅ Scrolled up!";
            }
            if ("TYPE_TEXT".equalsIgnoreCase(actionType)) {
                if (svc != null && svc.inputTextOnScreen(param1)) {
                    return "✅ Typed: " + param1;
                }
                String safe = param1.replace(" ", "%s");
                runShellCommand("input text \"" + safe + "\"");
                return "✅ Typed: " + param1;
            }
            if ("READ_SCREEN".equalsIgnoreCase(actionType)) {
                if (svc != null) return svc.readScreenSummary();
                return "Accessibility Service is not active yet.";
            }
            if ("LAST_NOTIF".equalsIgnoreCase(actionType)) {
                return YesminAgentService.lastNotificationText.isEmpty()
                        ? "Abhi koi naya notification record nahi hua hai Jaan."
                        : YesminAgentService.lastNotificationText;
            }
            return "Unknown action";
        }

        @JavascriptInterface
        public void signInWithGoogle() {
            mainHandler.post(() -> {
                try {
                    Intent intent;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        intent = AccountManager.newChooseAccountIntent(
                                null, null, new String[]{"com.google"}, null, null, null, null);
                    } else {
                        intent = AccountManager.newChooseAccountIntent(
                                null, null, new String[]{"com.google"}, false, null, null, null, null);
                    }
                    startActivityForResult(intent, REQ_GOOGLE_ACCOUNT);
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Google Account Picker: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public boolean launchApp(String key, String pkg) {
            try {
                String k = key != null ? key.toLowerCase().trim() : "";
                PackageManager pm = getPackageManager();
                if ("camera".equals(k)) {
                    Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                    cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(cam);
                    return true;
                }
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                    return true;
                }
                if ("whatsapp".equals(k)) {
                    Intent w4b = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                    if (w4b != null) {
                        w4b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(w4b);
                        return true;
                    }
                }
                Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
                market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(market);
                return true;
            } catch (Throwable e) {
                return false;
            }
        }

        @JavascriptInterface
        public void playYouTube(String query) {
            try {
                Intent intent = new Intent(Intent.ACTION_SEARCH);
                intent.setPackage("com.google.android.youtube");
                intent.putExtra("query", query);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Throwable e) {
                Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
                web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(web);
            }
        }

        @JavascriptInterface
        public void openUrlExternal(String url) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Throwable ignored) {}
        }

        @JavascriptInterface
        public void startVoiceMic() {
            mainHandler.post(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo Jaan (Yesmin AI Listening)...");
                    startActivityForResult(intent, REQ_VOICE);
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "Voice Mic not available", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void speak(String text) {
            if (tts != null && text != null) {
                tts.setPitch(1.1f);
                tts.setSpeechRate(1.05f);
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yesmin_utt");
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK && data != null) {
            ArrayList<String> list = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (list != null && !list.isEmpty()) {
                String spoken = list.get(0).replace("'", "\\'").replace("\n", " ");
                webView.evaluateJavascript("if(window.onNativeVoiceInput) window.onNativeVoiceInput('" + spoken + "');", null);
            }
        } else if (requestCode == REQ_GOOGLE_ACCOUNT && resultCode == RESULT_OK && data != null) {
            String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
            if (accountName != null) {
                prefs.edit().putString("google_email", accountName).apply();
                Toast.makeText(this, "✅ Signed in with Google: " + accountName, Toast.LENGTH_LONG).show();
                pushAgentStatusToUi();
            }
        }
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("if(window.handleBackPress) window.handleBackPress();", val -> {
            if (!"true".equals(val)) {
                MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onDestroy() {
        try {
            if (powerReceiver != null) unregisterReceiver(powerReceiver);
        } catch (Throwable ignored) {}
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
