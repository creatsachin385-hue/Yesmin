package com.yesmin.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private SpeechRecognizer speechRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new YesminBridge(), "YesminAndroid");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    if (url.contains("youtube.com") || url.contains("youtu.be") || url.contains("instagram.com") || url.contains("whatsapp.com") || url.contains("spotify.com")) {
                        try {
                            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                            return true;
                        } catch (Exception ignored) {}
                    }
                    return false;
                }
                try {
                    Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    return true;
                } catch (Exception e) {
                    return true;
                }
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(new Locale("hi", "IN"));
                if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
            }
        });

        requestNeededPermissions();
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            String[] perms = new String[]{
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.MODIFY_AUDIO_SETTINGS
            };
            ArrayList<String> needed = new ArrayList<>();
            for (String p : perms) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    needed.add(p);
                }
            }
            if (!needed.isEmpty()) {
                requestPermissions(needed.toArray(new String[0]), 101);
            }
        }
    }

    public class YesminBridge {
        @JavascriptInterface
        public void requestAllPermissions() {
            runOnUiThread(() -> requestNeededPermissions());
        }

        @JavascriptInterface
        public boolean openApp(String appName, String pkg) {
            try {
                String key = appName != null ? appName.toLowerCase().trim() : "";
                PackageManager pm = getPackageManager();
                if ("camera".equals(key)) {
                    Intent cam = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                    cam.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(cam);
                    return true;
                }
                Intent launchIntent = pm.getLaunchIntentForPackage(pkg);
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launchIntent);
                    return true;
                }
                if ("whatsapp".equals(key)) {
                    Intent w = pm.getLaunchIntentForPackage("com.whatsapp.w4b");
                    if (w != null) {
                        w.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(w);
                        return true;
                    }
                }
                Intent market = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg));
                market.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(market);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void openYouTube(String query) {
            try {
                Intent intent = new Intent(Intent.ACTION_SEARCH);
                intent.setPackage("com.google.android.youtube");
                intent.putExtra("query", query);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            } catch (Exception e) {
                try {
                    String url = "https://www.youtube.com/results?search_query=" + Uri.encode(query);
                    Intent viewIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    viewIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(viewIntent);
                } catch (Exception ignored) {}
            }
        }

        @JavascriptInterface
        public void speakText(String text, String pitchStr, String rateStr) {
            if (tts != null && text != null) {
                try {
                    float p = Float.parseFloat(pitchStr);
                    float r = Float.parseFloat(rateStr);
                    tts.setPitch(p);
                    tts.setSpeechRate(r);
                } catch (Exception ignored) {}
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yesmin_utt");
            }
        }

        @JavascriptInterface
        public void stopSpeak() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void startVoiceRecognition() {
            runOnUiThread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestNeededPermissions();
                        notifyJsStatus("Please allow Microphone permission first!");
                        return;
                    }
                    if (speechRecognizer != null) {
                        speechRecognizer.destroy();
                    }
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(MainActivity.this);
                    speechRecognizer.setRecognitionListener(new RecognitionListener() {
                        @Override public void onReadyForSpeech(Bundle params) { notifyJsStatus("LISTENING"); }
                        @Override public void onBeginningOfSpeech() {}
                        @Override public void onRmsChanged(float rmsdB) {}
                        @Override public void onBufferReceived(byte[] buffer) {}
                        @Override public void onEndOfSpeech() { notifyJsStatus("IDLE"); }
                        @Override public void onError(int error) { notifyJsStatus("Voice mic ready (Tap to speak)"); }
                        @Override public void onResults(Bundle results) {
                            ArrayArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                            if (matches != null && !matches.isEmpty()) {
                                String spoken = matches.get(0).replace("'", "\\'").replace("\"", "\\\"");
                                webView.evaluateJavascript("if(window.onNativeVoiceResult) window.onNativeVoiceResult('" + spoken + "');", null);
                            } else {
                                notifyJsStatus("IDLE");
                            }
                        }
                        @Override public void onPartialResults(Bundle partialResults) {}
                        @Override public void onEvent(int eventType, Bundle params) {}
                    });
                    Intent recIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    recIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    recIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
                    recIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    speechRecognizer.startListening(recIntent);
                } catch (Exception e) {
                    notifyJsStatus("Voice error: " + e.getMessage());
                }
            });
        }

        private void notifyJsStatus(String msg) {
            String safe = msg.replace("'", "\\'");
            webView.evaluateJavascript("if(window.onNativeVoiceStatus) window.onNativeVoiceStatus('" + safe + "');", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }
}
