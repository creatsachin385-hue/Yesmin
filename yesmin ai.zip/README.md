# Yesmin AI — GitHub Android APK Builder (No PC & No Termux Required)

यह पैकेज केवल आपके **Android फ़ोन के ब्राउज़र** से सीधे **GitHub** पर `.apk` बनाने के लिए तैयार किया गया है। इसमें आपकी **OxionAI API Key (`cc_enbRFm5F2eVv3trOrACgwIbYZTtH8XAcxFcLzrWP8uuPJSc0`)** और **`https://oxionai.com/v1`** पहले से जुड़े हुए हैं।

## सिर्फ़ फ़ोन से GitHub पर APK बनाने के 4 आसान स्टेप्स:
1. [GitHub.com/new](https://github.com/new) पर जाएँ, `yesmin-ai` नाम से नया Repository बनाएँ और **Add a README file** पर टिक करके **Create repository** दबाएँ।
2. **Add file → Upload files** पर टैप करें और इस पूरी **`yesmin_ai_github_apk_builder.zip`** फ़ाइल को बिना अनज़िप किए सीधे अपलोड करके **Commit changes** कर दें।
3. अब फिर से **Add file → Create new file** पर टैप करें, नाम में `.github/workflows/build-apk.yml` लिखें, और नीचे दिया गया YAML कोड पेस्ट करके **Commit changes** दबा दें।
4. ऊपर **Actions** टैब में जाएँ → 2 मिनट में बिल्ड पूरा होने पर **Artifacts** सेक्शन से **`Yesmin-AI-Android-APK`** डाउनलोड करें और अपने फ़ोन में इंस्टॉल कर लें!
